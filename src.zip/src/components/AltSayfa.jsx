/* ═══════════════════════════════════════════════════════════════════════════
   VUKUF — ALTTAN AÇILAN SAYFA (bottom sheet)
   src/components/AltSayfa.jsx

   ── 8 EKİM 2026: BAŞTAN, SADE YAPI ─────────────────────────────────────────
   Kullanıcı: "Kaydırma kısmı daha kötü oldu, baştan bir şey düşünelim,
   şuankiler üst üste binip daha kötüleştirmiş olabilir, klasik ama temiz bir
   şey yapalım."

   Eski sürüm, paneli HER YERİNDEN aşağı çekip kapatabilmek için içerik
   kaydırmasının içine giriyordu: gövdeye pointer dinleyicileri, pasif olmayan
   touchmove + preventDefault, değişen `touch-action`, yön eşikleri, kenar
   payları… Her yama başka bir durumda kaydırmayı yutuyordu (iOS'ta bir
   dokunuşun ilk touchmove'u engellenirse o dokunuşun kaydırması tümüyle ölür).

   ARTIK KLASİK DÜZEN — iki ayrı bölge, birbirine karışmaz:
     1) BAŞLIK ŞERİDİ (tutamak çizgisi + başlık): yalnız burası sürüklenir.
        `touch-action: none` + pointer olayları; aşağı çekince ya da hızlı
        fiskeyle kapanır, yukarı çekmede direnç vardır.
     2) GÖVDE: ayrı bir kaydırma kutusu. Üzerinde HİÇBİR dokunma dinleyicisi,
        preventDefault ya da değişen touch-action YOK — kaydırma tamamen
        tarayıcının kendi kaydırması. `overscroll-behavior: contain` ile sona
        gelince arka sayfaya taşmaz.
   Kapatmanın öbür yolları: perdeye dokunmak, Esc.

   ── 26 EKİM 2026: KAPANMA KARARI (bilinen alt sayfa mantığı) ───────────────
   Kullanıcı: "Biraz aşağı sürükleyip belirli bir noktayı geçip bırakırsam panel
   kapanmalı, hemen yukarıdayken bıraktığımda kapanmamalı. Aşağı çekip vazgeçip
   yukarı geri sürüklediğimde az sürüklesem de açık kalmalı; şu anda az
   sürükleyince kapanıyor."
   ESKİ HATA: hız, BAŞLANGIÇTAN bırakışa kadarki ORTALAMA idi (toplam yol /
   toplam süre). Kısa ve çabuk bir dokunuş (20 px / 30 ms) "fiske" sayılıp
   paneli kapatıyordu; geri çekilen hareketin yönü de hiç hesaba girmiyordu.
   ŞİMDİ (iOS / Material alt sayfalarındaki gibi), karar BIRAKMA ANINA bakar:
     • Bırakış hızı: yalnız SON ~100 ms'deki hareketten (parmak durup
       bırakılırsa hız 0 sayılır).
     • Yukarı doğru hareketle bırakıldıysa → AÇIK KALIR (vazgeçildi), ne kadar
       aşağıda olursa olsun.
     • Aşağı doğru belirgin fiske (> HIZ_ESIGI) ve en az FISKE_EN_AZ px
       inilmişse → kapanır.
     • Aksi hâlde yalnız KONUM: eşik çizgisinin (panel boyunun %25'i;
       ESIK_EN_AZ…ESIK_EN_COK arası) altına inilmişse kapanır, üstündeyse
       yerine döner.
   Eşik geçilince tutamak çizgisi vurgu rengine döner: "bırakılırsa kapanır".
   Parmak sistemce kesilirse (pointercancel) panel her zaman yerine döner.

   Korunanlar: giriş/çıkış geçişi (keyframe değil, aynı transform), sürükledikçe
   solan perde, perdede parmak kaydırınca arka sayfanın kaymaması (iOS),
   yatay telefon düzeni için `yp-altsayfa` sınıfı (bkz. yatayDuzen.js).
   Gövdeye kilit (body position:fixed) BİLEREK yok — iOS'ta kapanışta sayfa
   konumunu zıplatıyor.
   ═══════════════════════════════════════════════════════════════════════════ */

import { useState, useRef, useEffect, useCallback } from "react"
import "./yatayDuzen"

const KAPANMA_SURESI = 220          // ms — çıkış geçişiyle aynı olmalı
const ESIK_ORAN = 0.25              // panel boyunun bu kadarı aşağı inilirse kapanır…
const ESIK_EN_AZ = 90               // …ama en az bu kadar px
const ESIK_EN_COK = 160             // …ve en çok bu kadar px (uzun panelde de "biraz" çekmek yetsin)
const HIZ_ESIGI = 0.65              // px/ms — aşağı fiske ile kapanma (bırakış hızı)
const GERI_HIZ = 0.15               // px/ms — bu hızla yukarı gidiyorsa "vazgeçildi"
const FISKE_EN_AZ = 30              // px — fiske sayılması için en az iniş
const HIZ_PENCERESI = 100           // ms — bırakış hızı bu son süredeki hareketten

export default function AltSayfa({
  kapat,
  theme,
  baslik = null,
  children,
  maxGenislik = "520px",
  maxYukseklik = "82vh",
}) {
  const [kayma, setKayma] = useState(0)
  const [surukleniyor, setSurukleniyor] = useState(false)
  const [kapaniyor, setKapaniyor] = useState(false)
  const [acildi, setAcildi] = useState(false)
  // id: pointer · basY: başlangıç · esik: bu sürükleme için kapanma çizgisi (px)
  // ornekler: son hareketler [{ t, y }] — bırakış hızı için
  const bilgi = useRef({ id: null, basY: 0, esik: ESIK_EN_AZ, ornekler: [] })
  const suruklendi = useRef(false)
  const zamanlayici = useRef(null)
  const perdeRef = useRef(null)
  const panelRef = useRef(null)

  // Giriş: ilk karede kapalı, sonraki karede açık → geçiş devreye girer.
  useEffect(() => {
    const r = requestAnimationFrame(() => setAcildi(true))
    return () => {
      cancelAnimationFrame(r)
      if (zamanlayici.current) clearTimeout(zamanlayici.current)
    }
  }, [])

  const kapanmayaBasla = useCallback(() => {
    setKapaniyor(true)
    // Geçiş bitmeden unmount edilirse panel zıplayarak kaybolur; bekleniyor.
    zamanlayici.current = setTimeout(() => kapat?.(), KAPANMA_SURESI)
  }, [kapat])

  // Esc ile kapanma (masaüstü)
  useEffect(() => {
    const tus = (e) => { if (e.key === "Escape") kapanmayaBasla() }
    window.addEventListener("keydown", tus)
    return () => window.removeEventListener("keydown", tus)
  }, [kapanmayaBasla])

  // Perdede parmak kaydırması arka sayfaya geçmesin (iOS). Yalnız PERDEDE;
  // panelin kendisine dokunulmuyor. Perdeye dokunma = kapat (onClick) ayrı.
  useEffect(() => {
    const el = perdeRef.current
    if (!el) return
    const engel = (e) => { if (e.cancelable) e.preventDefault() }
    el.addEventListener("touchmove", engel, { passive: false })
    return () => el.removeEventListener("touchmove", engel)
  }, [])

  // ── BAŞLIK ŞERİDİNDEN SÜRÜKLEME ────────────────────────────────────────
  function basla(e) {
    if (kapaniyor || bilgi.current.id != null) return
    if (e.button != null && e.button !== 0) return          // yalnız sol tık / parmak
    const boy = (panelRef.current && panelRef.current.offsetHeight) || 400
    bilgi.current = {
      id: e.pointerId,
      basY: e.clientY,
      esik: Math.min(ESIK_EN_COK, Math.max(ESIK_EN_AZ, boy * ESIK_ORAN)),
      ornekler: [{ t: performance.now(), y: e.clientY }],
    }
    suruklendi.current = false
    setSurukleniyor(true)
    try { e.currentTarget.setPointerCapture(e.pointerId) } catch { /* eski tarayıcı */ }
  }
  function hareket(e) {
    const b = bilgi.current
    if (b.id !== e.pointerId) return
    const simdi = performance.now()
    b.ornekler.push({ t: simdi, y: e.clientY })
    // Yalnız son pencereyi tut (bir örnek fazlası: pencere başını kapsasın)
    while (b.ornekler.length > 2 && simdi - b.ornekler[1].t > HIZ_PENCERESI) b.ornekler.shift()
    const dy = e.clientY - b.basY
    if (Math.abs(dy) > 3) suruklendi.current = true
    setKayma(dy > 0 ? dy : dy * 0.25)          // yukarı çekmede direnç
  }
  // Bırakış hızı (px/ms, + aşağı): son HIZ_PENCERESI içindeki hareket.
  // Parmak bir süre durup bırakıldıysa pencerede hareket yok → 0.
  function birakisHizi(simdi, y) {
    const o = bilgi.current.ornekler
    let ilk = null
    for (const n of o) { if (simdi - n.t <= HIZ_PENCERESI) { ilk = n; break } }
    if (!ilk) return 0
    const dt = simdi - ilk.t
    return dt > 8 ? (y - ilk.y) / dt : 0
  }
  function bitir(e, iptal = false) {
    const b = bilgi.current
    if (b.id !== e.pointerId) return
    const simdi = performance.now()
    const dy = Math.max(0, e.clientY - b.basY)
    const hiz = birakisHizi(simdi, e.clientY)
    b.id = null
    setSurukleniyor(false)

    let kapansin = false
    if (!iptal && suruklendi.current) {
      if (hiz <= -GERI_HIZ) kapansin = false                       // yukarı doğru bırakıldı → vazgeçildi
      else if (hiz >= HIZ_ESIGI && dy >= FISKE_EN_AZ) kapansin = true  // aşağı fiske
      else kapansin = dy >= b.esik                                 // konuma göre
    }
    if (kapansin) kapanmayaBasla()
    else setKayma(0)
  }

  const yer = kapaniyor || !acildi ? "100%" : `${kayma}px`
  const perdeOran = kapaniyor ? 0 : Math.max(0, 1 - Math.max(0, kayma) / 320)
  // Eşik geçildi mi (tutamak vurgusu için) — bırakılırsa kapanır
  const esikGecildi = surukleniyor && kayma >= bilgi.current.esik

  return (
    <>
      <div
        ref={perdeRef}
        onClick={kapanmayaBasla}
        style={{
          position: "fixed", inset: 0, zIndex: 300,
          touchAction: "none",
          background: `rgba(0,0,0,${0.35 * (acildi ? perdeOran : 0)})`,
          transition: surukleniyor ? "none" : "background 0.22s ease",
        }}
      />

      <div
        ref={panelRef}
        className="yp-altsayfa"
        role="dialog"
        aria-modal="true"
        style={{
          position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 301,
          maxWidth: maxGenislik, maxHeight: maxYukseklik, margin: "0 auto",
          display: "flex", flexDirection: "column", overflow: "hidden",
          background: theme.surface,
          borderTop: `1px solid ${theme.border}`,
          borderRadius: "20px 20px 0 0",
          boxShadow: "0 -8px 30px rgba(0,0,0,0.22)",
          transform: `translateY(${yer})`,
          transition: surukleniyor ? "none" : `transform ${KAPANMA_SURESI}ms cubic-bezier(.22,.61,.36,1)`,
        }}
      >
        {/* 1) BAŞLIK ŞERİDİ — tek sürükleme alanı. Dokunma hedefi çizgiden
            büyük tutuluyor; 4 px'lik çizgiyi yakalamak zor. */}
        <div
          onPointerDown={basla}
          onPointerMove={hareket}
          onPointerUp={(e) => bitir(e)}
          onPointerCancel={(e) => bitir(e, true)}
          // Sürükledikten sonra başlıktaki bir öğe tıklanmış sayılmasın
          onClickCapture={(e) => {
            if (suruklendi.current) { e.stopPropagation(); e.preventDefault() }
            suruklendi.current = false
          }}
          role="button"
          aria-label="Paneli kapatmak için aşağı sürükleyin"
          style={{
            flexShrink: 0,
            touchAction: "none",
            cursor: surukleniyor ? "grabbing" : "grab",
            padding: "0 20px",
            userSelect: "none", WebkitUserSelect: "none",
          }}
        >
          <div style={{ display: "flex", justifyContent: "center", padding: "12px 0 8px" }}>
            <div style={{
              width: "40px", height: "4px", borderRadius: "2px",
              background: esikGecildi ? theme.accent : theme.border,
              opacity: surukleniyor ? 1 : 0.85,
              transform: surukleniyor ? "scaleX(1.25)" : "none",
              transition: "transform 0.15s ease, opacity 0.15s ease, background 0.15s ease",
            }} />
          </div>
          {baslik && (
            <div style={{
              fontSize: "12px", color: theme.textSecondary,
              letterSpacing: "1px", padding: "2px 4px 6px",
            }}>
              {baslik}
            </div>
          )}
        </div>

        {/* 2) GÖVDE — tarayıcının kendi kaydırması; hiçbir dokunma dinleyicisi yok. */}
        <div
          style={{
            flex: "1 1 auto", minHeight: 0,
            overflowY: "auto",
            overscrollBehavior: "contain",
            WebkitOverflowScrolling: "touch",
            padding: "0 20px calc(18px + env(safe-area-inset-bottom))",
          }}
        >
          {children}
        </div>
      </div>
    </>
  )
}
