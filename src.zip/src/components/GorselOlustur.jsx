import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import {
  X, Download, Share2, Plus, Check, Loader2,
  Square, RectangleHorizontal, RectangleVertical, Image as ImageIcon, Pipette,
  ImagePlay, Film, Volume2, VolumeX, CircleStop, Smartphone, Monitor,
  Ratio, LayoutTemplate, Frame, Eye, Wind, Sun, Palette, Layers, Move, Gauge, Timer, Highlighter, Shuffle,
} from "lucide-react"
import { DESENLER, GORSELLER } from "../data/arkaplanlar"
// İzleme modunun sahnesi (hareket / hava / ışık) ve ortak galeri — 7 Ekim 2026'da
// görsel oluşturmaya da aktarıldı (kullanıcı: "görsel oluşturmada olmayan kısımları aktaralım").
import { HAREKETLER as SAHNE_HAREKETLERI, HIZLAR, HAVALAR, ISIKLAR, GECIS_SN, resimCiz, gecisCiz, havaKur, havaCiz, isikCiz, videoCiz, videoSigar, videoKalis, VIDEO_YERLESIMLERI } from "../data/izlemeSahne"
import { galeriBlobu, videoKaresi } from "../data/izlemeGaleri"
import { useIzlemeAyar, ayarOku, ayarYaz } from "../data/izlemeAyar"
import { hizliKayitOlasi, hizliKodekler, sesleriBirlestir, hizliKaydet, videoOkuyucuKur } from "../data/hizliKayit"
import { Secim, Anahtar, AyarBaslik, ArkaPlanIzgara, desenOnizleme, useGaleriOgeleri, SusRenkleri } from "./AyarOgeleri"
import GaleriDuzenleyici, { GaleriKolaj, GaleriOzeti } from "./GaleriDuzenleyici"
// Özel okuyuş işaretlerinin (kasr/medd/nûn-i sağîre) kuralı TEK YERDE, mushaf
// sayfasıyla aynı tabloda duruyor. Burada yalnız ÇİZİM var, kural yok.
import { ozelOkuyusAyikla } from "./MushafKelime"

// ── ÂYET SONU ROZETİ — MushafAyetRozeti.jsx'in canvas sürümü ─────────────────────────────
// Süsleme (rakam HARİÇ) tek renk (#000) rasterize edilir; çizerken 'source-in' ile metnin
// rengine boyanır → senkron çalışır (video karesinde görüntü beklemesi olmaz). Rakam ayrıca
// Scheherazade ile canvas'a yazılır. viewBox, süslemenin taşan uçları kırpılmasın diye geniş.
const ROZET_GRUP = (t) => `<g transform="${t}">`
  + `<path d="M0 -19 C-11 -18.5 -17 -10 -17 0 C-17 10 -11 18.5 0 19 C-6 13 -6.5 -13 0 -19 Z" opacity=".92"/>`
  + `<path d="M-2 -14 C-7 -13.5 -12 -6.5 -12 0 C-12 6.5 -7 13.5 -2 14" fill="none" stroke="#000" stroke-width=".6" opacity=".45"/>`
  + `<path d="M-8 -24 C-9.5 -17 -8 -8.5 -7 0 C-8 8.5 -9.5 17 -8 24" fill="none" stroke="#000" stroke-width=".8" opacity=".5"/>`
  + `<path d="M-2 -19 C1 -22 3 -26 2 -31 C-2 -30 -6 -24 -1 -18.5 Z"/>`
  + `<path d="M-2 19 C1 22 3 26 2 31 C-2 30 -6 24 -1 18.5 Z"/>`
  + `<path d="M-8 -17 C-12 -18 -15.5 -16.5 -17 -13.5 C-14.5 -13 -12 -14 -10.5 -16 C-11 -13.5 -12.5 -11.5 -15.5 -11 C-12.5 -10 -9 -12 -7.5 -15 Z" opacity=".85"/>`
  + `<path d="M-8 17 C-12 18 -15.5 16.5 -17 13.5 C-14.5 13 -12 14 -10.5 16 C-11 13.5 -12.5 11.5 -15.5 11 C-12.5 10 -9 12 -7.5 15 Z" opacity=".85"/>`
  + `<path d="M-16.5 -1.8 L-15 0 L-16.5 1.8 L-18 0 Z" opacity=".55"/>`
  + `<path d="M-5.5 -7.5 C-7.5 -8.5 -10 -8 -11 -6 C-9 -5.5 -7 -6 -5.5 -7.5 Z" opacity=".7"/>`
  + `<path d="M-5.5 7.5 C-7.5 8.5 -10 8 -11 6 C-9 5.5 -7 6 -5.5 7.5 Z" opacity=".7"/>`
  + `<circle cx="-12" cy="-22" r="0.9" opacity=".5"/><circle cx="-14.5" cy="-20.5" r="0.5" opacity=".35"/>`
  + `<circle cx="-12" cy="22" r="0.9" opacity=".5"/><circle cx="-14.5" cy="20.5" r="0.5" opacity=".35"/>`
  + `<circle cx="-9" cy="-3.5" r="0.7" opacity=".55"/><circle cx="-9" cy="3.5" r="0.7" opacity=".55"/>`
  + `<path d="M-4 -19 C-6 -24 -9 -27 -14 -27 C-11 -24 -8 -21 -4 -19 Z" opacity=".7"/>`
  + `<path d="M-1 -19 C1 -24 3 -27 8 -27 C5 -24 2 -21 -1 -19 Z" opacity=".5"/>`
  + `<path d="M-4 19 C-6 24 -9 27 -14 27 C-11 24 -8 21 -4 19 Z" opacity=".7"/>`
  + `<path d="M-1 19 C1 24 3 27 8 27 C5 24 2 21 -1 19 Z" opacity=".5"/>`
  + `</g>`
// NOT: Safari, canvas'a çizilecek SVG görselinde AÇIK width/height ister (yalnız viewBox
// varsa iOS'ta 0×0 çizip hiçbir şey göstermez) → width/height açıkça verilir.
const ROZET_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="140" height="68" viewBox="-70 -34 140 68" fill="#000">`
  + ROZET_GRUP("translate(-50 0)") + ROZET_GRUP("translate(50 0) scale(-1 1)") + `</svg>`
const ROZET_ORAN = 140 / 68          // rozet genişlik/yükseklik oranı (viewBox)
export const rozetGorseliUret = () => {
  const im = new Image()
  im.src = "data:image/svg+xml;utf8," + encodeURIComponent(ROZET_SVG)
  return im
}
const arapcaRakamGorsel = (sayi) => {
  const r = "٠١٢٣٤٥٦٧٨٩"
  return String(sayi).split("").map(d => r[+d] ?? d).join("")
}
// Küçük 8 köşeli yıldız (secde rozeti) — verilen renkte dolu çizer.
const yildizCiz = (ctx, cx, cy, r, renk) => {
  ctx.save()
  ctx.beginPath()
  for (let i = 0; i < 16; i++) {
    const ang = -Math.PI / 2 + (i * Math.PI) / 8
    const rr = i % 2 ? r * 0.46 : r
    const x = cx + Math.cos(ang) * rr, yy = cy + Math.sin(ang) * rr
    if (i) ctx.lineTo(x, yy); else ctx.moveTo(x, yy)
  }
  ctx.closePath()
  ctx.fillStyle = renk
  ctx.fill()
  ctx.restore()
}

// ── RAHLE ────────────────────────────────────────────────────────────────────
// Sûre adı hattının altındaki süs: ÜSTTEN HAFİF EĞİK bakışla, üzerinde açık
// mushaf duran çapraz ayaklı rahle.
//
// ÜÇ DENEMEDEN ÇIKAN DERS: bir nesne çizimini tanınır yapan şey ayrıntı değil,
// (1) YERE BASMASI ve (2) ÖRTÜŞME. Perspektifli sürüm ayrıntılıydı ama havada
// duruyordu; örtüşmesiz sürüm de düz bir "X" harfi gibi okunuyordu.
//   • Yere basma: lataların alt uçları YATAY kesiliyor, ikisi de aynı zemin
//     çizgisinde bitiyor; altlarında pabuç ve soluk bir zemin çizgisi var.
//   • Örtüşme: arka plan fotoğraf olabildiği için DOLGU kullanılamıyor. Onun
//     yerine `gizliCiz()` her çizgiyi engel çokgenlerle (kitabın iki sayfası,
//     öndeki lata) kesiştirip yalnız DIŞARIDA kalan parçalarını çiziyor. Gerçek
//     gizli-çizgi hesabı; saf `stroke` ile katı nesne görüntüsü veren şey bu.
//
// cx: merkez, yUst: üst kenar, gen: toplam genişlik. Yükseklik gen*RAHLE_ORAN.
const RAHLE_ORAN = 0.74
function rahleCiz(ctx, cx, yUst, gen, renk, kalin) {
  const h = gen * RAHLE_ORAN
  const P = (nx, ny) => ({ x: cx + (nx - 0.5) * gen, y: yUst + ny * h })
  const ekle = (p, dx, dy) => ({ x: p.x + dx, y: p.y + dy })
  const ara = (a, b, f) => ({ x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f })
  const yTepe = yUst + h * 0.02
  const yZemin = yUst + h * 0.95
  const YARI = gen * 0.058

  ctx.save()
  ctx.strokeStyle = renk
  ctx.lineWidth = kalin
  ctx.lineCap = "round"
  ctx.lineJoin = "round"
  const yol = (n, kapali = false) => {
    ctx.beginPath()
    n.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)))
    if (kapali) ctx.closePath()
    ctx.stroke()
  }

  // ── Geometri yardımcıları ───────────────────────────────────────────────
  const kesisimT = (p1, p2, p3, p4) => {
    const r = { x: p2.x - p1.x, y: p2.y - p1.y }
    const t2 = { x: p4.x - p3.x, y: p4.y - p3.y }
    const payda = r.x * t2.y - r.y * t2.x
    if (Math.abs(payda) < 1e-9) return null
    const t = ((p3.x - p1.x) * t2.y - (p3.y - p1.y) * t2.x) / payda
    const u = ((p3.x - p1.x) * r.y - (p3.y - p1.y) * r.x) / payda
    return t > 0 && t < 1 && u > 0 && u < 1 ? t : null
  }
  const icindeMi = (n, cok) => {
    let ic = false
    for (let i = 0, j = cok.length - 1; i < cok.length; j = i++) {
      const a = cok[i], b = cok[j]
      if ((a.y > n.y) !== (b.y > n.y) &&
          n.x < ((b.x - a.x) * (n.y - a.y)) / ((b.y - a.y) || 1e-9) + a.x) ic = !ic
    }
    return ic
  }
  /* Bir doğru parçasını engel çokgenlerin DIŞINDA kalan parçalarına bölerek çizer. */
  const gizliCiz = (p, q, engeller) => {
    if (!engeller.length) { yol([p, q]); return }
    const ts = [0, 1]
    for (const cok of engeller) {
      for (let i = 0, j = cok.length - 1; i < cok.length; j = i++) {
        const t = kesisimT(p, q, cok[j], cok[i])
        if (t !== null) ts.push(t)
      }
    }
    ts.sort((a, b) => a - b)
    const uzerinde = (t) => ara(p, q, t)
    for (let i = 0; i < ts.length - 1; i++) {
      if (ts[i + 1] - ts[i] < 0.005) continue
      const orta = uzerinde((ts[i] + ts[i + 1]) / 2)
      if (engeller.some(c => icindeMi(orta, c))) continue
      yol([uzerinde(ts[i]), uzerinde(ts[i + 1])])
    }
  }
  const cokgenCiz = (nk, engeller) => {
    for (let i = 0; i < nk.length; i++) gizliCiz(nk[i], nk[(i + 1) % nk.length], engeller)
  }

  // ── LATALAR ─────────────────────────────────────────────────────────────
  // Eksenden iki paralel kenar, üstte ve zeminde YATAY kesim → düz basan ayak.
  const lataCokgen = (eksenA, eksenB) => {
    const dx = eksenB.x - eksenA.x, dy = eksenB.y - eksenA.y
    const L = Math.hypot(dx, dy) || 1
    const px = -dy / L * YARI, py = dx / L * YARI
    const kes = (ax, ay, yy) => ({ x: ax + dx * ((yy - ay) / (dy || 1e-6)), y: yy })
    const kenar = (s) => [
      kes(eksenA.x + px * s, eksenA.y + py * s, yTepe),
      kes(eksenA.x + px * s, eksenA.y + py * s, yZemin),
    ]
    const [u1, a1] = kenar(1), [u2, a2] = kenar(-1)
    return [u1, a1, a2, u2]            // üst1, alt1, alt2, üst2
  }
  const onLata = lataCokgen(P(0.045, 1.04), P(0.945, -0.06))
  const arkaLata = lataCokgen(P(0.955, 1.04), P(0.055, -0.06))

  // ── AÇIK MUSHAF ─────────────────────────────────────────────────────────
  // Sırt ortada, iki sayfa dışa-yukarı. Üstten baktığımız için her sayfanın
  // ARKA kenarı `derin` kadar yukarıda: yüzeyi görüyoruz.
  const C = P(0.5, 0.44)                     // sırt, ön uç
  const Lf = P(0.165, 0.215), Rf = P(0.835, 0.215)
  const derin = -h * 0.185
  const Cb = ekle(C, 0, derin), Lb = ekle(Lf, 0, derin), Rb = ekle(Rf, 0, derin)
  const solSayfa = [C, Lf, Lb, Cb]
  const sagSayfa = [C, Rf, Rb, Cb]
  const kitap = [solSayfa, sagSayfa]

  // ── ZEMİN ───────────────────────────────────────────────────────────────
  ctx.save(); ctx.globalAlpha = 0.28; ctx.lineWidth = kalin * 0.8
  yol([P(0.0, 0.975), P(1.0, 0.975)])
  ctx.restore()

  // ── ÇİZİM SIRASI: arka lata (kitap + ön lata arkasında) → ön lata (kitap
  //    arkasında) → pabuçlar → kitap. Her biri kendinden ÖNDEKİLERLE kesiliyor.
  cokgenCiz(arkaLata, [onLata, ...kitap])
  cokgenCiz(onLata, kitap)

  /* PABUÇ — fotoğraftaki en ayırt edici parça: tabanı yere düz basan, dış ucu
     kızak gibi yukarı kıvrılan ayak. */
  const ayak = (lata) => {
    const [, a1, a2] = lata
    const dis = Math.abs(a1.x - cx) > Math.abs(a2.x - cx) ? a1 : a2
    const ic = dis === a1 ? a2 : a1
    const yon = Math.sign(dis.x - ic.x) || 1
    const e = YARI * 1.05
    const uc = dis.x + yon * e
    ctx.beginPath()
    ctx.moveTo(ic.x, yZemin)
    ctx.lineTo(uc, yZemin)
    ctx.quadraticCurveTo(uc + yon * e * 0.2, yZemin - YARI * 0.7, dis.x - yon * YARI * 0.15, yZemin - YARI * 1.15)
    ctx.stroke()
  }
  ayak(arkaLata); ayak(onLata)

  // Oyma süsü — ALT kollarda (üst kollar kitabın arkasında kalıyor)
  const badem = (merkez, yon, uzun, genis) => {
    const A = ekle(merkez, -yon.x * uzun, -yon.y * uzun)
    const B = ekle(merkez, yon.x * uzun, yon.y * uzun)
    ctx.beginPath()
    ctx.moveTo(A.x, A.y)
    ctx.quadraticCurveTo(merkez.x - yon.y * genis, merkez.y + yon.x * genis, B.x, B.y)
    ctx.quadraticCurveTo(merkez.x + yon.y * genis, merkez.y - yon.x * genis, A.x, A.y)
    ctx.stroke()
  }
  const birim = (a, b) => {
    const dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy) || 1
    return { x: dx / L, y: dy / L }
  }
  ctx.save(); ctx.globalAlpha = 0.7; ctx.lineWidth = kalin * 0.7
  for (const l of [onLata, arkaLata]) {
    const ustOrta = ara(l[0], l[3], 0.5), altOrta = ara(l[1], l[2], 0.5)
    badem(ara(ustOrta, altOrta, 0.80), birim(ustOrta, altOrta), gen * 0.06, gen * 0.042)
  }
  ctx.restore()

  // ── KİTAP en üstte: yüzeyler, sayfa kalınlığı, satır izleri ─────────────
  yol(solSayfa, true)
  yol(sagSayfa, true)
  const kal = h * 0.055
  yol([ekle(Lf, 0, kal), ekle(C, 0, kal), ekle(Rf, 0, kal)])
  yol([Lf, ekle(Lf, 0, kal)]); yol([C, ekle(C, 0, kal)]); yol([Rf, ekle(Rf, 0, kal)])

  ctx.save(); ctx.globalAlpha = 0.5; ctx.lineWidth = kalin * 0.6
  for (const D of [Lf, Rf]) {
    for (const f of [0.28, 0.52, 0.76]) {
      const a = ara(C, Cb, f), b = ara(D, D === Lf ? Lb : Rb, f)
      yol([ara(a, b, 0.14), ara(a, b, 0.88)])
    }
  }
  ctx.restore()

  ctx.restore()
}

// Sûre adı, SureBasligi.jsx ile AYNI kaynaktan geliyor: `surah-name-v2-icon`
// fontunun özel kullanım alanındaki (PUA) glifleri, U+E000 + sûre numarası.
// Tek yerde tanımlı olması, başlıkla görselin ayrışmasını imkânsız kılıyor.
const SURE_ADI_FONT = "'surah-name-v2-icon', serif"
const sureAdiGlifi = (sureNo) =>
  sureNo >= 1 && sureNo <= 114 ? String.fromCodePoint(0xE000 + sureNo) : ""

/* ── SÛRE ADI GLİFİNİN GERÇEK YÜKSEKLİĞİ ─────────────────────────────────────
   `measureText` bu fontun özel alan (PUA) glifleri için güvenilir değil: dönen
   kutu gerçek mürekkebin çok altında kalabiliyor, blok yüksekliksiz kalıyor ve
   hat KAYNAK SATIRININ ÜSTÜNE BİNİYOR (cihazda görüldü). Bu yüzden glif bir kez
   gizli tuvale çizilip PİKSELLERİ TARANIYOR; taban çizgisine göre gerçek üst/alt
   taşma bulunuyor. Sonuç punto oranı olarak saklanıyor, her boyda çarpılıyor.
   Ölçüm glif başına bir kez yapılıyor (114 sûre → en çok 114 küçük tarama).
   DİKKAT: yalnız font YÜKLENDİKTEN sonra çağrılmalı; çağıranlar bunu güvence
   altına alıyor (sûre adı, font hazır değilse zaten hiç çizilmiyor). */
const sureAdiOlcuBellek = new Map()
function sureAdiOlcusu(glif) {
  if (sureAdiOlcuBellek.has(glif)) return sureAdiOlcuBellek.get(glif)
  let sonuc = null
  try {
    const REF = 90
    const cv = document.createElement("canvas")
    cv.width = REF * 5; cv.height = REF * 3
    const c = cv.getContext("2d")
    c.font = `${REF}px ${SURE_ADI_FONT}`
    c.textAlign = "center"; c.textBaseline = "alphabetic"; c.fillStyle = "#000"
    try { c.direction = "rtl" } catch { /* eski tarayıcı */ }
    const taban = REF * 2
    c.fillText(glif, cv.width / 2, taban)
    const d = c.getImageData(0, 0, cv.width, cv.height).data
    let ust = -1, alt = -1, sol = -1, sag = -1
    for (let y = 0; y < cv.height; y++) {
      let dolu = false
      for (let x = 0; x < cv.width; x++) {
        if (d[(y * cv.width + x) * 4 + 3] > 8) {
          dolu = true
          if (sol < 0 || x < sol) sol = x
          if (x > sag) sag = x
        }
      }
      if (dolu) { if (ust < 0) ust = y; alt = y }
    }
    // sol/sag: mürekkebin, çizim noktasına (ortalı) göre yatay taşması — sûre adını
    // kaynak satırının YANINA koyarken genişlik ve hizalama için (7 Ekim 2026).
    if (ust >= 0) sonuc = {
      asc: (taban - ust) / REF, desc: (alt - taban) / REF,
      sol: (sol - cv.width / 2) / REF, sag: (sag + 1 - cv.width / 2) / REF,
    }
  } catch { /* tuval okunamadı → metriklere düşülür */ }
  sureAdiOlcuBellek.set(glif, sonuc)
  return sonuc
}

// ════════════════════════════════════════════════════════════════
// GÖRSEL OLUŞTUR — âyet / metin paylaşım görseli üretici (ortak bileşen)
//
// KuranOkuma âyet gönderir (arapca + meal), OkumaEkrani seçili metni gönderir (metin).
// Her şey TEK CANVAS'a çizilir; önizleme aynı canvas'ın CSS ile küçültülmüş hâlidir,
// yani kullanıcının gördüğü ile indirdiği BİREBİR aynıdır.
//
// props:
//   acik, kapat
//   arapca      : string | null   — Arapça blok (KuranOkuma)
//   meal        : string | null   — Türkçe blok (meal veya seçili metin)
//   kaynak      : string | null   — "Bakara 255" / "On Dokuzuncu Mektup · s. 225"
//   arapcaFont  : string          — aktif Arapça font-family (canvas'a da verilir)
//   theme, isMobile
// ════════════════════════════════════════════════════════════════

const ORANLAR = [
  { id: "1:1",  ad: "Kare",     w: 1080, h: 1080, Ikon: Square },
  { id: "4:5",  ad: "Dikey",    w: 1080, h: 1350, Ikon: RectangleVertical },
  { id: "9:16", ad: "Hikâye",   w: 1080, h: 1920, Ikon: RectangleVertical },
  { id: "16:9", ad: "Yatay",    w: 1920, h: 1080, Ikon: RectangleHorizontal },
  { id: "3:4",  ad: "Klasik",   w: 1080, h: 1440, Ikon: RectangleVertical },
]

// ── TAM EKRAN ────────────────────────────────────────────────────────────────
// Cihazın GERÇEK ekran çözünürlüğü: CSS ölçüsü × piksel yoğunluğu (dpr).
// `screen.width/height` mobilde döndürmede değişmediği için cihazın doğal yönü korunur.
// Uzun kenar 3000 px ile sınırlanır (çok büyük canvas telefonda çizilemiyor/çok yavaş).
export function ekranOlcusuAl() {
  const yedek = { id: "ekran", ad: "Tam Ekran", w: 1080, h: 1920, Ikon: Smartphone, etiket: "1080×1920" }
  try {
    const dpr = Math.min(Math.max(window.devicePixelRatio || 1, 1), 3)
    let w = Math.round((window.screen && window.screen.width ? window.screen.width : window.innerWidth) * dpr)
    let h = Math.round((window.screen && window.screen.height ? window.screen.height : window.innerHeight) * dpr)
    if (!(w > 0) || !(h > 0)) return yedek
    let uzun = Math.max(w, h)
    const SINIR = 3000, EN_AZ = 1280
    if (uzun > SINIR) { const k = SINIR / uzun; w = Math.round(w * k); h = Math.round(h * k); uzun = SINIR }
    // Çok küçük ekranlarda (eski cihaz / dpr okunamadı) çıktı kullanışsız kalmasın
    if (uzun < EN_AZ) { const k = EN_AZ / uzun; w = Math.round(w * k); h = Math.round(h * k) }
    w = Math.max(2, Math.round(w / 2) * 2)
    h = Math.max(2, Math.round(h / 2) * 2)
    return { id: "ekran", ad: "Tam Ekran", w, h, Ikon: h >= w ? Smartphone : Monitor, etiket: `${w}×${h}` }
  } catch { return yedek }
}

const CERCEVELER = [
  { id: "yok",    ad: "Çerçevesiz" },
  { id: "ince",   ad: "İnce Çizgi" },
  { id: "cift",   ad: "Çift Çizgi" },
  { id: "kose",   ad: "Köşe Süsü" },
  { id: "kemer",  ad: "Kemer" },
  { id: "kartus", ad: "Kartuş" },
]

const KARARTMALAR = [
  { id: "yok", ad: "Yok",  guc: 0 },
  { id: "az",  ad: "Az",   guc: 0.28 },
  { id: "orta", ad: "Orta", guc: 0.45 },
  { id: "cok", ad: "Çok",  guc: 0.62 },
]

// ── YAZI RENGİ ────────────────────────────────────────────────────────────────
// "oto" = zemin koyuysa fildişi, açıksa koyu (varsayılan davranış).
// Yanında hazır öneriler, kullanıcının seçtiği ÖZEL renk ve SON 5 renk durur.
export const ONERILEN_RENKLER = [
  { id: "beyaz",    ad: "Beyaz",       renk: "#ffffff" },
  { id: "fildisi",  ad: "Fildişi",     renk: "#f6f1e6" },
  { id: "krem",     ad: "Krem",        renk: "#eadfc4" },
  { id: "kum",      ad: "Kum",         renk: "#dcc9a6" },
  { id: "altin",    ad: "Altın",       renk: "#d9b45a" },
  { id: "bakir",    ad: "Bakır",       renk: "#c98a4b" },
  { id: "nane",     ad: "Nane",        renk: "#cfe8d5" },
  { id: "zumrut",   ad: "Zümrüt",      renk: "#7fc9a5" },
  { id: "gok",      ad: "Gök",         renk: "#cfe0f5" },
  { id: "lacivert", ad: "Lâcivert",    renk: "#8fb4e3" },
  { id: "gul",      ad: "Gül",         renk: "#f3d3d3" },
  { id: "mercan",   ad: "Mercan",      renk: "#e59a8a" },
  { id: "lila",     ad: "Lila",        renk: "#d9cdf0" },
  { id: "gri",      ad: "Açık Gri",    renk: "#c9cdd2" },
  { id: "kahve",    ad: "Kahve",       renk: "#5a4632" },
  { id: "koyu",     ad: "Koyu",        renk: "#1d1a14" },
]
// Yatay seçenek şeritlerindeki kaydırma çubuğu GİZLENİR (kaydırma çalışmaya devam eder).
// Satır içi stil sözde-öğe alamadığı için tek seferlik bir <style> enjekte edilir.
const SERIT_STIL_ID = "vukuf-serit-stil"
function seritStiliKur() {
  if (typeof document === "undefined" || document.getElementById(SERIT_STIL_ID)) return
  const el = document.createElement("style")
  el.id = SERIT_STIL_ID
  el.textContent = `.vukuf-serit{scrollbar-width:none;-ms-overflow-style:none}
.vukuf-serit::-webkit-scrollbar{width:0;height:0;display:none}`
  document.head.appendChild(el)
}

const SON_RENK_ANAHTAR = "vukuf-gorsel-son-renkler"
export const sonRenkleriOku = () => {
  try {
    const d = JSON.parse(localStorage.getItem(SON_RENK_ANAHTAR) || "[]")
    return Array.isArray(d) ? d.filter(x => typeof x === "string" && /^#[0-9a-fA-F]{6}$/.test(x)).slice(0, 5) : []
  } catch { return [] }
}
export const sonRenkEkle = (renk) => {
  try {
    const yeni = [renk, ...sonRenkleriOku().filter(r => r.toLowerCase() !== renk.toLowerCase())].slice(0, 5)
    localStorage.setItem(SON_RENK_ANAHTAR, JSON.stringify(yeni))
    return yeni
  } catch { return sonRenkleriOku() }
}

// ── EKSİK GLİF EMNİYETİ ───────────────────────────────────────────────────────
// Aktif fontta karşılığı OLMAYAN işaretler canvas'ta boş kutu (□ notdef) çiziyor.
// Sadece İŞARET/HAREKE aralıklarına bakılır — taban harflere ASLA dokunulmaz.
// Ölçüm: "ا" + işaret genişliği ile notdef genişliği (U+FFFF) karşılaştırılır;
// notdef glifleri aynı ilerleme genişliğini paylaştığı için bu ayrım güvenilir.
const ISARET_ARALIK = [
  [0x0610, 0x061A], [0x064B, 0x065F], [0x0670, 0x0670],
  [0x06D6, 0x06ED], [0x08D3, 0x08FF], [0xFBB2, 0xFBC1],
]
const isaretMi = (cp) => ISARET_ARALIK.some(([a, b]) => cp >= a && cp <= b)
// Yukaridaki araliklar icinde kalan ama BIRLESEN OLMAYAN kodlar. Bunlarin ilerleme
// genisligi TASARIM GEREGI sifir degildir (Unicode kategorisi Mn disi: Lm/So/Cf/Sk),
// bu yuzden asagidaki genislik testinden MUAF tutulurlar. Muaf tutulmazsa gercek
// Kur'an isaretleri atilir: olcumde U+06E5/06E6 (kucuk vav/ya) Yusuf 12:75'ten
// dusuyordu. Liste Unicode kategorilerinden uretildi, elle yazilmadi.
const GENIS_ISARET = new Set([
  0x06DD, 0x06DE, 0x06E5, 0x06E6, 0x06E9, 0x08E2,
  0xFBB2, 0xFBB3, 0xFBB4, 0xFBB5, 0xFBB6, 0xFBB7, 0xFBB8, 0xFBB9, 0xFBBA, 0xFBBB,
  0xFBBC, 0xFBBD, 0xFBBE, 0xFBBF, 0xFBC0, 0xFBC1,
])
function eksikGlifAt(ctx, metin, fontStr, pxBoy) {
  if (!metin) return metin
  const eski = ctx.font
  ctx.font = fontStr
  const bas = ctx.measureText("\u0627").width
  // GENISLIK KURALI - iki ayri arizayi tek testle yakalar:
  //   1) notdef kutusu: font o isareti hic tanimiyor.
  //   2) YER TUTUCU (daire): font isareti taniyor ama hepsini ayni daire glifiyle ciziyor.
  //      KFGQPC v4'te 13 kod (U+0610-0614, 0616, 0618, 0619, 0659-065B, 065D, 065F)
  //      TEK bir konturu paylasiyor (fontTools ile olculdu). Bu gercek bir kontur
  //      oldugu icin "bos mu" testi onu YAKALAMAZ; eski kod bu yuzden caresiz kalip
  //      ciktiyi zorla me_quran'a ceviriyordu.
  // Ayrim net: gercek birlesen isaretin ilerleme genisligi 0'dir, arizalilar em'in
  // dortte birinden genistir. Tarayicida 60px ile olculdu:
  //   gercek isaretler = 0 | yer tutucu = 42.2 | notdef = 30 (KF) / 44.4 (MQ)
  const esik = (pxBoy || 60) * 0.25
  let cikti = ""
  for (const c of metin) {
    const cp = c.codePointAt(0)
    if (!isaretMi(cp) || GENIS_ISARET.has(cp)) { cikti += c; continue }
    const ek = ctx.measureText("\u0627" + c).width - bas
    if (ek > esik) continue                     // notdef VEYA yer tutucu -> at
    cikti += c
  }
  ctx.font = eski
  return cikti
}

// ════════════════════════════════════════════════════════════════
// VİDEO — süre, efekt ve hareket seçenekleri + parçacık motoru
// ════════════════════════════════════════════════════════════════
const SURELER = [
  { id: 6,  ad: "6 sn" },
  { id: 10, ad: "10 sn" },
  { id: 15, ad: "15 sn" },
  { id: 20, ad: "20 sn" },
]
// Videonun süresine yayılan Ken Burns hareketleri + izleme modunun sürekli
// hareketleri (gezinti / yakınlaş-uzaklaş / sonsuz akış — hızı seçilebilir).
const HAREKETLER = [
  { id: "yok",       ad: "Sabit" },
  { id: "yakinlas",  ad: "Yakınlaş" },
  { id: "uzaklas",   ad: "Uzaklaş" },
  { id: "kaydir",    ad: "Kaydır" },
  ...SAHNE_HAREKETLERI.filter(h => ["gezinti", "nefes", "akis"].includes(h.id)),
]
const SAHNE_HAREKETI = new Set(["gezinti", "nefes", "akis"])
// Fotoğrafta efektler DONDURULMUŞ bir an olarak çizilir (bu saniyedeki hâli)
const FOTO_EFEKT_ANI = 4.2

// Parçacık (hava) ve ışık efektleri artık data/izlemeSahne.js'te — izleme modu ile
// görsel/video AYNI motoru kullanıyor (7 Ekim 2026).

// Arka planın hareketi (Ken Burns). t saniye, sure toplam süre.
export function hareketKutusu(hareket, W, H, t, sure) {
  const o = sure > 0 ? Math.min(1, Math.max(0, t / sure)) : 0
  if (hareket === "yakinlas") { const z = 1 + 0.10 * o; return { sw: W / z, sh: H / z, sx: (W - W / z) / 2, sy: (H - H / z) / 2 } }
  if (hareket === "uzaklas")  { const z = 1.10 - 0.10 * o; return { sw: W / z, sh: H / z, sx: (W - W / z) / 2, sy: (H - H / z) / 2 } }
  if (hareket === "kaydir")   { const z = 1.08; const kx = (W - W / z) * o; return { sw: W / z, sh: H / z, sx: kx, sy: (H - H / z) / 2 } }
  return { sw: W, sh: H, sx: 0, sy: 0 }
}

/* KARARTMA — fotoğraf üstünde yazı okunsun diye dikey yumuşak perde. Dışa açık:
   izleme modu arka planı her karede kendisi çizdiği için karartmayı da (hava
   efektlerinin ALTINA) kendisi koyuyor; aynı işlev → iki yüzey ayrışmaz. */
export function karartmaCiz(ctx, W, H, karartma, koyuZemin = true) {
  const kar = KARARTMALAR.find(k => k.id === karartma) || KARARTMALAR[2]
  if (!(kar.guc > 0)) return
  const g = ctx.createLinearGradient(0, 0, 0, H)
  const renk = koyuZemin ? "0,0,0" : "255,255,255"
  g.addColorStop(0,   `rgba(${renk},${kar.guc * 0.75})`)
  g.addColorStop(0.5, `rgba(${renk},${kar.guc})`)
  g.addColorStop(1,   `rgba(${renk},${kar.guc * 0.85})`)
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H)
}

/* ── İŞARET RENGİ (8 Ekim 2026) ─────────────────────────────────────────────
   Kullanıcı: "izleme modu ya da görüntü modunda vakıf işaretleri gibi işaretleri
   renklendirmeyi seçenek olarak sunsak". Boyanan işaretler mushaf sayfasında
   boyananlarla AYNI: MushafKelime.jsx'teki VAKIF_CPS + CIM_CPS (o dosyada da
   değişirse burası birlikte güncellenmeli).
   YÖNTEM — işaretlerin yerini font belirliyor, bozulmasın diye satır yine TEK
   PARÇA çiziliyor; üstüne yalnız işaretlerden oluşan bir katman bindiriliyor:
   ayrı tuvale satır işaret renginde çizilir, işaretleri ÇIKARILMIŞ satır
   "destination-out" ile (ince bir kenar çizgisiyle birlikte) silinir → geriye
   yalnız işaretler kalır. Vakıf işaretleri genişlik kaplamadığı için iki çizim
   piksel piksel çakışıyor; harflerin dizilişi değişmiyor. */
export const ISARET_CPS = new Set([0x615, 0x617, 0x06D6, 0x06D8, 0x06D9, 0x06DB, 0x08D5, 0x08D6, 0x08D7, 0x08DE, 0x06DA])
export const ISARET_RENKLERI = [
  { id: "kapali", ad: "Kapalı" },
  { id: "mushaf", ad: "Mushaftaki gibi" },
  { id: "vurgu",  ad: "Vurgu rengi" },
  { id: "ozel",   ad: "Özel" },
]
// Seçimi gerçek renge çevirir (null = boyama yok). Koyu zeminde mushaf kırmızısı
// kaybolduğu için biraz açık tonu kullanılır.
export function isaretRengiCoz(secim, ozel, koyuZemin, vurguRenk) {
  if (!secim || secim === "kapali") return null
  if (secim === "mushaf") return koyuZemin ? "#ff7a66" : "#c0392b"
  if (secim === "vurgu") return vurguRenk
  if (secim === "ozel") return /^#[0-9a-fA-F]{6}$/.test(ozel || "") ? ozel : (koyuZemin ? "#ff7a66" : "#c0392b")
  return /^#[0-9a-fA-F]{6}$/.test(secim) ? secim : null
}
function isaretKatmaniCiz(ctx, satir, x, y, boy, font, renk) {
  const isaretsiz = [...satir].filter(c => !ISARET_CPS.has(c.codePointAt(0))).join("")
  if (isaretsiz === satir) return
  try {
    ctx.font = font
    const gen = Math.ceil(ctx.measureText(satir).width + boy * 2)
    const yuk = Math.ceil(boy * 3.2)
    const cv = document.createElement("canvas")
    cv.width = Math.max(1, gen); cv.height = Math.max(1, yuk)
    const c = cv.getContext("2d")
    c.font = font
    c.textAlign = "center"; c.textBaseline = "top"
    try { c.direction = "rtl" } catch { /* eski tarayıcı */ }
    const ox = gen / 2, oy = boy * 1.1
    c.fillStyle = renk
    c.fillText(satir, ox, oy)
    c.globalCompositeOperation = "destination-out"
    c.fillStyle = "#000"; c.strokeStyle = "#000"
    c.lineWidth = Math.max(1, boy * 0.04)            // kenar yumuşatma kalıntısı da silinsin
    c.lineJoin = "round"
    c.fillText(isaretsiz, ox, oy)
    c.strokeText(isaretsiz, ox, oy)
    ctx.drawImage(cv, x - ox, y - oy)
  } catch { /* boyanamazsa işaretler yazı renginde kalır */ }
}

// Metni verilen genişliğe göre satırlara böler. Arapça'da bitişme kelime İÇİNDE
// olduğundan boşluktan bölmek şekillenmeyi bozmaz.
function satirlaraBol(ctx, metin, maxW) {
  const cikti = []
  for (const paragraf of String(metin).split(/\n+/)) {
    const kelimeler = paragraf.trim().split(/\s+/).filter(Boolean)
    if (!kelimeler.length) continue
    let satir = kelimeler[0]
    for (let i = 1; i < kelimeler.length; i++) {
      const deneme = satir + " " + kelimeler[i]
      if (ctx.measureText(deneme).width <= maxW) satir = deneme
      else { cikti.push(satir); satir = kelimeler[i] }
    }
    cikti.push(satir)
  }
  return cikti
}

// ════════════════════════════════════════════════════════════════
// SAF ÇİZİM — bileşenden bağımsız, tek başına test edilebilir.
// ayar: { W,H, arka, cerceve, karartma, arapca, meal, kaynak, sureNo, rahle, arapcaFont,
//         guvenliUst, guvenliAlt }
// dönüş: { olcek }  (0.45'e kadar inip metni sığdırır; altına inmez)
// ════════════════════════════════════════════════════════════════
export async function gorselCiz(ctx, ayar) {
  const { W, H, arka, cerceve, karartma, arapca, meal, kaynak, arapcaFont, yaziRengi } = ayar
  // rozetNo: âyet numarası (varsa MushafAyetRozeti çizilir). secde: secde âyeti rozeti.
  // rozetImg: ön-yüklenmiş süsleme görseli (source-in ile boyanır).
  const rozetNo = ayar.rozetNo || null
  const secde = !!ayar.secde
  const rozetImg = ayar.rozetImg || null
  // sureNo: kaynak satırının üstüne SÛRE BAŞLIĞINDAKİ hat fontuyla sûre adı yazılır.
  const sureNo = Number(ayar.sureNo) || 0
  const rahle = !!ayar.rahle
  // rahleDipte: rahle yazı akışında değil, içerik kutusunun DİBİNDE ortalı durur
  // (izleme modu, 7 Ekim 2026). Yazı bloğu kalan alanda ortalanır.
  /* DİP SABİT (13 Ekim 2026, kullanıcı: "sûre adı ve kaynak metni takip ederek aşağı
     iniyor; rahleye yakın sabit kalsın. Rahleyi daha aşağı alıp kaynakları hemen
     üzerine alalım, değişen kısmı onun üstünden verelim; böylece âyet değişince
     yalnız rakam değişir."). Açıkken kaynak satırı + sûre adı + rahle bir DİP GRUBU
     olur: SABİT ölçekle çizilir ve çerçevenin dibine oturur. Âyet ve meal kalan
     alanda (kendi ölçeğiyle) ortalanır. İzleme modunda (rahleDipte) ve videoda açık;
     tek fotoğrafta eski akış sürer. */
  const dipSabit = ayar.dipSabit !== undefined ? !!ayar.dipSabit : !!ayar.rahleDipte
  const rahleDipte = rahle && !!ayar.rahleDipte && !dipSabit
  /* GÜVENLİ ALAN — yalnız TAM EKRANDA kullanılıyor (izleme modu). Arka plan bütün
     ekranı kaplamaya devam ediyor, çerçeve ve yazı bu paylar kadar içeri alınıyor;
     böylece çentiğin/ana ekran çizgisinin altında yazı kalmıyor ama kenarlarda
     siyah bant da oluşmuyor. Dosyaya kaydedilen görselde ikisi de 0. */
  const gUst = Math.max(0, Number(ayar.guvenliUst) || 0)
  const gAlt = Math.max(0, Number(ayar.guvenliAlt) || 0)
  const rozetVar = !!(rozetNo && rozetImg && rozetImg.complete && rozetImg.naturalWidth > 0)
  // katman: "hepsi" (fotoğraf) | "arka" (yalnız arka plan) | "on" (karartma+çerçeve+yazı).
  // Videoda arka plan hareket ettiği için iki katman AYRI ön-çizilir, her karede birleştirilir.
  const katman = ayar.katman || "hepsi"
  const arkaCiz = katman !== "on"
  const onCiz = katman !== "arka"
  const S = Math.min(W, H)
  ctx.clearRect(0, 0, W, H)

  // 1) ARKA PLAN
  if (!arkaCiz) { /* yalnız ön katman çizilecek */ }
  else if (arka.tip === "gorsel") {
    await new Promise(cz => {
      const im = new Image()
      im.crossOrigin = "anonymous"
      im.onload = () => {
        // "cover": oranı bozmadan kırparak doldur
        const o1 = im.width / im.height, o2 = W / H
        let sw = im.width, sh = im.height, sx = 0, sy = 0
        if (o1 > o2) { sw = im.height * o2; sx = (im.width - sw) / 2 }
        else { sh = im.width / o2; sy = (im.height - sh) / 2 }
        ctx.drawImage(im, sx, sy, sw, sh, 0, 0, W, H)
        cz()
      }
      im.onerror = () => { ctx.fillStyle = "#111417"; ctx.fillRect(0, 0, W, H); cz() }
      im.src = arka.src
    })
  } else {
    arka.ciz(ctx, W, H)
  }

  // 2) KARARTMA (fotoğraf üstünde yazının okunması için)
  const koyuZemin = arka.koyu !== false
  if (!onCiz) return { olcek: 1 }
  karartmaCiz(ctx, W, H, karartma, koyuZemin)

  // Kullanıcı bir renk seçtiyse o kullanılır; seçmediyse zemine göre otomatik.
  const yaziRenk  = yaziRengi || (koyuZemin ? "#f6f1e6" : "#1d1a14")
  const vurguRenk = koyuZemin ? "#d9b45a" : "#8a6a1f"
  // İşaret rengi (vakıf vb.) — ayar.isaretRenk: "kapali"|"mushaf"|"vurgu"|"ozel"|"#rrggbb"
  const isaretRenk = isaretRengiCoz(ayar.isaretRenk, ayar.isaretOzel, koyuZemin, vurguRenk)
  // SÜS RENKLERİ (13 Ekim 2026): sûre adı hattı (Arapça), kaynak satırı (Türkçe sûre
  // adı / âyet) ve rahle ayrı ayrı boyanabiliyor; seçilmemişse çerçeveyle aynı vurgu rengi.
  const renkMi = (c) => (/^#[0-9a-fA-F]{6}$/.test(c || "") ? c : null)
  const sureAdiRenk = renkMi(ayar.sureAdiRengi) || vurguRenk
  const kaynakRenk  = renkMi(ayar.kaynakRengi)  || vurguRenk
  const rahleRenk   = renkMi(ayar.rahleRengi)   || vurguRenk
  const solukRenk = koyuZemin ? "rgba(246,241,230,0.62)" : "rgba(29,26,20,0.62)"

  // 3) ÇERÇEVE
  const pay = S * 0.075
  const cx0 = pay, cy0 = pay + gUst, cx1 = W - pay, cy1 = H - pay - gAlt
  const kalin = Math.max(2, S * 0.0035)
  // ÖN BÖLÜM (14 Ekim 2026, video): "akis" → yalnız değişen kısım (âyet, rozet, meal);
  // "sabit" → yalnız çerçeve + dip grubu (kaynak, sûre adı, rahle). Videoda bu ikisi ayrı
  // çizilip sabit kısım âyet geçişinde SOLMADAN kalır; yalnız kaynaktaki rakam değişir.
  const onBolum = ayar.onBolum || "hepsi"
  const cizCerceve = onBolum === "akis" ? "yok" : cerceve
  ctx.save()
  ctx.strokeStyle = vurguRenk
  ctx.lineWidth = kalin
  if (cizCerceve === "ince") {
    ctx.strokeRect(cx0, cy0, cx1 - cx0, cy1 - cy0)
  } else if (cizCerceve === "cift") {
    ctx.strokeRect(cx0, cy0, cx1 - cx0, cy1 - cy0)
    ctx.lineWidth = kalin * 0.5
    const i = S * 0.018
    ctx.strokeRect(cx0 + i, cy0 + i, (cx1 - cx0) - 2 * i, (cy1 - cy0) - 2 * i)
  } else if (cizCerceve === "kose") {
    const u = S * 0.09
    ctx.beginPath()
    ctx.moveTo(cx0, cy0 + u); ctx.lineTo(cx0, cy0); ctx.lineTo(cx0 + u, cy0)
    ctx.moveTo(cx1 - u, cy0); ctx.lineTo(cx1, cy0); ctx.lineTo(cx1, cy0 + u)
    ctx.moveTo(cx1, cy1 - u); ctx.lineTo(cx1, cy1); ctx.lineTo(cx1 - u, cy1)
    ctx.moveTo(cx0 + u, cy1); ctx.lineTo(cx0, cy1); ctx.lineTo(cx0, cy1 - u)
    ctx.stroke()
  } else if (cizCerceve === "kemer") {
    // Mihrap kemeri: üstte kemer, altta düz kenarlar. Kemerin tepesi ÇERÇEVE KUTUSUNUN
    // içinde kalır (daha önce kutunun üstüne taşıp tuval kenarına dayanıyordu).
    const r = (cx1 - cx0) / 2
    const omuz = cy0 + Math.min(r * 0.9, (cy1 - cy0) * 0.55)
    ctx.beginPath()
    ctx.moveTo(cx0, cy1)
    ctx.lineTo(cx0, omuz)
    ctx.quadraticCurveTo(cx0, cy0, cx0 + r, cy0)
    ctx.quadraticCurveTo(cx1, cy0, cx1, omuz)
    ctx.lineTo(cx1, cy1)
    ctx.closePath()
    ctx.stroke()
  } else if (cizCerceve === "kartus") {
    const rr = S * 0.045
    const yol = () => {
      ctx.beginPath()
      if (ctx.roundRect) ctx.roundRect(cx0, cy0, cx1 - cx0, cy1 - cy0, rr)
      else ctx.rect(cx0, cy0, cx1 - cx0, cy1 - cy0)
    }
    ctx.save()
    ctx.fillStyle = koyuZemin ? "rgba(0,0,0,0.34)" : "rgba(255,255,255,0.46)"
    ctx.shadowColor = "rgba(0,0,0,0.35)"
    ctx.shadowBlur = S * 0.03
    yol(); ctx.fill()
    ctx.restore()
    ctx.lineWidth = kalin * 0.6
    yol(); ctx.stroke()
  }
  ctx.restore()

  // 4) METİN — tek ÖLÇEK ile hepsi birlikte küçülür/büyür (ikili arama)
  const icPay = cerceve === "yok" ? S * 0.10 : pay + S * 0.055
  // Kemerde üst kısım daralıyor → metin kutusu üstten ve yanlardan biraz daha içeri alınır
  const icPayUst = icPay + gUst + (cerceve === "kemer" ? S * 0.075 : 0)
  const icPayAlt = icPay + gAlt
  const kutuW = (W - icPay * 2) * (cerceve === "kemer" ? 0.9 : 1)
  const kutuH = H - icPayUst - icPayAlt
  const mealVar   = !!meal
  const kaynakVar = !!kaynak
  const sureAdiGlif = sureAdiGlifi(sureNo)
  const sureAdiVar  = !!sureAdiGlif

  // İŞARETLERİ FONT ÇİZER — overlay yok. Fontlar onarıldı: KFGQPC'de uni0656 konturu düzeltildi,
  // me_quran'a U+0615 (ط durağı) ve U+08D1..08DE Osmanlı işaretleri eklendi. Böylece vakıf,
  // uzatma ve tecvid işaretleri metnin İÇİNDE kalır; konumlarını fontun kendi GPOS'u yerleştirir
  // (harf sayarak tahmin etme ve kelimeden kelimeye kayma sorunu ortadan kalktı).
  // ÇIKTI, KULLANICININ SEÇTİĞİ FONTU KULLANIR.
  // Eskiden KFGQPC seçiliyken çıktı zorla me_quran'a çevriliyordu; gerekçe "KFGQPC
  // tecvid işaretlerini ◉ çiziyor" idi ve v4 onarımından SONRA geçerliliğini yitirdi.
  // Ölçüldü (fontTools, v4 dosyaları): iki fontta da işaretlerin BOŞ ya da paylaşılan
  // placeholder konturu yok; üstelik KFGQPC, me_quran'ın üst kümesi — me_quran'ın
  // olup KFGQPC'de olmayan TEK bir işaret bile yok, tersine KFGQPC'de 13 işaret fazla
  // (U+0610–0614 hürmet işaretleri, U+0618–061A küçük hareke, U+065C–065E).
  // Yani zorlama, kullanıcının seçimini ezmenin yanı sıra işaret KAYBETTİRİYORDU.
  // me_quran yalnızca YEDEK olarak kalıyor: seçili fontun çizemediği bir işaret varsa
  // (ör. Indopak Nastaleeq) tarayıcı o karakteri yedekten alır.
  // DİKKAT: yedek, jenerik aileden ÖNCE gelmeli. "X, serif, 'me_quran'" yazılırsa
  // `serif` her karakteri yakalar ve me_quran'a hiç sıra gelmez.
  const arapcaFontGorsel = (() => {
    const secili = String(arapcaFont || "").trim().replace(/,\s*(serif|sans-serif|monospace)\s*$/i, "")
    if (!secili) return "'me_quran', serif"
    if (/me_quran/i.test(secili)) return `${secili}, serif`
    return `${secili}, 'me_quran', serif`
  })()
  const arapcaFontYap = (b) => `${Math.round(b)}px ${arapcaFontGorsel}`
  const mealFontYap   = (b) => `${Math.round(b)}px Georgia, 'Times New Roman', serif`
  const kucukFontYap  = (b) => `600 ${Math.round(b)}px system-ui, -apple-system, sans-serif`

  // `arapca` iki biçimde gelebilir: DÜZ METİN (bugünkü KuranOkuma / OkumaEkrani) veya
  // KELİME DİZİSİ ({ar,...} nesneleri — eski sürüm). String()'e vermek diziyi
  // "[object Object],[object Object]" yaptığı için her iki biçim de burada metne çevrilir.
  const arapcaMetne = (a) => {
    if (typeof a === "string") return a
    if (Array.isArray(a)) {
      return a.map(k => (typeof k === "string" ? k : (k && (k.ar || k.metin || k.text)) || "")).filter(Boolean).join(" ")
    }
    if (a && typeof a === "object") return String(a.ar || a.metin || a.text || "")
    return ""
  }
  const arapcaHam = arapcaMetne(arapca).replace(/\s+/g, " ").trim()
  // Son süzgeç: SEÇİLİ FONTUN çizemediği (notdef/□) işaretleri at. Fonta göre kendini ayarlar.
  const arapcaVar = !!arapcaHam
  const arapcaGuvenli = arapcaVar ? eksikGlifAt(ctx, arapcaHam, arapcaFontYap(S * 0.078), S * 0.078) : ""

  const duzen = (olcek) => {
    const bloklar = []
    let toplam = 0
    if (arapcaVar) {
      const b = S * 0.078 * olcek
      ctx.font = arapcaFontYap(b)
      const sat = satirlaraBol(ctx, arapcaGuvenli, kutuW)
      const satirYuk = b * 1.95
      bloklar.push({ tip: "arapca", boy: b, satirlar: sat, yuk: sat.length * satirYuk, satirYuk })
      toplam += sat.length * satirYuk
    }
    // ÂYET SONU ROZETİ — Arapça'nın hemen altında, ortalı KÜÇÜK madalyon (+ secde âyeti rozeti)
    if (arapcaVar && rozetVar) {
      const ab = S * 0.078 * olcek
      const rh = ab * 0.82                // âyet rozeti: harf boyunun altında, küçük madalyon
      const gapUst = ab * 0.40
      const secdeYuk = secde ? ab * 0.62 : 0
      const yuk = gapUst + rh + secdeYuk
      bloklar.push({ tip: "rozet", yuk, rh, gapUst, secdeYuk, ab })
      toplam += yuk
    }
    if (arapcaVar && mealVar) { const bo = S * 0.045 * olcek; bloklar.push({ tip: "ayrac", yuk: bo }); toplam += bo }
    if (mealVar) {
      const b = S * 0.042 * olcek
      ctx.font = mealFontYap(b)
      const sat = satirlaraBol(ctx, meal, kutuW)
      const satirYuk = b * 1.52
      bloklar.push({ tip: "meal", boy: b, satirlar: sat, yuk: sat.length * satirYuk, satirYuk })
      toplam += sat.length * satirYuk
    }
    if ((kaynakVar || sureAdiVar) && !dipSabit) {
      const bo = S * 0.05 * olcek
      bloklar.push({ tip: "bosluk", yuk: bo })
      toplam += bo
    }
    /* SÛRE ADI KAYNAK SATIRININ SOLUNDA (7 Ekim 2026, kullanıcı: "dengeli durmaları
       için Arapça sûre ismini Türkçe ismin soluna alabilirsin"). Kaynak TEK satıra
       sığıyor ve hat yanına sığıyorsa ikisi aynı satırda: [hat] [Âl-i İmrân sûresi,
       104. âyet]. Sığmıyorsa (uzun kitap kaynağı, dar ekran) eski düzen: önce kaynak,
       altında hat. */
    let yanYana = false
    if (kaynakVar && sureAdiVar) {
      let b = S * 0.028 * olcek
      ctx.font = kucukFontYap(b)
      const sat = satirlaraBol(ctx, kaynak, kutuW)
      const o = sureAdiOlcusu(sureAdiGlif)
      if (sat.length === 1 && o && o.sag > o.sol) {
        // Dar ekranda (dikey telefon) satır biraz taşıyorsa ikisi birlikte en çok
        // %30 küçültülüp yine yan yana konuyor; daha fazlası gerekiyorsa alt alta.
        const tw0 = ctx.measureText(sat[0]).width
        const ham = (o.sag - o.sol) * b * 2.05 + b * 0.85 + tw0
        const f = Math.min(1, kutuW / ham)
        if (f >= 0.7) {
          b *= f
          ctx.font = kucukFontYap(b)
        }
        const tw = ctx.measureText(sat[0]).width
        const gb = b * 2.05                       // hattın puntosu (yazının ~2 katı)
        const gw = (o.sag - o.sol) * gb
        const ara = b * 0.85
        if (gw + ara + tw <= kutuW + 0.5) {
          const gAsc = o.asc * gb, gDesc = o.desc * gb
          const yuk = Math.max(b * 1.4, gAsc + gDesc) + b * 0.3
          bloklar.push({ tip: "kaynakHat", boy: b, metin: sat[0], tw, gb, gw, ara, gAsc, gDesc, sol: o.sol, yuk })
          toplam += yuk
          yanYana = true
        }
      }
    }
    /* Eski SIRA (sığmayınca): önce SÛRE BİLGİSİ (kaynak satırı), altında SÛRE ADI
       hattı, en altta RAHLE. Yani hat, rahlenin hemen üzerinde duruyor. */
    if (kaynakVar && !yanYana) {
      const b = S * 0.028 * olcek
      ctx.font = kucukFontYap(b)
      // Kaynak uzun olabilir (kitap · kısım yolu · sayfa) → KAÇ SATIR GEREKİYORSA o kadar
      // sarılır, KISALTILMAZ. Tamamı görünsün; sığmıyorsa genel ölçek zaten küçülür.
      const sat = satirlaraBol(ctx, kaynak, kutuW)
      const satirYuk = b * 1.4
      bloklar.push({ tip: "kaynak", boy: b, satirlar: sat, yuk: sat.length * satirYuk, satirYuk })
      toplam += sat.length * satirYuk
    }
    /* ⚠ YÜKSEKLİK: `actualBoundingBox*` TEK BAŞINA YETMİYOR. Sûre adı fontunun
       özel alan (PUA) glifleri için bu değerler çok küçük (hatta sıfıra yakın)
       dönebiliyor; blok neredeyse yüksekliksiz kalıyor ve glifin mürekkebi
       yukarı taşıp KAYNAK SATIRININ ÜSTÜNE BİNİYORDU (cihazda görüldü).
       Bu yüzden üç ölçünün EN BÜYÜĞÜ alınıyor: gerçek glif kutusu, fontun kendi
       ascent/descent'i ve punto oranından bir taban. Fazla boşluk kalması,
       üst üste binmeye göre kat kat iyi. */
    if (sureAdiVar && !yanYana) {
      const b = S * 0.062 * olcek
      const o = sureAdiOlcusu(sureAdiGlif)
      let asc, desc
      if (o) { asc = o.asc * b; desc = o.desc * b }
      else {
        ctx.font = `${Math.round(b)}px ${SURE_ADI_FONT}`
        const m = ctx.measureText(sureAdiGlif)
        asc = Math.max(m.actualBoundingBoxAscent || 0, m.fontBoundingBoxAscent || 0, b * 0.88)
        desc = Math.max(m.actualBoundingBoxDescent || 0, m.fontBoundingBoxDescent || 0, b * 0.26)
      }
      // Boşluğun ÇOĞU ÜSTTE: hat, üstteki sûre bilgisinden uzaklaşsın, altındaki
      // rahleye yakın dursun (kullanıcı isteği).
      const ustPay = b * 0.60
      const yuk = ustPay + asc + desc + b * 0.06
      bloklar.push({ tip: "sureAdi", boy: b, asc, desc, ustPay, yuk })
      toplam += yuk
    }
    if (rahle) {
      /* KÜÇÜLTÜLDÜ (7 Ekim 2026, kullanıcı: "rahle çok büyük kalıyor"). Eskiden
         min(kutu×0,34, kısa kenar×0,15)×ölçek idi; uzun ekranlarda ölçek 1,7'ye
         çıkınca kısa kenarın dörtte biri kadar oluyordu. Artık ölçeğin büyütmesi
         de sınırlı. */
      const gen = Math.min(kutuW * 0.2, S * 0.088) * Math.min(olcek, 1.15)
      const ara = rahleDipte ? S * 0.035 * olcek : S * 0.014 * olcek
      const yuk = gen * RAHLE_ORAN + ara                  // çizim + üstünde nefes
      bloklar.push({ tip: "rahle", gen, yuk, dipte: rahleDipte })
      toplam += yuk
    }
    return { bloklar, toplam }
  }

  // Üst sınır: çok uzun ekranlarda (tam ekran 9:19.5 gibi) yazı kutuda küçük kalmasın
  const enBoy = Math.max(W, H) / Math.min(W, H)
  const enBuyukOlcek = 1.35 + Math.min(0.35, Math.max(0, enBoy - 1.8) * 0.5)

  // DİP GRUBU (dipSabit): SABİT ölçek → âyetten âyete aynı boy ve aynı yer
  const DIP_OLCEK = 1.2
  const DIP_TIPLERI = new Set(["kaynakHat", "kaynak", "sureAdi", "rahle"])
  let dipBloklar = [], dipUst = 0
  if (dipSabit) {
    dipBloklar = duzen(DIP_OLCEK).bloklar.filter(b => DIP_TIPLERI.has(b.tip))
    const dipYuk = dipBloklar.reduce((t, b) => t + b.yuk, 0)
    // Rahle çerçeve çizgisine yakın: içerik kutusunun dibinden daha aşağıda
    const dipAlt = H - gAlt - (cerceve === "yok" ? S * 0.07 : pay + S * 0.022)
    dipUst = dipAlt - dipYuk
  }
  const akisSiniri = dipSabit ? Math.max(0, dipUst - S * 0.035 - icPayUst) : kutuH
  const akisOlc = (o) => {
    const d = duzen(o)
    if (!dipSabit) return d
    const bl = d.bloklar.filter(b => !DIP_TIPLERI.has(b.tip))
    return { bloklar: bl, toplam: bl.reduce((t, b) => t + b.yuk, 0) }
  }
  let alt = 0.45, ust = enBuyukOlcek, olcek = 0.45
  for (let i = 0; i < 26; i++) {
    const orta = (alt + ust) / 2
    if (akisOlc(orta).toplam <= akisSiniri) { olcek = orta; alt = orta } else ust = orta
  }
  const sonuc = akisOlc(olcek)
  // Dip grubu akışın sonuna "atla" işaretiyle eklenir: çizim y'yi dip grubunun üstüne taşır
  if (dipSabit && dipBloklar.length) sonuc.bloklar.push({ tip: "atla", hedef: dipUst, yuk: 0 }, ...dipBloklar)

  // Rahle dipteyse yazı bloğu, rahlenin üstünde KALAN alanda ortalanır.
  const dipRahle = sonuc.bloklar.find(b => b.tip === "rahle" && b.dipte)
  const akisToplam = dipSabit ? sonuc.bloklar.filter(b => !DIP_TIPLERI.has(b.tip)).reduce((t, b) => t + b.yuk, 0)
    : sonuc.toplam - (dipRahle ? dipRahle.yuk : 0)
  const akisH = dipSabit ? akisSiniri : kutuH - (dipRahle ? dipRahle.yuk : 0)
  // Dip sabitken yazı kalan alanda göz ortasına (biraz yukarı) yerleşir
  let y = Math.max(icPayUst, icPayUst + (akisH - akisToplam) * (dipSabit ? 0.46 : 0.5))
  ctx.textAlign = "center"
  ctx.textBaseline = "top"
  let dipBolumu = false
  for (const b of sonuc.bloklar) {
    if (b.tip === "atla") { y = b.hedef; dipBolumu = true; continue }
    if (dipSabit && onBolum === "akis" && dipBolumu) continue
    if (dipSabit && onBolum === "sabit" && !dipBolumu) continue
    if (b.tip === "arapca") {
      // Satır TEK PARÇA çizilir; vakıf/uzatma/tecvid işaretleri metnin içindedir ve
      // konumlarını fontun kendi şekillendirmesi belirler (bizim hesabımız yok).
      // TEK İSTİSNA özel okuyuş işaretleri (U+08D1 kasr / U+08D2 medd / U+08D9 nûn-i
      // sağîre): bunların font glifi GERÇEKTEN bir daire (Unicode adları LARGE CIRCLE
      // BELOW / LARGE ROUND DOT INSIDE CIRCLE BELOW), yani olduğu gibi bırakılırsa
      // görselde anlamsız bir yuvarlak çıkıyor. Mushaf sayfasında olduğu gibi metinden
      // ayrılıp yerine قصر / مد / ن kısaltması yazılıyor — konumu, sayfadakiyle AYNI
      // hesapla (taban harf sayımı → satır içinde yüzde) bulunuyor.
      ctx.font = arapcaFontYap(b.boy)
      ctx.fillStyle = yaziRenk
      ctx.textAlign = "center"; ctx.textBaseline = "top"
      try { ctx.direction = "rtl" } catch { /* eski tarayıcı */ }
      const ozelEtiketler = []            // {x, y, sembol} — satırlar çizildikten sonra basılır
      for (const st of b.satirlar) {
        const { metin: sade, ozeller } = ozelOkuyusAyikla(st)
        const ty = y + (b.satirYuk - b.boy) / 2
        ctx.fillText(sade, W / 2, ty)
        if (isaretRenk) {
          isaretKatmaniCiz(ctx, sade, W / 2, ty, b.boy, arapcaFontYap(b.boy), isaretRenk)
          ctx.font = arapcaFontYap(b.boy); ctx.fillStyle = yaziRenk
          ctx.textAlign = "center"; ctx.textBaseline = "top"
          try { ctx.direction = "rtl" } catch { /* yoksay */ }
        }
        if (ozeller.length) {
          // Satır ortalanmış çizildiği için sol kenar = merkez − genişlik/2.
          // `sol` yüzdesi soldan ölçülüyor (taban harf sayımı), doğrudan uygulanır.
          const gen = ctx.measureText(sade).width
          const solKenar = W / 2 - gen / 2
          for (const oz of ozeller) {
            ozelEtiketler.push({
              x: solKenar + ((oz.sol ?? 50) / 100) * gen,
              y: ty + b.boy * 1.02,       // harflerin hemen altı
              sembol: oz.sembol,
            })
          }
        }
        y += b.satirYuk
      }
      try { ctx.direction = "ltr" } catch { /* yoksay */ }
      if (ozelEtiketler.length) {
        // Renk: sayfadaki kırmızı yerine kartın VURGU rengi. Sebebi okunurluk —
        // kart arka planı koyu/renkli olabiliyor, sabit kırmızı orada kayboluyor.
        ctx.font = `${Math.round(b.boy * 0.34)}px 'Scheherazade New', 'me_quran', serif`
        ctx.fillStyle = vurguRenk
        ctx.textAlign = "center"; ctx.textBaseline = "top"
        try { ctx.direction = "rtl" } catch { /* yoksay */ }
        for (const e of ozelEtiketler) ctx.fillText(e.sembol, e.x, e.y)
        try { ctx.direction = "ltr" } catch { /* yoksay */ }
      }
    } else if (b.tip === "meal") {
      ctx.font = mealFontYap(b.boy)
      ctx.fillStyle = yaziRenk
      for (const st of b.satirlar) { ctx.fillText(st, W / 2, y + (b.satirYuk - b.boy) / 2); y += b.satirYuk }
    } else if (b.tip === "ayrac") {
      const g = ctx.createLinearGradient(W / 2 - kutuW * 0.22, 0, W / 2 + kutuW * 0.22, 0)
      g.addColorStop(0, "rgba(0,0,0,0)")
      g.addColorStop(0.5, vurguRenk)
      g.addColorStop(1, "rgba(0,0,0,0)")
      ctx.fillStyle = g
      ctx.fillRect(W / 2 - kutuW * 0.22, y + b.yuk / 2 - Math.max(1, S * 0.0016), kutuW * 0.44, Math.max(2, S * 0.0032))
      y += b.yuk
    } else if (b.tip === "kaynak") {
      ctx.font = kucukFontYap(b.boy)
      ctx.fillStyle = kaynakRenk
      for (const st of b.satirlar) { ctx.fillText(st, W / 2, y + (b.satirYuk - b.boy) / 2); y += b.satirYuk }
    } else if (b.tip === "sureAdi") {
      // Ölçülen glif kutusu blok içine ortalanıyor; taban çizgisi ona göre bulunuyor.
      ctx.font = `${Math.round(b.boy)}px ${SURE_ADI_FONT}`
      ctx.fillStyle = sureAdiRenk
      ctx.textAlign = "center"; ctx.textBaseline = "alphabetic"
      try { ctx.direction = "rtl" } catch { /* eski tarayıcı */ }
      ctx.fillText(sureAdiGlif, W / 2, y + b.ustPay + b.asc)
      try { ctx.direction = "ltr" } catch { /* yoksay */ }
      ctx.textBaseline = "top"
      y += b.yuk
    } else if (b.tip === "kaynakHat") {
      // [hat] [kaynak] — ikisi satırın ortasına göre dikeyde ortalı
      const toplamW = b.gw + b.ara + b.tw
      const x0 = W / 2 - toplamW / 2
      const orta = y + b.yuk / 2
      ctx.font = `${Math.round(b.gb)}px ${SURE_ADI_FONT}`
      ctx.fillStyle = sureAdiRenk
      ctx.textAlign = "center"; ctx.textBaseline = "alphabetic"
      try { ctx.direction = "rtl" } catch { /* eski tarayıcı */ }
      // Mürekkebin sol kenarı x0'a otursun: çizim noktası = x0 − sol taşma
      ctx.fillText(sureAdiGlif, x0 - b.sol * b.gb, orta + (b.gAsc - b.gDesc) / 2)
      try { ctx.direction = "ltr" } catch { /* yoksay */ }
      ctx.font = kucukFontYap(b.boy)
      ctx.fillStyle = kaynakRenk
      ctx.textAlign = "left"; ctx.textBaseline = "middle"
      ctx.fillText(b.metin, x0 + b.gw + b.ara, orta)
      ctx.textAlign = "center"; ctx.textBaseline = "top"
      y += b.yuk
    } else if (b.tip === "rahle") {
      const cizYuk = b.gen * RAHLE_ORAN
      const kalin = Math.max(1.1, S * 0.0018)
      if (b.dipte) {
        // İçerik kutusunun dibinde, ortalı — yazı akışını ilerletmez
        rahleCiz(ctx, W / 2, icPayUst + kutuH - cizYuk, b.gen, rahleRenk, kalin)
      } else {
        rahleCiz(ctx, W / 2, y + (b.yuk - cizYuk), b.gen, rahleRenk, kalin)
        y += b.yuk
      }
    } else if (b.tip === "rozet") {
      // Süslemeyi metin rengine boya (source-in) ve ortala; rakamı Scheherazade ile yaz.
      const rh = b.rh
      const rw = rh * ROZET_ORAN
      const rTop = y + b.gapUst
      try {
        const tmp = document.createElement("canvas")
        tmp.width = Math.max(1, Math.ceil(rw)); tmp.height = Math.max(1, Math.ceil(rh))
        const tctx = tmp.getContext("2d")
        tctx.drawImage(rozetImg, 0, 0, rw, rh)
        tctx.globalCompositeOperation = "source-in"
        tctx.fillStyle = yaziRenk
        tctx.fillRect(0, 0, rw, rh)
        ctx.drawImage(tmp, W / 2 - rw / 2, rTop)
      } catch { /* rozet çizilemedi → yalnız rakam */ }
      ctx.fillStyle = yaziRenk
      ctx.font = `900 ${Math.round(rh * 0.5)}px 'Scheherazade New', 'me_quran', serif`
      ctx.textAlign = "center"; ctx.textBaseline = "middle"
      try { ctx.direction = "rtl" } catch { /* yoksay */ }
      ctx.fillText(arapcaRakamGorsel(rozetNo), W / 2, rTop + rh / 2 + rh * 0.02)
      try { ctx.direction = "ltr" } catch { /* yoksay */ }
      ctx.textBaseline = "top"
      // SECDE ÂYETİ rozeti — küçük yıldız + "Secde âyeti" (renksiz)
      if (b.secdeYuk > 0) {
        const sf = Math.round(b.secdeYuk * 0.5)
        ctx.font = `600 ${sf}px system-ui, -apple-system, sans-serif`
        const etiket = "Secde âyeti"
        const tw = ctx.measureText(etiket).width
        const yr = sf * 0.62
        const ara = sf * 0.42
        const cy = rTop + rh + b.secdeYuk * 0.45
        const toplamW = yr * 2 + ara + tw
        const xBas = W / 2 - toplamW / 2
        yildizCiz(ctx, xBas + yr, cy, yr, yaziRenk)
        ctx.fillStyle = solukRenk
        ctx.textAlign = "left"; ctx.textBaseline = "middle"
        ctx.fillText(etiket, xBas + yr * 2 + ara, cy)
        ctx.textAlign = "center"; ctx.textBaseline = "top"
      }
      y += b.yuk
    } else {
      y += b.yuk
    }
  }

  // İMZA YOK — uygulamanın çıktıya imza koyma amacı yok (kullanıcı kararı).
  // Görselin altında duran tek süs, kaynak satırının altındaki rahle çizimidir.
  return { olcek }
}

// Tarayıcı video kaydını destekliyor mu? (iOS 14.3+ mp4, masaüstü webm)
const VIDEO_MIMELER = [
  "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
  "video/mp4",
  "video/webm;codecs=vp9,opus",
  "video/webm;codecs=vp8,opus",
  "video/webm",
]
function videoMime() {
  try {
    if (typeof MediaRecorder === "undefined") return null
    return VIDEO_MIMELER.find(m => MediaRecorder.isTypeSupported(m)) || null
  } catch { return null }
}

/* ── GALERİ VİDEOLARI (13 Ekim 2026) ─────────────────────────────────────────
   Sessiz, satır içi, döngülü <video>; iOS'ta oynayıp tuvale çizilebilmesi için
   görünmez bir kutuda DOM'a takılıyor. Karesi her çizimde "cover" kırpılarak
   kendi tuvaline basılıyor; sahne o tuvali resim gibi kullanıyor (hareket,
   geçiş ve efektler resimlerle aynı yoldan geçer). */
let videoKutusu = null
function sahneVideosu(url) {
  return new Promise(cz => {
    if (!videoKutusu || !videoKutusu.isConnected) {
      videoKutusu = document.createElement("div")
      videoKutusu.setAttribute("aria-hidden", "true")
      videoKutusu.style.cssText = "position:fixed;left:0;top:0;width:2px;height:2px;overflow:hidden;opacity:0;pointer-events:none"
      document.body.appendChild(videoKutusu)
    }
    const v = document.createElement("video")
    v.muted = true; v.defaultMuted = true; v.playsInline = true; v.loop = true; v.preload = "auto"
    v.setAttribute("muted", ""); v.setAttribute("playsinline", "")
    let bitti = false
    const son = (x) => { if (!bitti) { bitti = true; cz(x) } }
    v.onloadeddata = () => son(v)
    v.onerror = () => { v.remove(); son(null) }
    setTimeout(() => son(v.readyState >= 2 ? v : null), 10000)
    v.src = url
    videoKutusu.appendChild(v)
  })
}
/* SLAYT KONUMU — t anında hangi slayt (sira) ve ne zaman başladı (bas)? Saf işlev:
   hem kare çizimi hem hızlı dışa aktarmadaki video kare çözücüsü aynı sonucu kullanır.
   Kurallar izleme moduyla aynı (izlemeSahne.videoKalis). */
function slaytKonumu(t, slaytlar, cizelge, slaytKip, slaytVideo, slaytSn) {
  const n = slaytlar.length
  let idx = 0
  for (let i = 0; i < cizelge.length; i++) { if (t >= cizelge[i].bas) idx = i; else break }
  if (n <= 1) return { sira: 0, bas: 0 }
  if (slaytKip === "ayet" && slaytVideo === "ayetle") return { sira: idx, bas: (cizelge[idx] || { bas: 0 }).bas }
  if (slaytKip === "ayet") {
    // Video bir kez sonuna kadar oynar, bittiği anda (âyet ortası da olsa) sıradakine;
    // resim YENİ ÂYETTE değişir. Çizelge sabit → zaman çizgisi baştan yürütülür.
    let s = 0, b = 0
    for (let guv = 0; guv < 10000; guv++) {
      const x = slaytlar[s % n]
      let sonraki
      if (x.video) sonraki = b + videoKalis(x.sure)
      else {
        const k = cizelge.findIndex(c => c.bas > b + 0.01)
        if (k < 0) break                                   // son âyet: resim kalır
        sonraki = cizelge[k].bas
      }
      if (sonraki > t) break
      s++; b = sonraki
    }
    return { sira: s, bas: b }
  }
  // Süreyle: resim slaytSn kadar, video bir kez sonuna kadar
  const sureler = slaytlar.map(x => (x.video ? videoKalis(x.sure) : slaytSn))
  const tur = sureler.reduce((a, b) => a + b, 0) || 1
  const kac = Math.floor(t / tur)
  let kalan = t - kac * tur, i = 0
  while (i < n - 1 && kalan >= sureler[i]) { kalan -= sureler[i]; i++ }
  return { sira: kac * n + i, bas: t - kalan }
}

// Video karesi tuvale yerleşime göre (kapla / sığdır + bulanık zemin) — izleme moduyla aynı işlev
function videoKapla(cv, v, yerlesim) {
  videoCiz(cv.getContext("2d"), cv.width, cv.height, v, yerlesim)
}

export default function GorselOlustur({
  acik, kapat, arapca, meal, kaynak, secde = false, arapcaFont, theme, isMobile,
  // Video için (KuranOkuma doldurur; yoksa video sessiz kaydedilir)
  kariler, kariId, onKari, sesUrlAl, ayet, ayetListesiAl, azamiAyet = 25, sureBilgi,
}) {
  const canvasRef = useRef(null)
  // Âyet sonu rozeti süslemesi — bir kez yüklenir, canvas'a senkron çizilir.
  const rozetImgRef = useRef(null)
  const [varliklarSurum, setVarliklarSurum] = useState(0)   // görseller yüklenince yeniden çiz
  const [oran, setOran] = useState("4:5")
  const [arkaId, setArkaId] = useState("zumrut")
  // Galeri İZLEME MODUYLA ORTAK (IndexedDB): birinde eklenen resim öbüründe de görünür
  const [izAyar, izGuncelle] = useIzlemeAyar()
  const galeri = izAyar.izleme.galeri || []
  // Galeri (resim + video) — ızgarada TEK "Galerim" kutusu; düzenleme GaleriDuzenleyici'de (13 Ekim 2026)
  const galeriOgeleri = useGaleriOgeleri(acik ? galeri : [], galeriBlobu)
  const galeriUrl = useMemo(() => {
    const m = {}
    for (const [id, o] of Object.entries(galeriOgeleri)) m[id] = o.url
    return m
  }, [galeriOgeleri])
  const [galeriDuzenleAcik, setGaleriDuzenleAcik] = useState(false)
  const [cerceve, setCerceve] = useState("ince")
  const [karartma, setKarartma] = useState("orta")
  const [arapcaAcik, setArapcaAcik] = useState(!!arapca)
  const [mealAcik, setMealAcik] = useState(!!meal)
  const [kaynakAcik, setKaynakAcik] = useState(true)
  const [rahleAcik, setRahleAcik] = useState(true)
  const [gecerliGorseller, setGecerliGorseller] = useState([])   // dosyası GERÇEKTEN olanlar
  const [durum, setDurum] = useState("")                          // kullanıcıya kısa bilgi
  const [calisiyor, setCalisiyor] = useState(false)
  // Hazırlanan dosya (foto/video). Paylaşım ya da indirme kendiliğinden çalışmazsa
  // kullanıcı buradaki düğmeye basar → TAZE bir kullanıcı hareketiyle tekrar denenir.
  const [hazirDosya, setHazirDosya] = useState(null)   // {url, ad, tur, blob} | null
  const kaydirRef = useRef(null)                       // panelin dikey kaydırma kutusu
  const [uyari, setUyari] = useState("")
  const [yaziRengi, setYaziRengi] = useState(null)          // null = otomatik
  // Süs renkleri (13 Ekim 2026): sûre adı (Arapça) · kaynak (Türkçe) · rahle — null = otomatik
  const [susRenk, setSusRenk] = useState({ sureAdi: null, kaynak: null, rahle: null })
  // Vakıf vb. işaretlerin rengi (8 Ekim 2026) — "kapali" | "mushaf" | "vurgu" | "ozel"
  const [isaretRenk, setIsaretRenk] = useState("kapali")
  const [isaretOzel, setIsaretOzel] = useState("#e0503c")
  // ── VİDEO
  const [mod, setMod] = useState("foto")                     // "foto" | "video"
  const [videoSure, setVideoSure] = useState(6)
  // Efektler (izleme modundan aktarıldı) — fotoğrafta da, videoda da
  const [hava, setHava] = useState("yok")
  const [isik, setIsik] = useState("yok")
  const [hiz, setHiz] = useState("yavas")
  const [hareket, setHareket] = useState("yakinlas")
  /* SLAYT GÖSTERİSİ (13 Ekim 2026) — yalnız videoda, galeride 2+ resim varken.
     "kapali": seçili tek arka plan · "sure": her resim belirli süre · "ayet": her
     âyette (video parçasında) sıradaki resim. Açıkken arka plan galeriden sırayla gelir. */
  // Slayt ayarları izleme moduyla ORTAK (Galerim düzenleyicisinde değişiyor)
  const izOrtak = izAyar.izleme
  const slaytKip = izOrtak.slaytKip === "ayet" ? "ayet" : "sure"
  const slaytSn = Math.max(1, Number(izOrtak.slaytSure) || 15)
  const slaytGecis = izOrtak.slaytGecis || "solma"
  const slaytVideo = izOrtak.slaytVideo === "ayetle" ? "ayetle" : "sonuna"
  const videoHareket = izOrtak.videoHareket === "resim" ? "resim" : "sabit"
  const videoYerlesim = ["kapla", "sigdir"].includes(izOrtak.videoYerlesim) ? izOrtak.videoYerlesim : "oto"
  // Video VARSAYILAN SESSİZ üretilir; kullanıcı isterse önizlemedeki ses ikonundan açar.
  const [sesAcik, setSesAcik] = useState(false)
  // DİNLEME (monitör): kayıt SIRASINDA sesin hoparlörden duyulup duyulmayacağı. Kapalı başlar —
  // çıktı alırken kullanıcıya zorla ses çalmaz. Kâri sesinin videoya KAYDEDİLMESİ ayrı ayardır
  // (yukarıdaki `sesAcik`); dinlemeyi kapatmak kaydı sessizleştirmez.
  const [dinle, setDinle] = useState(false)
  const [hizliSurer, setHizliSurer] = useState(false)          // hızlı (WebCodecs) dışa aktarma sürüyor
  const dinleRef = useRef(false)
  const monitorRef = useRef(null)
  useEffect(() => {
    dinleRef.current = dinle
    if (monitorRef.current) {
      try { monitorRef.current.gain.value = dinle ? 1 : 0 } catch { /* düğüm kapanmış */ }
    }
  }, [dinle])
  const [kapsam, setKapsam] = useState("tek")                // "tek"|3|5|10|"sayfa"|"sure"|"ozel"
  const [ozelBas, setOzelBas] = useState(1)                  // Özel kapsam: başlangıç âyeti
  const [ozelSon, setOzelSon] = useState(1)                  // Özel kapsam: bitiş âyeti
  // Özel kapsam kutularının YAZILAN metni ayrı tutulur. Eskiden her tuş vuruşunda sayı
  // kırpılıyordu (boş alan → 1, aralık dışı → ânında sınıra çekiliyor) ve kutuya yeni bir
  // âyet numarası YAZILAMIYORDU. Artık yazarken serbest; sınırlar odaktan çıkınca uygulanır.
  const [ozelBasMetin, setOzelBasMetin] = useState("1")
  const [ozelSonMetin, setOzelSonMetin] = useState("1")
  const ozelBasYaz = useCallback((n) => { setOzelBas(n); setOzelBasMetin(String(n)) }, [])
  const ozelSonYaz = useCallback((n) => { setOzelSon(n); setOzelSonMetin(String(n)) }, [])
  // Video çözünürlüğü: 720 (hızlı, varsayılan) veya 1080. Telefonda 1080×1920'yi 30 fps
  // çizmek zorlanabildiği için kısa kenar varsayılan 720.
  const [videoKalite, setVideoKalite] = useState(720)
  const iptalRef = useRef(null)                              // ses indirmelerini kesmek için
  const kayitDurumRef = useRef("hazir")
  const parcaCvRef = useRef(null)                            // parça (âyet) yazı katmanı — değişen kısım
  const parcaSabitCvRef = useRef(null)                       // parçanın sabit kısmı: çerçeve + kaynak + sûre adı + rahle
  const parcaIdxRef = useRef(-1)                             // o an çizili parça
  const cizelgeRef = useRef([])                              // [{bas, sure}] saniye
  const tamponRef = useRef([])                               // AudioBuffer | null
  const [kayitDurum, setKayitDurum] = useState("hazir")      // hazir | kayit | isleniyor
  const [ilerleme, setIlerleme] = useState(0)
  const [kalanSn, setKalanSn] = useState(0)
  const arkaCvRef = useRef(null)                             // ön-çizilmiş arka plan
  const slaytCvRef = useRef(null)                            // galeri sahnesi: [{ cv, video?, sure? }]
  const videoElRef = useRef([])                              // sahnedeki <video>'lar (temizlik için)
  const videoSiraRef = useRef(-1)                            // en son başa sarılan slayt sırası
  const hizliKareRef = useRef(null)                          // hızlı dışa aktarma: Map<slayt, çözülmüş kare tuvali>
  const videoElleriniBirak = useCallback(() => {
    for (const v of videoElRef.current) {
      try { v.pause(); v.removeAttribute("src"); v.load(); v.remove() } catch { /* yoksay */ }
    }
    videoElRef.current = []
  }, [])
  // Panel kapanınca / videodan çıkınca sahne videoları bırakılır
  useEffect(() => { if (!acik || mod !== "video") { videoElleriniBirak(); slaytCvRef.current = null } }, [acik, mod, videoElleriniBirak])
  useEffect(() => () => videoElleriniBirak(), [videoElleriniBirak])
  const onCvRef = useRef(null)                               // ön-çizilmiş yazı katmanı
  const rafRef = useRef(null)
  const parcacikRef = useRef([])
  const sesRef = useRef(null)
  const kayitIptalRef = useRef(false)
  const toplamSureRef = useRef(0)                            // sesli kayıtta gerçek süre
  useEffect(() => { kayitDurumRef.current = kayitDurum }, [kayitDurum])
  const mimeTuru = useMemo(() => videoMime(), [])
  const videoDestekli = !!mimeTuru && typeof HTMLCanvasElement !== "undefined"
    && typeof HTMLCanvasElement.prototype.captureStream === "function"
  const [sonRenkler, setSonRenkler] = useState(() => sonRenkleriOku())
  const ozelRenkMi = !!yaziRengi && !ONERILEN_RENKLER.some(r => r.renk === yaziRengi)

  // Panel her AÇILIŞTA içeriğe göre mantıklı başlasın.
  // KRİTİK: sıfırlama yalnızca KAPALI→AÇIK geçişinde yapılır. Daha önce bağımlılıklar
  // (arapca/meal gibi) proplardan geldiği için, üst bileşen bu propları yeni kimlikle
  // ürettiğinde effect tekrar çalışıp KULLANICININ AYARLARINI VARSAYILANA DÖNDÜRÜYORDU
  // (renk seçiliyor geri dönüyor, Video sekmesi Fotoğraf'a atıyordu). Artık açılış kenarı
  // bir ref ile izleniyor; panel açık kaldığı sürece hiçbir prop değişimi ayarları bozmaz.
  const acikOncekiRef = useRef(false)
  useEffect(() => {
    if (!acik) { acikOncekiRef.current = false; return }
    if (acikOncekiRef.current) return        // zaten açıktı → sıfırlama YOK
    acikOncekiRef.current = true
    seritStiliKur()
    setArapcaAcik(!!arapca); setMealAcik(!!meal); setUyari(""); setDurum("")
    setYaziRengi(null); setSonRenkler(sonRenkleriOku())
    setMod("foto"); setKayitDurum("hazir"); setIlerleme(0); kayitIptalRef.current = false
    setSesAcik(false)                          // her açılışta sessiz başla
    setDinle(false); dinleRef.current = false  // kayıt sırasında dinleme de kapalı başlar
    setKapsam("tek"); tamponRef.current = []; cizelgeRef.current = []
    setHazirDosya(null)
    if (ayet) { ozelBasYaz(ayet.ayetNo); ozelSonYaz(ayet.ayetNo) }
  }, [acik, arapca, meal, ayet, ozelBasYaz, ozelSonYaz])

  // ── PANELİN HER YERİNDEN KAYDIRMA ──────────────────────────────
  // Sorun: tekerlek yalnız düz yazı üstündeyken çalışıyordu. Sebebi iki katmanlı:
  //  1) Yatay seçenek şeritleri (`overflow-x:auto`) CSS gereği dikeyde de kaydırma kutusu
  //     sayılır (bir eksen `visible` değilse diğeri `auto`ya döner) → tekerlek orada "yutulur".
  //  2) Panel kilidi `.vukuf-panel *{overscroll-behavior:contain}` verdiği için bu yutulan
  //     kaydırma ÜST kutuya zincirlenemiyor.
  // Çözüm: kaydırma kutusuna pasif olmayan tek bir `wheel` dinleyicisi. Olayın geldiği yerden
  // yukarı yürünür; gerçekten dikey kaydırabilen bir iç kutu varsa karışılmaz, yoksa
  // kaydırma paneli kaydırır. Böylece tuval/önizleme, şeritler, düğmeler — her yer kaydırır.
  useEffect(() => {
    if (!acik) return
    const k = kaydirRef.current
    if (!k) return
    const tekerlek = (e) => {
      if (e.ctrlKey) return                                  // yakınlaştırma jesti
      const dy = e.deltaMode === 1 ? e.deltaY * 16
        : e.deltaMode === 2 ? e.deltaY * k.clientHeight : e.deltaY
      if (!dy) return
      let n = e.target
      while (n && n !== k) {
        if (n.nodeType === 1 && n.scrollHeight > n.clientHeight + 1) {
          const ov = getComputedStyle(n).overflowY
          const ustSinir = n.scrollHeight - n.clientHeight - 1
          if ((ov === "auto" || ov === "scroll") &&
              ((dy < 0 && n.scrollTop > 0) || (dy > 0 && n.scrollTop < ustSinir))) return
        }
        n = n.parentElement
      }
      const once = k.scrollTop
      k.scrollTop = Math.max(0, Math.min(k.scrollHeight - k.clientHeight, once + dy))
      if (k.scrollTop !== once && e.cancelable) e.preventDefault()
    }
    k.addEventListener("wheel", tekerlek, { passive: false })
    return () => k.removeEventListener("wheel", tekerlek)
  }, [acik])

  // Panel kapanınca / fotoğraf moduna dönünce ön-çizilmiş canvas'ları bırak.
  // iOS'ta canvas belleği sınırlı; tam çözünürlükte 2-3 offscreen canvas açık kalmasın.
  useEffect(() => {
    if (acik && mod === "video") return
    arkaCvRef.current = null
    parcaCvRef.current = null
    parcaIdxRef.current = -1
    tamponRef.current = []
    cizelgeRef.current = []
  }, [acik, mod])

  // Âyet rozeti süslemesi — bir kez yüklenir (canvas'a senkron çizmek için).
  // Yüklenince `varliklarSurum` artar → foto önizlemesi ve video katmanı yeniden çizilir.
  useEffect(() => {
    if (rozetImgRef.current) return
    let iptal = false
    const rim = rozetGorseliUret()
    rim.onload = () => { rozetImgRef.current = rim; if (!iptal) setVarliklarSurum(v => v + 1) }
    rim.onerror = () => {}
    if (rim.complete && rim.naturalWidth > 0) rozetImgRef.current = rim
    return () => { iptal = true }
  }, [])

  // SÛRE ADI FONTU — canvas, CSS'teki @font-face'i KENDİLİĞİNDEN yüklemez; font
  // hazır değilken çizilirse yedek yazı tipiyle boş kutu çıkar ve bir daha yenilenmez.
  // Bu yüzden glif açıkça yüklenip bitince yeniden çizim tetikleniyor.
  // Font gelmezse sûre adı HİÇ çizilmiyor: PUA glifi yedek yazı tipinde boş kutu (□)
  // olarak çıkar ve görselin altında anlamsız bir kare kalırdı.
  const sureAdiNo = ayet?.sureNo || 0
  const [sureAdiHazir, setSureAdiHazir] = useState(false)
  useEffect(() => {
    const glif = sureAdiGlifi(sureAdiNo)
    if (!acik || !glif || typeof document === "undefined" || !document.fonts) { setSureAdiHazir(false); return }
    let iptal = false
    document.fonts.load(`64px ${SURE_ADI_FONT}`, glif)
      .then(yuzler => {
        if (iptal) return
        setSureAdiHazir(yuzler && yuzler.length > 0)
        setVarliklarSurum(v => v + 1)
      })
      .catch(() => { if (!iptal) setSureAdiHazir(false) })
    return () => { iptal = true }
  }, [acik, sureAdiNo])

  // Hangi hazır fotoğraflar GERÇEKTEN var? (dosya yoksa listede hiç görünmesin)
  useEffect(() => {
    if (!acik) return
    let iptal = false
    Promise.all(GORSELLER.map(g => new Promise(cz => {
      const im = new Image()
      im.onload = () => cz(g)
      im.onerror = () => cz(null)
      im.src = g.src
    }))).then(sonuc => { if (!iptal) setGecerliGorseller(sonuc.filter(Boolean)) })
    return () => { iptal = true }
  }, [acik])

  // İlk galeri öğesi video ise fotoğraf için tek karesi çıkarılır
  const [kapakKaresi, setKapakKaresi] = useState(null)
  const ilkGaleriOge = galeri.length ? galeriOgeleri[galeri[0]] : null
  const ilkVideoUrl = ilkGaleriOge && ilkGaleriOge.video ? ilkGaleriOge.url : null
  useEffect(() => {
    if (!ilkVideoUrl) { setKapakKaresi(null); return }
    let iptal = false, uretilen = null
    videoKaresi(ilkVideoUrl, 0.5).then(u => { uretilen = u; if (!iptal) setKapakKaresi(u); else if (u) URL.revokeObjectURL(u) })
    return () => { iptal = true; if (uretilen) setTimeout(() => { try { URL.revokeObjectURL(uretilen) } catch { /* yoksay */ } }, 1500) }
  }, [ilkVideoUrl])
  // Galerim boşaldıysa (düzenleyicide hepsi kaldırıldı) varsayılan arka plana dön
  useEffect(() => { if (arkaId === "galeri" && !galeri.length) setArkaId("zumrut") }, [arkaId, galeri.length])

  const secili = useMemo(() => {
    // GALERİM: fotoğrafta ilk öğe (kapak); video ise ilk karesi
    if (arkaId === "galeri" && galeri.length) {
      const ilk = galeriOgeleri[galeri[0]]
      if (ilk && !ilk.video) return { id: "galeri", ad: "Galerim", src: ilk.url, koyu: true, tip: "gorsel" }
      if (ilk && ilk.video && kapakKaresi) return { id: "galeri", ad: "Galerim", src: kapakKaresi, koyu: true, tip: "gorsel" }
    }
    if (String(arkaId).startsWith("g:")) {
      const u = galeriUrl[arkaId.slice(2)]
      if (u) return { id: arkaId, ad: "Galeri", src: u, koyu: true, tip: "gorsel" }
    }
    const g = gecerliGorseller.find(x => x.id === arkaId)
    if (g) return { ...g, tip: "gorsel" }
    const d = DESENLER.find(x => x.id === arkaId) || DESENLER[0]
    return { ...d, tip: "desen" }
  }, [arkaId, galeriUrl, gecerliGorseller, galeri, galeriOgeleri, kapakKaresi])

  // Slayt etkin mi + yazı katmanının dayandığı arka plan (slaytta galeri resmi → koyu zemin)
  // GALERİ SAHNESİ (videoda): 2+ öğe → slayt; tek öğe video ise hareketli arka plan
  const slaytResimleri = useMemo(() => galeri.filter(id => galeriOgeleri[id]), [galeri, galeriOgeleri])
  const slaytAktif = mod === "video" && arkaId === "galeri" && (slaytResimleri.length >= 2
    || (slaytResimleri.length === 1 && !!galeriOgeleri[slaytResimleri[0]]?.video))
  const arkaEtkin = useMemo(() => (slaytAktif
    ? { id: "slayt", ad: "Galeri slaytı", src: secili.src, koyu: true, tip: "gorsel" }
    : secili), [slaytAktif, secili])

  // Hazır oranlar + cihazın tam ekranı
  const oranListesi = useMemo(() => [...ORANLAR, ekranOlcusuAl()], [])
  const olcuTam = oranListesi.find(o => o.id === oran) || oranListesi[0]
  // Videoda kısa kenar `videoKalite` olacak şekilde ölçeklenir (oran korunur, çift sayı)
  const olcu = useMemo(() => {
    if (mod !== "video") return olcuTam
    const kisa = Math.min(olcuTam.w, olcuTam.h)
    const k = videoKalite / kisa
    if (k >= 1) return olcuTam
    const cift = (n) => Math.round(n * k / 2) * 2
    return { ...olcuTam, w: cift(olcuTam.w), h: cift(olcuTam.h) }
  }, [olcuTam, mod, videoKalite])

  // ── ÇİZİM ───────────────────────────────────────────────────
  // Ortak ayar paketi (foto ve video aynı görünümü kullansın)
  const cizAyari = useCallback((ek) => ({
    W: olcu.w, H: olcu.h,
    arka: arkaEtkin,
    cerceve, karartma,
    arapca: arapcaAcik ? arapca : null,
    meal:   mealAcik   ? meal   : null,
    kaynak: kaynakAcik ? kaynak : null,
    // Sûre adı hattı kaynak satırının parçası — kaynak kapatılırsa o da kapanır.
    sureNo: kaynakAcik && sureAdiHazir ? sureAdiNo : 0,
    rahle: rahleAcik,
    // Videoda âyetler akarken kaynak + sûre adı + rahle dipte sabit kalır (yalnız rakam değişir)
    dipSabit: mod === "video",
    arapcaFont,
    yaziRengi,
    isaretRenk, isaretOzel,
    sureAdiRengi: susRenk.sureAdi, kaynakRengi: susRenk.kaynak, rahleRengi: susRenk.rahle,
    // Âyet sonu rozeti (foto: prop'tan; video: parça kendi rozetNo'sunu ek ile geçer)
    rozetNo: arapcaAcik ? (ayet?.ayetNo || null) : null,
    secde: arapcaAcik ? secde : false,
    rozetImg: rozetImgRef.current,
    ...ek,
  }), [olcu, arkaEtkin, cerceve, karartma, arapca, meal, kaynak, arapcaAcik, mealAcik, kaynakAcik, rahleAcik, sureAdiNo, sureAdiHazir, arapcaFont, yaziRengi, isaretRenk, isaretOzel, susRenk, ayet, secde, varliklarSurum, mod])

  // ÇİZİM SIRA NUMARASI — `gorselCiz` asenkron (arka plan fotoğrafını bekliyor). Art arda
  // ayar değiştirilince ESKİ çizim SONRA bitip canvas'a basabiliyordu: kullanıcı ayarı
  // uygulanmış görüp bir an sonra ESKİ hâle dönmüş görüyordu. Çözüm: her çizim önce
  // GİZLİ bir canvas'a yapılır; bitince hâlâ en güncel çizim ise ekrana kopyalanır.
  const cizNoRef = useRef(0)
  const ciz = useCallback(async () => {
    const cv = canvasRef.current
    if (!cv) return
    const benim = ++cizNoRef.current
    const W = olcu.w, H = olcu.h
    const gizli = document.createElement("canvas")
    gizli.width = W; gizli.height = H
    let olcek
    if (hava !== "yok" || isik !== "yok") {
      // EFEKTLİ: arka plan → karartma → ışık → hava → yazı (izleme modunun sırası;
      // kar/yağmur karartmanın altında solmasın, yazının altında kalsın)
      const g = gizli.getContext("2d")
      await gorselCiz(g, cizAyari({ katman: "arka" }))
      if (benim !== cizNoRef.current) return
      karartmaCiz(g, W, H, karartma, arkaEtkin.koyu !== false)
      isikCiz(g, isik, W, H, FOTO_EFEKT_ANI)
      havaCiz(g, hava, havaKur(hava, W, H), W, H, FOTO_EFEKT_ANI)
      const on = document.createElement("canvas"); on.width = W; on.height = H
      olcek = (await gorselCiz(on.getContext("2d"), cizAyari({ katman: "on", karartma: "yok" }))).olcek
      g.drawImage(on, 0, 0)
    } else {
      olcek = (await gorselCiz(gizli.getContext("2d"), cizAyari())).olcek
    }
    if (benim !== cizNoRef.current || !canvasRef.current) return   // eskimiş çizim → basma
    cv.width = W; cv.height = H
    cv.getContext("2d").drawImage(gizli, 0, 0)
    setUyari(olcek <= 0.46
      ? "Metin uzun olduğu için yazı en küçük okunur boyuta indi. Daha kısa bir bölüm seçerseniz daha güzel görünecektir."
      : "")
  }, [olcu, cizAyari, hava, isik, karartma, arkaEtkin])

  // ── VİDEO PARÇALARI ────────────────────────────────────────────
  // Tek âyet → tek parça. Çoklu seçimde KuranOkuma'nın listesi kullanılır
  // (gerekirse başa besmele eklenmiş, uzun sûrelerde kırpılmış hâlde).
  const videoParcalari = useMemo(() => {
    const tek = [{ tip: "ayet", arapca, meal, etiket: kaynak, ayetNo: ayet?.ayetNo || null, secde }]
    if (mod !== "video" || !ayet || !ayetListesiAl || kapsam === "tek") return tek
    try {
      const adet = kapsam === "sure" ? "hepsi" : kapsam    // "sayfa" ve "ozel" aynen geçer
      // Kutular serbest yazılabildiği için buradaki değerler geçici olarak aralık dışı
      // olabilir; önizleme hiçbir durumda geçersiz aralık istemesin diye burada kırpılır.
      const enCokAyet = sureBilgi?.ayetSayisi || 286
      const bas = kapsam === "ozel" ? Math.min(Math.max(1, ozelBas || 1), enCokAyet) : ayet.ayetNo
      const son = kapsam === "ozel"
        ? Math.min(Math.max(bas, ozelSon || bas), Math.min(enCokAyet, bas + azamiAyet - 1))
        : ozelSon
      const { liste } = ayetListesiAl(ayet.sureNo, bas, adet, son)
      return liste && liste.length ? liste : tek
    } catch { return tek }
  }, [mod, ayet, ayetListesiAl, kapsam, ozelBas, ozelSon, arapca, meal, kaynak, secde, sureBilgi, azamiAyet])

  // Bir parçanın YAZI katmanını çizer. katman:"on" görsel yüklemediği için gorselCiz
  // gövdesi baştan sona SENKRON çalışır → beklemeye gerek yok (rAF içinde kullanılabilir).
  const parcaCiz = useCallback((idx) => {
    const p = videoParcalari[idx]
    if (!p) return
    let cv = parcaCvRef.current
    if (!cv || cv.width !== olcu.w || cv.height !== olcu.h) {
      cv = document.createElement("canvas"); cv.width = olcu.w; cv.height = olcu.h
      parcaCvRef.current = cv
    }
    // SABİT BÖLÜM (14 Ekim 2026, kullanıcı: "süs kısımları ve âyet ismi yazan kısım efekt
    // ile sonraki âyette değişmesin, sabit kalsın, sadece rakam değişebilir"): çerçeve ve
    // dip grubu ayrı tuvale çizilir, videoKare onu soldurmadan basar.
    let sabitCv = parcaSabitCvRef.current
    if (!sabitCv || sabitCv.width !== olcu.w || sabitCv.height !== olcu.h) {
      sabitCv = document.createElement("canvas"); sabitCv.width = olcu.w; sabitCv.height = olcu.h
      parcaSabitCvRef.current = sabitCv
    }
    const ortak = {
      katman: "on",
      karartma: "yok",                     // karartma videoKare'de, efektlerin altında
      arapca: arapcaAcik ? p.arapca : null,
      meal:   mealAcik   ? p.meal   : null,
      kaynak: kaynakAcik ? p.etiket : null,
      rozetNo: arapcaAcik ? (p.ayetNo || null) : null,
      secde: arapcaAcik ? !!p.secde : false,
    }
    const sabitG = sabitCv.getContext("2d")
    // Söz döndürür: hızlı dışa aktarma yazı katmanı hazır olmadan kareyi çizmesin
    const soz = Promise.all([
      gorselCiz(cv.getContext("2d"), cizAyari({ ...ortak, onBolum: "akis" })),
      gorselCiz(sabitG, cizAyari({ ...ortak, onBolum: "sabit" })),
    ])
    parcaIdxRef.current = idx
    return soz
  }, [videoParcalari, olcu, cizAyari, arapcaAcik, mealAcik, kaynakAcik])

  // Zaman çizelgesi: ses yüklüyse gerçek süreler, değilse eşit paylaştırma
  const cizelgeKur = useCallback(() => {
    const n = videoParcalari.length
    const tamponlar = tamponRef.current
    const cizelge = []
    let t = 0
    for (let i = 0; i < n; i++) {
      const b = tamponlar[i]
      const sr = b && b.duration > 0
        ? b.duration + 0.35                                   // âyetler arası küçük nefes
        : Math.max(2.4, (n > 1 ? Math.max(videoSure, n * 3) : videoSure) / n)
      cizelge.push({ bas: t, sure: sr })
      t += sr
    }
    cizelgeRef.current = cizelge
    return t
  }, [videoParcalari, videoSure])

  // ── VİDEO: arka plan katmanını ÖN-ÇİZ (her karede yeniden çizmek pahalı) ──────
  const katmanlariHazirla = useCallback(async () => {
    const benim = ++cizNoRef.current
    const W = olcu.w, H = olcu.h
    const arkaCv = document.createElement("canvas"); arkaCv.width = W; arkaCv.height = H
    await gorselCiz(arkaCv.getContext("2d"), cizAyari({ katman: "arka" }))
    if (benim !== cizNoRef.current) return toplamSureRef.current || videoSure   // eskimiş
    // Galeri sahnesi: her RESİM ayrı ön-çizilir (karede yalnız kopyalanır); her VİDEO
    // sessiz bir <video> olarak hazırlanır, karesi her çizimde kendi tuvaline basılır.
    videoElleriniBirak()
    let slaytlar = null
    if (slaytAktif) {
      slaytlar = []
      for (const id of slaytResimleri) {
        const o = galeriOgeleri[id]
        if (!o) continue
        const cv = document.createElement("canvas"); cv.width = W; cv.height = H
        if (o.video) {
          const v = await sahneVideosu(o.url)
          if (benim !== cizNoRef.current) { try { v && v.pause() } catch { /* yoksay */ } return toplamSureRef.current || videoSure }
          if (!v) continue
          videoElRef.current.push(v)
          slaytlar.push({ cv, video: v, sure: v.duration || 0, url: o.url })
        } else {
          await gorselCiz(cv.getContext("2d"), cizAyari({
            katman: "arka", arka: { id: "g:" + id, ad: "Galeri", src: o.url, koyu: true, tip: "gorsel" },
          }))
          if (benim !== cizNoRef.current) return toplamSureRef.current || videoSure
          slaytlar.push({ cv })
        }
      }
      if (!slaytlar.length) slaytlar = null
    }
    slaytCvRef.current = slaytlar
    videoSiraRef.current = -1
    arkaCvRef.current = arkaCv
    parcacikRef.current = havaKur(hava, W, H)
    parcaIdxRef.current = -1
    parcaCiz(0)
    const toplam = cizelgeKur()
    return toplam
  }, [olcu, cizAyari, hava, parcaCiz, cizelgeKur, videoSure, slaytAktif, slaytResimleri, galeriOgeleri, videoElleriniBirak])

  // Tek kare: arka plan (hareketli) → parçacıklar → o anki âyetin yazı katmanı
  const videoKare = useCallback((ctx, t, toplam) => {
    const W = olcu.w, H = olcu.h
    const arkaCv = arkaCvRef.current
    if (!arkaCv) return
    ctx.clearRect(0, 0, W, H)

    // Hangi âyetteyiz? (slayt "âyetle" kipinde resim de buna göre seçilir)
    const cizelge = cizelgeRef.current
    let idx = 0
    for (let i = 0; i < cizelge.length; i++) { if (t >= cizelge[i].bas) idx = i; else break }

    // Video slaytı varsayılan SABİT (çekim zaten hareketli); "resim" seçiliyse resimlerle aynı.
    // Sığdırılmış (yönü ekrana uymayan) videoya hareket uygulanmaz — izleme moduyla aynı.
    const arkaCizici = (kaynakCv, faz, video) => () => {
      if (video && (videoHareket !== "resim" || videoSigar(video.videoWidth, video.videoHeight, W, H, videoYerlesim))) ctx.drawImage(kaynakCv, 0, 0, W, H)
      else if (SAHNE_HAREKETI.has(hareket)) {
        resimCiz(ctx, W, H, { img: kaynakCv, w: W, h: H }, hareket, hiz, t, faz)
      } else {
        const k = hareketKutusu(hareket, W, H, t, toplam)
        ctx.drawImage(kaynakCv, k.sx, k.sy, k.sw, k.sh, 0, 0, W, H)
      }
    }
    const slaytlar = slaytCvRef.current
    // Hızlı dışa aktarmada video kareleri çözücüden gelir (slayt → tuval); <video> öğelerine dokunulmaz
    const hizliKareler = hizliKareRef.current
    if (slaytlar && slaytlar.length) {
      const n = slaytlar.length
      const { sira, bas } = slaytKonumu(t, slaytlar, cizelge, slaytKip, slaytVideo, slaytSn)
      const i = sira % n, onceki = (sira - 1 + n) % n
      // Video denetimi: yeni slaytın videosu baştan başlar; ekranda olmayanlar durur
      if (!hizliKareler && sira !== videoSiraRef.current) {
        videoSiraRef.current = sira
        const yeni = slaytlar[i]
        // "Âyetle değişsin" seçiliyse video tekrar geldiğinde KALDIĞI YERDEN sürer
        const kaldigiYerden = slaytKip === "ayet" && slaytVideo === "ayetle" && sira > 0
        if (yeni.video && !kaldigiYerden) { try { yeni.video.currentTime = 0 } catch { /* yoksay */ } }
      }
      const gecisVar = n > 1 && sira > 0 && (t - bas) < GECIS_SN
      if (!hizliKareler) slaytlar.forEach((x, j) => {
        if (!x.video) return
        const gorunur = j === i || (gecisVar && j === onceki)
        // Slaytta video başa sarmaz; tek öğede ya da "âyetle değişsin"de döngü sürer
        const dongu = n < 2 || (slaytKip === "ayet" && slaytVideo === "ayetle")
        if (x.video.loop !== dongu) x.video.loop = dongu
        if (gorunur && x.video.paused && !x.video.ended) { const pr = x.video.play(); if (pr && pr.catch) pr.catch(() => {}) }
        else if (!gorunur && !x.video.paused) x.video.pause()
      })
      const hazirla = (x) => {
        if (x.video) {
          const kaynak = hizliKareler ? hizliKareler.get(x) : x.video
          if (kaynak) videoKapla(x.cv, kaynak, videoYerlesim)
        }
        return x.cv
      }
      if (gecisVar) {
        gecisCiz(ctx, W, H, arkaCizici(hazirla(slaytlar[onceki]), onceki * 1.7, slaytlar[onceki].video), arkaCizici(hazirla(slaytlar[i]), i * 1.7, slaytlar[i].video), slaytGecis, (t - bas) / GECIS_SN, sira)
      } else arkaCizici(hazirla(slaytlar[i]), i * 1.7, slaytlar[i].video)()
    } else {
      arkaCizici(arkaCv, 0)()
    }
    // Sıra izleme moduyla aynı: karartma → ışık → hava → yazı
    karartmaCiz(ctx, W, H, karartma, arkaEtkin.koyu !== false)
    isikCiz(ctx, isik, W, H, t)
    havaCiz(ctx, hava, parcacikRef.current, W, H, t)
    if (idx !== parcaIdxRef.current) parcaCiz(idx)
    const cv = parcaCvRef.current
    if (!cv) return
    // Sabit kısım (çerçeve, kaynak, sûre adı, rahle) hiç solmaz; âyet geçişinde yalnız rakam değişir
    if (parcaSabitCvRef.current) ctx.drawImage(parcaSabitCvRef.current, 0, 0)

    // Geçiş: değişen kısım her âyette 0,45 sn içinde belirir, bitmeden 0,3 sn önce soluklaşır
    const c = cizelge[idx] || { bas: 0, sure: toplam }
    const yerel = t - c.bas
    const gir = Math.min(1, yerel / 0.45)
    const cik = Math.min(1, Math.max(0, (c.sure - yerel) / 0.3))
    ctx.globalAlpha = Math.max(0, Math.min(1, gir * cik))
    ctx.drawImage(cv, 0, 0)
    ctx.globalAlpha = 1
  }, [olcu, hareket, hiz, hava, isik, karartma, arkaEtkin, parcaCiz, slaytKip, slaytSn, slaytGecis, slaytVideo, videoHareket, videoYerlesim])

  // Döngünün kullandığı GÜNCEL işlevler — bağımlılık kirlenmesin diye ref üzerinden okunur
  const hazirlaRef = useRef(null)
  const kareRef = useRef(null)
  hazirlaRef.current = katmanlariHazirla
  kareRef.current = videoKare
  // Önizlemenin yeniden kurulmasını gerektiren AYAR imzası (ilkel değerlerden)
  const icerikImza = `${arapcaAcik ? 1 : 0}${mealAcik ? 1 : 0}${kaynakAcik ? 1 : 0}${rahleAcik ? 1 : 0}`
    + `|${kapsam}|${(arapca || "").length}|${(meal || "").length}|${kaynak || ""}`
    + `|${arkaEtkin.id}:${secili.src || ""}|${slaytAktif ? `${slaytKip}:${slaytVideo}:${videoHareket}:${videoYerlesim}:${slaytSn}:${slaytGecis}:${slaytResimleri.join(",")}` : "-"}|${cerceve}|${karartma}|${yaziRengi || "oto"}|${susRenk.sureAdi || "-"}${susRenk.kaynak || "-"}${susRenk.rahle || "-"}|${isaretRenk}${isaretRenk === "ozel" ? isaretOzel : ""}|${arapcaFont || ""}|${videoParcalari.length}|${varliklarSurum}`

  // Fontlar yüklenmeden çizersek canvas yedek fontla çizer → önce fonts.ready bekle
  useEffect(() => {
    if (!acik || mod !== "foto") return
    let iptal = false
    const calistir = () => { if (!iptal) ciz() }
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(calistir).catch(calistir)
    else calistir()
    // Moddan/ayardan çıkarken uçuşan çizimi GEÇERSİZ kıl (video karesinin üstüne basmasın)
    return () => { iptal = true; cizNoRef.current++ }
  }, [acik, mod, ciz])

  // ── VİDEO ÖNİZLEME DÖNGÜSÜ ──────────────────────────────────
  // ÖNEMLİ: bağımlılıkları SADE ve İLKEL tutulur. Önceki sürüm `katmanlariHazirla` /
  // `videoKare` / `videoParcalari` gibi her render'da kimliği değişebilen değerlere
  // bağlıydı; üst bileşen sık render ettiği için döngü sürekli yeniden kuruluyor ve
  // animasyon baştan başlıyordu → önizleme "sürekli açılıp kapanıyor" görünüyordu.
  // Artık işlevler REF üzerinden okunur; effect yalnızca gerçekten değişen ayarlarda kurulur.
  useEffect(() => {
    if (!acik || mod !== "video") return
    let iptal = false
    let baslangic = 0
    const cv = canvasRef.current
    if (!cv) return
    cv.width = olcu.w; cv.height = olcu.h
    const ctx = cv.getContext("2d")
    const baslat = async () => {
      const toplam = await hazirlaRef.current()
      if (iptal) return
      toplamSureRef.current = toplam
      const dongu = (zaman) => {
        if (iptal) return
        // Kayıt sırasında çizimi KAYIT döngüsü yapar; önizleme döngüsü karışmaz
        if (kayitDurumRef.current === "kayit") { rafRef.current = requestAnimationFrame(dongu); return }
        if (!baslangic) baslangic = zaman
        const t = (zaman - baslangic) / 1000
        const sure = toplamSureRef.current || 8
        kareRef.current(ctx, t % (sure + 0.6), sure)
        rafRef.current = requestAnimationFrame(dongu)
      }
      rafRef.current = requestAnimationFrame(dongu)
    }
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(baslat).catch(baslat)
    else baslat()
    return () => {
      iptal = true
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
  }, [acik, mod, olcu.w, olcu.h, hava, isik, hiz, hareket, videoSure, icerikImza])

  // ── İNDİR / PAYLAŞ ──────────────────────────────────────────
  const dosyaAdi = useMemo(() => {
    const t = (kaynak || "vukuf").toLocaleLowerCase("tr-TR")
      .replace(/[çğıöşü]/g, c => ({ ç: "c", ğ: "g", ı: "i", ö: "o", ş: "s", ü: "u" }[c]))
      .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")
    return `vukuf-${t || "gorsel"}.png`
  }, [kaynak])

  // ── VİDEO KAYDI ─────────────────────────────────────────────
  // SES: <audio> + createMediaElementSource yolu CORS'a çok duyarlıydı ve sessiz kalıyordu.
  // Artık ses DOSYA OLARAK indirilip (fetch) çözülüyor (decodeAudioData) ve AudioContext'te
  // ZAMANLANARAK çalınıyor. Böylece (a) gerçek süreler baştan bilinir → âyet-meal senkronu
  // birebir olur, (b) çoklu âyet kesintisiz sıralanır, (c) kaydedilen akışa doğrudan bağlanır.
  // SES İNDİRME (14 Ekim 2026 sağlamlaştırma — kullanıcı: "âyetleri indirirken saniye
  // verisini anlayıp âyetin ekranda değişme süresini ona göre belirleyip sesleri
  // birleştirsin, sessiz kalarak değişim yapmasın"). Süre zaten ÖLÇÜLMÜYOR, ses
  // çözülünce (decodeAudioData) KESİN biliniyor. Eksikler giderildi:
  //   • Önce internetsiz dinleme için indirilmiş sesler (Cache "vukuf-ses") kullanılır.
  //   • Eskiden TÜM indirmeler için toplam 8 sn vardı → uzun sûrede bir kısmı kesilip
  //     video yer yer SESSİZ kalıyordu. Artık her dosyaya 25 sn, aynı anda en çok 6
  //     indirme, başarısız olana bir kez daha deneme.
  //   • İnen sesler bu pencere açık kaldıkça bellekte tutulur → yeniden denemede hızlı.
  //   • Bir âyetin bile sesi alınamazsa kayıt BAŞLAMAZ (yarısı sessiz video çıkmasın).
  const sesBellekRef = useRef(new Map())                      // url → ArrayBuffer (kopya)
  const sesleriYukle = useCallback(async (sesCtx) => {
    const n = videoParcalari.length
    const tamponlar = new Array(n).fill(null)
    if (!sesAcik || !sesUrlAl || !ayet) { tamponRef.current = tamponlar; return { yuklenen: 0, eksik: 0 } }
    const kontrol = new AbortController()
    iptalRef.current = kontrol
    let onbellek = null
    try { if (typeof caches !== "undefined") onbellek = await caches.open("vukuf-ses") } catch { onbellek = null }
    const indir = async (url) => {
      const bellekte = sesBellekRef.current.get(url)
      if (bellekte) return bellekte.slice(0)
      if (onbellek) {
        try {
          const y = await onbellek.match(url, { ignoreVary: true })
          if (y && y.ok) { const ab = await y.arrayBuffer(); if (ab.byteLength) return ab }
        } catch { /* ağdan denenecek */ }
      }
      for (let deneme = 0; deneme < 2; deneme++) {
        if (kontrol.signal.aborted) throw new Error("iptal")
        const tek = new AbortController()
        const birak = () => tek.abort()
        kontrol.signal.addEventListener("abort", birak)
        const zaman = setTimeout(birak, 25000)
        try {
          const c = await fetch(url, { mode: "cors", credentials: "omit", signal: tek.signal })
          if (!c.ok) throw new Error(String(c.status))
          return await c.arrayBuffer()
        } catch (e) {
          if (deneme === 1 || kontrol.signal.aborted) throw e
        } finally { clearTimeout(zaman); kontrol.signal.removeEventListener("abort", birak) }
      }
      throw new Error("indirilemedi")
    }
    let bitmis = 0, yuklenen = 0
    const sira = videoParcalari.map((p, i) => i)
    const isci = async () => {
      while (sira.length && !kontrol.signal.aborted) {
        const i = sira.shift()
        const p = videoParcalari[i]
        // Besmele için Fâtiha 1 kaydı kullanılır (besmelenin kendisidir)
        const sn = p.tip === "besmele" ? 1 : (p.sureNo || ayet.sureNo)
        const an = p.tip === "besmele" ? 1 : (p.ayetNo || ayet.ayetNo)
        const url = sesUrlAl(sn, an)
        if (url) {
          try {
            const ab = await indir(url)
            if (!sesBellekRef.current.has(url)) sesBellekRef.current.set(url, ab.slice(0))
            tamponlar[i] = await sesCtx.decodeAudioData(ab)   // ab burada tüketilir
            yuklenen++
          } catch { /* eksik kalır */ }
        }
        bitmis++
        setIlerleme(bitmis / n)
        setDurum(`Ses hazırlanıyor… ${bitmis}/${n}`)
      }
    }
    await Promise.all(Array.from({ length: Math.min(6, n) }, isci))
    iptalRef.current = null
    tamponRef.current = tamponlar
    return { yuklenen, eksik: n - yuklenen }
  }, [videoParcalari, sesAcik, sesUrlAl, ayet])
  // SESLER CİHAZDA MI? (14 Ekim 2026) — indirilmiş bölümde video internetsiz ve daha
  // hızlı hazırlanır; kullanıcıya bir satırla söylenir. null: bilinmiyor / gösterme.
  const [sesCihazda, setSesCihazda] = useState(null)       // { var, toplam }
  useEffect(() => {
    if (!acik || mod !== "video" || !sesAcik || !sesUrlAl || !ayet || typeof caches === "undefined") { setSesCihazda(null); return }
    let iptal = false
    ;(async () => {
      try {
        const k = await caches.open("vukuf-ses")
        let say = 0
        for (const p of videoParcalari) {
          const sn = p.tip === "besmele" ? 1 : (p.sureNo || ayet.sureNo)
          const an = p.tip === "besmele" ? 1 : (p.ayetNo || ayet.ayetNo)
          const u = sesUrlAl(sn, an)
          if (u && await k.match(u, { ignoreVary: true })) say++
        }
        if (!iptal) setSesCihazda({ var: say, toplam: videoParcalari.length })
      } catch { if (!iptal) setSesCihazda(null) }
    })()
    return () => { iptal = true }
  }, [acik, mod, sesAcik, sesUrlAl, ayet, videoParcalari, kariId])
  // Pencere kapanınca ya da kâri değişince bellekteki sesler bırakılır
  useEffect(() => { if (!acik) sesBellekRef.current = new Map() }, [acik])
  useEffect(() => { sesBellekRef.current = new Map() }, [kariId])

  const videoKaydet = async () => {
    const cv = canvasRef.current
    if (!cv || !videoDestekli) return
    kayitIptalRef.current = false
    setDurum(""); setIlerleme(0); setKayitDurum("isleniyor"); setHazirDosya(null)

    // 1) Ses (varsa) indirilip çözülür → gerçek süreler
    let sesCtx = null, sesUyari = false
    const AC = window.AudioContext || window.webkitAudioContext
    if (sesAcik && sesUrlAl && ayet && AC) {
      try {
        sesCtx = new AC()
        if (sesCtx.state === "suspended") await sesCtx.resume()
        const { eksik } = await sesleriYukle(sesCtx)
        if (eksik > 0 && !kayitIptalRef.current) {
          // Yarısı sessiz video üretmek yerine kayıt başlatılmıyor; inenler bellekte kalıyor
          try { sesCtx.close() } catch { /* yoksay */ }
          setKayitDurum("hazir"); kayitDurumRef.current = "hazir"
          setIlerleme(0); setKalanSn(0)
          const n = videoParcalari.length
          setDurum(eksik === n
            ? "Kâri sesi alınamadı; internet bağlantısı varken yeniden denenebilir."
            : `${n} âyetten ${eksik} tanesinin sesi alınamadı; yeniden denendiğinde inenler tekrar indirilmez.`)
          return
        }
      } catch { sesUyari = true; sesCtx = null }
    } else {
      tamponRef.current = new Array(videoParcalari.length).fill(null)
    }
    if (kayitIptalRef.current) {
      setKayitDurum("hazir"); kayitDurumRef.current = "hazir"
      setIlerleme(0); setKalanSn(0); setDurum("Kayıt durduruldu.")
      try { sesCtx && sesCtx.close() } catch { /* yoksay */ }
      return
    }

    // 2) Çizelge (ses süreleriyle) + katmanlar
    await katmanlariHazirla()
    const toplam = cizelgeKur()
    toplamSureRef.current = toplam
    setDurum(""); setIlerleme(0)

    // 3a) HIZLI YOL (14 Ekim 2026) — kareler beklemeden çizilip kodlanır, sesler anında
    // birleştirilir (data/hizliKayit.js). Galeri videoları da kare kare çözülür (2. adım).
    // Tarayıcı uygun kodek bulamazsa, bir galeri videosu çözülemezse ya da bir hata
    // olursa aşağıdaki gerçek zamanlı kayda dönülür.
    if (hizliKayitOlasi() && !kayitIptalRef.current) {
      const sesVar = !!(sesCtx && tamponRef.current.some(Boolean))
      const kod = await hizliKodekler(cv.width, cv.height, sesVar)
      const okuyucular = new Map()                       // slayt → videoOkuyucu
      const okuyuculariKapat = () => { okuyucular.forEach(o => o.kapat()); okuyucular.clear(); hizliKareRef.current = null }
      if (kod) {
        try {
          // Galeri videoları: <video>'lar durdurulur, her biri için kare çözücü kurulur
          const slaytlar = slaytCvRef.current || []
          for (const x of slaytlar) {
            if (!x.video) continue
            try { x.video.pause() } catch { /* yoksay */ }
            const blob = await (await fetch(x.url)).blob()
            const o = await videoOkuyucuKur(blob, Math.max(cv.width, cv.height))
            if (!o) throw new Error("galeri videosu çözülemiyor")
            okuyucular.set(x, o)
          }
          const kareler = new Map()
          hizliKareRef.current = okuyucular.size ? kareler : null
          // Görünen video slaytlarının o anki karesini çözücüden al
          const cizelgeHizli = cizelgeRef.current
          const n = slaytlar.length
          const dongu = n < 2 || (slaytKip === "ayet" && slaytVideo === "ayetle")
          const videoKareleriHazirla = async (t) => {
            if (!okuyucular.size) return
            const { sira, bas } = slaytKonumu(t, slaytlar, cizelgeHizli, slaytKip, slaytVideo, slaytSn)
            const i = sira % n
            const gorunen = [[i, sira, bas]]
            if (n > 1 && sira > 0 && (t - bas) < GECIS_SN) {
              const o = slaytKonumu(Math.max(0, bas - 0.0005), slaytlar, cizelgeHizli, slaytKip, slaytVideo, slaytSn)
              gorunen.push([o.sira % n, o.sira, o.bas])
            }
            for (const [j, s, b] of gorunen) {
              const x = slaytlar[j]
              const ok = okuyucular.get(x)
              if (!ok) continue
              let yerel = t - b
              // "Âyetle değişsin": video her gelişinde KALDIĞI YERDEN sürer → önceki görünüşler eklenir
              if (slaytKip === "ayet" && slaytVideo === "ayetle" && n > 1) {
                for (let k = j; k < s; k += n) yerel += ((cizelgeHizli[k + 1] || { bas: toplam }).bas - cizelgeHizli[k].bas)
              }
              const sure = x.sure > 0 ? x.sure : 0
              if (sure) yerel = dongu ? yerel % sure : Math.min(yerel, sure - 0.001)
              kareler.set(x, await ok.kare(Math.max(0, yerel)))
            }
          }
          const birlesik = sesVar ? await sesleriBirlestir(tamponRef.current, cizelgeRef.current, toplam) : null
          if (sesVar && !birlesik) throw new Error("ses birleştirilemedi")
          if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null }
          setHizliSurer(true); setKayitDurum("kayit"); kayitDurumRef.current = "kayit"
          setDurum("Video hazırlanıyor…")
          const ctx2 = cv.getContext("2d")
          const blob = await hizliKaydet({
            canvas: cv, W: cv.width, H: cv.height, toplam, kod, ses: birlesik,
            kareCiz: async (t) => {
              const cz = cizelgeRef.current
              let iz = 0
              for (let k = 0; k < cz.length; k++) { if (t >= cz[k].bas) iz = k; else break }
              if (iz !== parcaIdxRef.current) await parcaCiz(iz)
              await videoKareleriHazirla(t)
              videoKare(ctx2, t, toplam)
            },
            ilerleme: (oran, kalan) => {
              setIlerleme(oran)
              setDurum(`Video hazırlanıyor… %${Math.round(oran * 100)}${kalan != null ? `\nyaklaşık ${Math.max(1, Math.ceil(kalan))} sn kaldı` : ""}`)
            },
            iptal: () => kayitIptalRef.current,
          })
          try { sesCtx && sesCtx.close() } catch { /* yoksay */ }
          okuyuculariKapat()
          setHizliSurer(false)
          setIlerleme(0); setKalanSn(0); setKayitDurum("hazir"); kayitDurumRef.current = "hazir"
          if (!blob) { setDurum("Kayıt durduruldu."); return }
          setDurum("")
          await dosyayiVer(blob, dosyaAdi.replace(/\.png$/, ".mp4"), "video/mp4")
          return
        } catch {
          // Hızlı yol olmadı → gerçek zamanlı kayıtla devam (sesler hâlâ elde)
          okuyuculariKapat()
          videoSiraRef.current = -1
          setHizliSurer(false); setDurum(""); setIlerleme(0)
          if (kayitIptalRef.current) {
            try { sesCtx && sesCtx.close() } catch { /* yoksay */ }
            setKayitDurum("hazir"); kayitDurumRef.current = "hazir"; setDurum("Kayıt durduruldu.")
            return
          }
          parcaIdxRef.current = -1
        }
      }
    }

    // 3) Akış: canvas + (varsa) ses
    const akis = cv.captureStream(30)
    let hedef = null
    if (sesCtx) {
      try {
        hedef = sesCtx.createMediaStreamDestination()
        hedef.stream.getAudioTracks().forEach(t => akis.addTrack(t))
      } catch { sesUyari = true; hedef = null }
    }

    const parcalar = []
    let kaydedici
    try {
      kaydedici = new MediaRecorder(akis, { mimeType: mimeTuru, videoBitsPerSecond: 6000000 })
    } catch {
      setKayitDurum("hazir"); setDurum("Bu tarayıcı video kaydını desteklemiyor.")
      return
    }
    kaydedici.ondataavailable = (e) => { if (e.data && e.data.size) parcalar.push(e.data) }
    const bitti = new Promise(cz => { kaydedici.onstop = cz })

    // 4) Kaydı ve sesi AYNI ANDA başlat; çizim döngüsü sıfırdan saysın
    setKayitDurum("kayit")
    kayitDurumRef.current = "kayit"
    setKalanSn(Math.ceil(toplam))
    const ctx2 = cv.getContext("2d")
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null }
    kaydedici.start(200)
    const kaynaklar = []
    const t0 = sesCtx ? sesCtx.currentTime + 0.12 : 0
    if (sesCtx && hedef) {
      // DİNLEME (monitör) yolu: ses KAYDA her hâlükârda gider, HOPARLÖRE ise ayrı bir kazanç
      // düğümü üzerinden. Kazanç 0 başlar → kayıt alırken kullanıcıya zorla ses çalmaz.
      // Kullanıcı isterse kayıt SÜRERKEN "Dinle" düğmesiyle canlı açıp kapatabilir.
      let monitor = null
      try {
        monitor = sesCtx.createGain()
        monitor.gain.value = dinleRef.current ? 1 : 0
        monitor.connect(sesCtx.destination)
        monitorRef.current = monitor
      } catch { monitor = null }
      cizelgeRef.current.forEach((c, i) => {
        const b = tamponRef.current[i]
        if (!b) return
        const src = sesCtx.createBufferSource()
        src.buffer = b
        src.connect(hedef)                       // → videoya kaydedilir
        if (monitor) src.connect(monitor)        // → yalnız "Dinle" açıksa duyulur
        src.start(t0 + c.bas)
        kaynaklar.push(src)
      })
    }
    const bas = performance.now() + (sesCtx ? 120 : 0)
    await new Promise(cz => {
      const dongu = (zaman) => {
        const t = (zaman - bas) / 1000
        if (kayitIptalRef.current || t >= toplam) { cz(); return }
        if (t >= 0) videoKare(ctx2, t, toplam)
        setIlerleme(Math.min(1, Math.max(0, t / toplam)))
        setKalanSn(Math.max(0, Math.ceil(toplam - Math.max(0, t))))
        rafRef.current = requestAnimationFrame(dongu)
      }
      rafRef.current = requestAnimationFrame(dongu)
    })
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null }

    // 5) Bitir
    try { kaydedici.stop() } catch { /* yoksay */ }
    kaynaklar.forEach(sr => { try { sr.stop() } catch { /* yoksay */ } })
    await bitti
    try { akis.getTracks().forEach(t => t.stop()) } catch { /* yoksay */ }
    monitorRef.current = null                    // dinleme düğümü kayıtla birlikte biter
    try { sesCtx && sesCtx.close() } catch { /* yoksay */ }
    setKayitDurum("isleniyor")

    const blob = new Blob(parcalar, { type: mimeTuru })
    setIlerleme(0); setKalanSn(0); setKayitDurum("hazir"); kayitDurumRef.current = "hazir"
    if (kayitIptalRef.current) { setDurum("Kayıt durduruldu."); return }
    if (!blob.size) { setDurum("Video oluşturulamadı, lütfen tekrar deneyiniz."); return }
    const uzanti = mimeTuru.includes("mp4") ? "mp4" : "webm"
    await dosyayiVer(blob, dosyaAdi.replace(/\.png$/, "." + uzanti), `video/${uzanti}`)
    if (sesUyari) setDurum("Video kaydedildi — kâri sesi alınamadı (ses sunucusu izin vermiyor olabilir).")
  }

  // Hazır dosyanın nesne adresi, yenisi geldiğinde / panel kapanınca bırakılır.
  useEffect(() => () => { if (hazirDosya?.url) { try { URL.revokeObjectURL(hazirDosya.url) } catch { /* yoksay */ } } }, [hazirDosya])

  // ── DOSYAYI VER (foto ve video ortak) ───────────────────────────
  // ESKİ HATA: video kaydı gerçek zamanlıdır (onlarca saniye). Bitince navigator.share
  // çağrılıyordu; ama paylaşım API'si "taze kullanıcı hareketi" ister ve o hareket çoktan
  // sona ermiş olduğu için NotAllowedError atıyordu → "Kaydedilemedi — dosyaya basılı
  // tutarak kaydedebilirsiniz." Oysa dosya hazırdı.
  // YENİ: (1) paylaşım yalnız kullanıcı hareketi HÂLÂ geçerliyken denenir, (2) paylaşım
  // olmazsa sessizce indirmeye düşer, (3) her hâlükârda dosya `hazirDosya`ya konur →
  // alt çubukta "Videoyu kaydet" düğmesi çıkar; ona basmak taze bir hareket üretir.
  const hareketTaze = () => {
    try {
      if (navigator.userActivation && typeof navigator.userActivation.isActive === "boolean")
        return navigator.userActivation.isActive
    } catch { /* yoksay */ }
    return true   // bilgi yoksa denemeye değer
  }

  const indirmeyiDene = (blob, ad) => {
    const u = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = u; a.download = ad; a.rel = "noopener"
    document.body.appendChild(a); a.click(); a.remove()
    setTimeout(() => { try { URL.revokeObjectURL(u) } catch { /* yoksay */ } }, 60000)
  }

  const dosyayiVer = async (blob, ad, tur, { paylasimDene = true } = {}) => {
    // Dosya her durumda elde tutulur: otomatik adım tutmazsa kullanıcı düğmeyle alır.
    setHazirDosya({ url: URL.createObjectURL(blob), ad, tur, blob })
    const dosya = new File([blob], ad, { type: tur })
    const paylasilabilir = !!(navigator.canShare && navigator.share && navigator.canShare({ files: [dosya] }))

    if (paylasimDene && paylasilabilir && hareketTaze()) {
      try {
        await navigator.share({ files: [dosya] })
        setDurum("Paylaşıldı")
        setHazirDosya(null)          // paylaşım tuttu → yedek düğmeye gerek yok
        return true
      } catch (e) {
        if (e && e.name === "AbortError") { setDurum(""); return true }   // kullanıcı vazgeçti
        /* NotAllowedError / NotSupportedError → indirmeye düş */
      }
    }
    try {
      indirmeyiDene(blob, ad)
      setDurum(paylasilabilir ? "Hazır — kaydetmek için aşağıdaki düğmeye dokunun." : "İndirildi")
      return true
    } catch {
      setDurum("Hazır — kaydetmek için aşağıdaki düğmeye dokunun.")
      return false
    }
  }

  // Alt çubuktaki "Kaydet/Paylaş" düğmesi: TAZE kullanıcı hareketiyle çalışır.
  const hazirDosyayiAl = async () => {
    if (!hazirDosya) return
    const dosya = new File([hazirDosya.blob], hazirDosya.ad, { type: hazirDosya.tur })
    if (navigator.canShare && navigator.share && navigator.canShare({ files: [dosya] })) {
      try { await navigator.share({ files: [dosya] }); setDurum("Paylaşıldı"); return }
      catch (e) { if (e && e.name === "AbortError") { setDurum(""); return } }
    }
    try { indirmeyiDene(hazirDosya.blob, hazirDosya.ad); setDurum("İndirildi") }
    catch { setDurum("Kaydedilemedi — aşağıdaki bağlantıya basılı tutup kaydedebilirsiniz.") }
  }

  const indir = async () => {
    const cv = canvasRef.current
    if (!cv) return
    // Kaydedilen görselde kullanılan özel rengi "son kullanılanlar"a yaz (onBlur mobilde
    // her zaman tetiklenmiyor; kaydetme anı kesin bir işaret).
    if (yaziRengi) setSonRenkler(sonRenkEkle(yaziRengi))
    setCalisiyor(true); setDurum(""); setHazirDosya(null)
    try {
      const blob = await new Promise(cz => cv.toBlob(cz, "image/png"))
      if (!blob) throw new Error("boş")
      // iOS'ta <a download> güvenilir değil; önce paylaşım sayfası denenir ("Fotoğraflara Kaydet")
      await dosyayiVer(blob, dosyaAdi, "image/png")
    } catch {
      setDurum("Kaydedilemedi — görsele basılı tutarak kaydedebilirsiniz.")
    }
    setCalisiyor(false)
  }

  // Galerim kutusu: boşken dokunmak düzenleyiciyi açar; doluyken arka plan olarak seçer
  const arkaSec = (id) => {
    if (id === "galeri" && !galeri.length) { setGaleriDuzenleAcik(true); return }
    setArkaId(id)
  }

  if (!acik) return null

  // ── ARAYÜZ ──────────────────────────────────────────────────
  const kucukBaslik = { fontSize: "10px", letterSpacing: "1px", textTransform: "uppercase", color: theme.textSecondary, opacity: 0.75, margin: "0 0 6px" }
  const cipStil = (aktif) => ({
    display: "flex", alignItems: "center", gap: "5px",
    padding: isMobile ? "6px 9px" : "7px 11px", borderRadius: "999px", cursor: "pointer",
    border: `1px solid ${aktif ? theme.accent : theme.border}`,
    background: aktif ? `${theme.accent}1e` : "transparent",
    color: aktif ? theme.accent : theme.textSecondary,
    fontSize: isMobile ? "11px" : "12px", fontWeight: 600, whiteSpace: "nowrap", flexShrink: 0,
  })
  // overscrollBehaviorY:"auto" → panel kilidinin `.vukuf-panel *{overscroll-behavior:contain}`
  // kuralını satır içi olarak ezer; şeritte yutulan dikey kaydırma üst kutuya zincirlenebilir.
  // touchAction:"pan-x pan-y" → parmakla şerit üzerinden dikey kaydırma da mümkün.
  const seritStil = {
    display: "flex", gap: "6px", overflowX: "auto", paddingBottom: "3px",
    WebkitOverflowScrolling: "touch",
    overscrollBehaviorX: "contain", overscrollBehaviorY: "auto",
    touchAction: "pan-x pan-y",
  }
  const renkKutu = (renk, aktif) => ({
    width: isMobile ? "26px" : "28px", height: isMobile ? "26px" : "28px",
    borderRadius: "50%", flexShrink: 0, cursor: "pointer", background: renk,
    border: aktif ? `3px solid ${theme.accent}` : `1px solid ${theme.border}`,
    boxShadow: aktif ? `0 0 0 2px ${theme.accent}33` : "none",
    padding: 0,
  })

  const anahtar = (etiket, deger, ayarla, kapali) => (
    <button
      onClick={() => !kapali && ayarla(v => !v)}
      disabled={kapali}
      style={{ ...cipStil(deger && !kapali), opacity: kapali ? 0.35 : 1, cursor: kapali ? "not-allowed" : "pointer" }}
    >
      {deger && !kapali ? <Check size={12} /> : <span style={{ width: 12 }} />} {etiket}
    </button>
  )

  return (
    <div
      onClick={kapat}
      style={{
        position: "fixed", inset: 0, zIndex: 420, background: "rgba(0,0,0,0.62)",
        display: "flex", alignItems: "center", justifyContent: "center",
        /* ÇENTİK PAYI — panel %94 yükseklikte olduğu için üstte yalnız ~%3 boşluk
           kalıyordu; iPhone'da çentik payı bundan büyük, panelin başlığı saatin
           altında kalıyordu. Pay burada AÇIKÇA veriliyor ve panel `maxHeight:100%`
           ile bu payın içinde kalıyor (94vh olsaydı payı aşabilirdi). */
        padding: isMobile
          ? "calc(env(safe-area-inset-top) + 10px) 10px calc(env(safe-area-inset-bottom) + 10px)"
          : "18px",
      }}
    >
      <div
        className="vukuf-panel"
        onClick={e => e.stopPropagation()}
        style={{
          width: "100%", maxWidth: isMobile ? "100%" : "820px", maxHeight: "100%",
          display: "flex", flexDirection: "column",
          background: theme.background, border: `1px solid ${theme.border}`,
          borderRadius: "16px", overflow: "hidden", boxShadow: "0 18px 60px rgba(0,0,0,0.45)",
        }}
      >
        {/* Başlık */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "11px 14px", borderBottom: `1px solid ${theme.border}`, flexShrink: 0,
        }}>
          <span style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0 }}>
            <ImagePlay size={16} color={theme.accent} style={{ flexShrink: 0 }} />
            {/* MOD SEKMELERİ — ayrı bir bar düğmesi yok; fotoğraf/video buradan seçilir */}
            <span style={{ display: "flex", gap: "4px", background: `${theme.accent}12`, borderRadius: "999px", padding: "3px" }}>
              {[{ id: "foto", ad: "Fotoğraf", I: ImageIcon }, { id: "video", ad: "Video", I: Film }].map(m => {
                const kapali = m.id === "video" && !videoDestekli
                const I = m.I
                return (
                  <button
                    key={m.id}
                    onClick={() => !kapali && setMod(m.id)}
                    disabled={kapali}
                    title={kapali ? "Bu tarayıcı video kaydını desteklemiyor" : m.ad}
                    style={{
                      display: "flex", alignItems: "center", gap: "5px",
                      padding: isMobile ? "5px 10px" : "6px 13px", borderRadius: "999px",
                      border: "none", cursor: kapali ? "not-allowed" : "pointer",
                      background: mod === m.id ? theme.accent : "transparent",
                      color: mod === m.id ? "#fff" : theme.textSecondary,
                      opacity: kapali ? 0.4 : 1,
                      fontSize: isMobile ? "11px" : "12px", fontWeight: 600, whiteSpace: "nowrap",
                    }}
                  ><I size={12} /> {m.ad}</button>
                )
              })}
            </span>
          </span>
          <button onClick={kapat} aria-label="Kapat" style={{ background: "transparent", border: "none", color: theme.textSecondary, cursor: "pointer", padding: "4px", display: "flex" }}>
            <X size={18} />
          </button>
        </div>

        <div
          ref={kaydirRef}
          style={{
            overflowY: "auto", overscrollBehavior: "contain", flex: 1,
            // ÜST BOŞLUK YOK: yapışkan önizlemenin kendi üst dolgusu var. Kutunun üst
            // dolgusu bırakılırsa (eskiden 10/14px) önizleme negatif üst boşlukla yukarı
            // çekilmek zorunda kalıyordu; yapışkan konumlandırma negatif üst boşluğu da
            // hesaba kattığı için kaydırınca üstte bir şerit açılıyor ve panelin devamı
            // oradan görünüyordu. Artık üst dolgu 0, negatif üst boşluk yok.
            padding: isMobile ? "0 12px 14px" : "0 18px 18px",
            touchAction: "pan-y",
          }}
        >
          {/* ÖNİZLEME */}
          {/* Önizleme YAPIŞKAN: seçenekleri kaydırırken üstte sabit kalır */}
          <div style={{
            position: "sticky", top: 0, zIndex: 6,
            background: theme.background,
            display: "flex", justifyContent: "center",
            // yalnız YATAY negatif boşluk (kenarlara taşsın); dikeyde sıfır → yapışkan tam otursun
            margin: isMobile ? "0 -12px 12px" : "0 -18px 12px",
            padding: isMobile ? "10px 12px" : "14px 18px",
            borderBottom: `1px solid ${theme.border}`,
            boxShadow: `0 6px 12px -8px ${theme.border}`,
          }}>
            <div style={{ position: "relative", display: "inline-flex" }}>
              <canvas
                ref={canvasRef}
                style={{
                  maxWidth: "100%",
                  maxHeight: isMobile ? "42vh" : "46vh",
                  width: "auto", height: "auto",
                  borderRadius: "10px",
                  boxShadow: "0 6px 22px rgba(0,0,0,0.28)",
                  background: theme.surface,
                }}
              />
              {/* Video: sessiz üretilir. Önizlemedeki ikon ile kullanıcı kâri sesini açar. */}
              {mod === "video" && ayet && sesUrlAl && (
                <button
                  onClick={() => setSesAcik(v => !v)}
                  title={sesAcik ? "Kâri sesi açık — kapatmak için dokunun" : "Sessiz — kâri sesini açmak için dokunun"}
                  style={{
                    position: "absolute", top: "8px", right: "8px",
                    width: "34px", height: "34px", borderRadius: "999px",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    border: "none", cursor: "pointer",
                    background: sesAcik ? theme.accent : "rgba(0,0,0,0.55)",
                    color: "#fff", boxShadow: "0 2px 8px rgba(0,0,0,0.3)",
                    backdropFilter: "blur(2px)",
                  }}
                >
                  {sesAcik ? <Volume2 size={17} /> : <VolumeX size={17} />}
                </button>
              )}
            </div>
          </div>

          {uyari && (
            <div style={{
              fontSize: "11px", color: theme.textSecondary, background: `${theme.accent}12`,
              border: `1px solid ${theme.border}`, borderRadius: "8px", padding: "7px 10px", marginBottom: "10px",
            }}>{uyari}</div>
          )}

          {/* ── 7 Ekim 2026: yana kayan çip şeritleri yerine hıfz panelindeki gibi
              bölünmüş düğmeler (Secim) ve aç/kapa satırları (Anahtar) — ortak
              AyarOgeleri.jsx. Seçenekler satıra sarılır, hiçbiri kesik kalmaz. ── */}

          {/* ORAN */}
          <AyarBaslik theme={theme} ikon={Ratio} ust={2}>Boyut</AyarBaslik>
          <Secim theme={theme} kucuk deger={oran} onSec={setOran} sutun={isMobile ? 3 : oranListesi.length}
            secenekler={oranListesi.map(o => ({ id: o.id, ad: o.ad, Ikon: o.Ikon, alt: o.etiket || o.id }))} />

          {/* İÇERİK ANAHTARLARI */}
          <AyarBaslik theme={theme} ikon={LayoutTemplate}>İçerik</AyarBaslik>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", columnGap: "6px" }}>
            <Anahtar theme={theme} baslik="Âyet (Arapça)" acik={arapcaAcik} onDegis={setArapcaAcik} kapali={!arapca} />
            <Anahtar theme={theme} baslik="Meal / Metin" acik={mealAcik} onDegis={setMealAcik} kapali={!meal} />
            <Anahtar theme={theme} baslik="Kaynak" acik={kaynakAcik} onDegis={setKaynakAcik} kapali={!kaynak} />
            <Anahtar theme={theme} baslik="Rahle süsü" acik={rahleAcik} onDegis={setRahleAcik} />
          </div>

          {/* ARKA PLAN — galeri izleme moduyla ortak */}
          <AyarBaslik theme={theme} ikon={ImageIcon} not={galeri.length ? "galeri izleme moduyla ortak" : null}>Arka plan</AyarBaslik>
          <ArkaPlanIzgara theme={theme} onSec={arkaSec}
            ogeler={[
              {
                id: "galeri", ad: galeri.length >= 2 ? "Slayt" : "Galerim", secili: arkaId === "galeri" && galeri.length > 0,
                icerik: <GaleriKolaj theme={theme} galeri={galeri} ogeler={galeriOgeleri} />,
              },
              ...gecerliGorseller.map(g => ({ id: g.id, ad: g.ad, resim: g.src, secili: arkaId === g.id })),
              ...DESENLER.map(d => ({ id: d.id, ad: d.ad, resim: desenOnizleme(d), secili: arkaId === d.id })),
            ]} />
          {arkaId === "galeri" && galeri.length > 0 && (
            <GaleriOzeti theme={theme} galeri={galeri} ogeler={galeriOgeleri} iz={izOrtak}
              not={mod === "foto" && galeri.length > 1 ? "fotoğrafta kapak" : null}
              onDuzenle={() => setGaleriDuzenleAcik(true)} />
          )}

          {/* ÇERÇEVE */}
          <AyarBaslik theme={theme} ikon={Frame}>Çerçeve</AyarBaslik>
          <Secim theme={theme} kucuk deger={cerceve} onSec={setCerceve} sutun={3}
            secenekler={CERCEVELER.map(c => ({ id: c.id, ad: c.ad.replace(" Çizgi", "").replace(" Süsü", "") }))} />

          {/* KARARTMA */}
          <AyarBaslik theme={theme} ikon={Eye} not="yazının okunurluğu">Karartma</AyarBaslik>
          <Secim theme={theme} kucuk deger={karartma} onSec={setKarartma} secenekler={KARARTMALAR} />

          {/* EFEKTLER — izleme modundan aktarıldı; fotoğrafta donmuş bir an, videoda canlı */}
          <AyarBaslik theme={theme} ikon={Wind} not={mod === "foto" && (hava !== "yok" || isik !== "yok") ? "fotoğrafta donmuş an" : null}>Hava</AyarBaslik>
          <Secim theme={theme} kucuk deger={hava} onSec={setHava} secenekler={HAVALAR} />
          <AyarBaslik theme={theme} ikon={Sun}>Işık</AyarBaslik>
          <Secim theme={theme} kucuk deger={isik} onSec={setIsik} secenekler={ISIKLAR} />

          {/* YAZI RENGİ — otomatik + öneriler + son 5 renk + özel renk */}
          <AyarBaslik theme={theme} ikon={Palette}>Yazı rengi</AyarBaslik>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "4px", alignItems: "center" }}>
            <button onClick={() => setYaziRengi(null)} style={cipStil(yaziRengi === null)}>Otomatik</button>

            {/* ÖZEL RENK — input'un KENDİSİ düğme; tıklanınca tarayıcının renk paleti açılır.
                (Gizli/sıfır boyutlu input iOS'ta paleti açmıyordu ve panelin altında ince bir
                beyaz çizgi olarak sızıyordu.) */}
            <label
              title="Özel renk seç"
              style={{
                position: "relative", display: "flex", alignItems: "center", gap: "5px",
                padding: isMobile ? "5px 9px" : "6px 11px", borderRadius: "999px", cursor: "pointer",
                border: `1px solid ${ozelRenkMi ? theme.accent : theme.border}`,
                background: ozelRenkMi ? `${theme.accent}1e` : "transparent",
                color: ozelRenkMi ? theme.accent : theme.textSecondary,
                fontSize: isMobile ? "11px" : "12px", fontWeight: 600, whiteSpace: "nowrap", flexShrink: 0,
                overflow: "hidden",
              }}
            >
              <Pipette size={13} />
              Özel
              <span style={{
                width: "14px", height: "14px", borderRadius: "50%",
                background: yaziRengi || "#f6f1e6",
                border: `1px solid ${theme.border}`, flexShrink: 0,
              }} />
              <input
                type="color"
                value={yaziRengi || "#f6f1e6"}
                onChange={e => setYaziRengi(e.target.value)}
                onBlur={e => setSonRenkler(sonRenkEkle(e.target.value))}
                style={{ position: "absolute", inset: 0, opacity: 0, cursor: "pointer", border: "none", padding: 0 }}
              />
            </label>

            {sonRenkler.length > 0 && <span style={{ width: "1px", height: "22px", background: theme.border, flexShrink: 0, margin: "0 2px" }} />}
            {sonRenkler.map(r => (
              <button key={`son-${r}`} onClick={() => setYaziRengi(r)} title={`Son kullanılan: ${r}`} style={renkKutu(r, yaziRengi === r)} />
            ))}

            <span style={{ width: "1px", height: "22px", background: theme.border, flexShrink: 0, margin: "0 2px" }} />
            {ONERILEN_RENKLER.map(r => (
              <button key={r.id} onClick={() => { setYaziRengi(r.renk); setSonRenkler(sonRenkEkle(r.renk)) }} title={r.ad} style={renkKutu(r.renk, yaziRengi === r.renk)} />
            ))}
          </div>
          <div style={{ fontSize: "10px", color: theme.textSecondary, opacity: 0.7 }}>
            Otomatik: koyu zeminde açık, açık zeminde koyu yazı.
          </div>

          {/* SÜS RENKLERİ — sûre adı (Arapça), kaynak (Türkçe), rahle */}
          {(kaynakAcik || rahleAcik) && (
            <>
              <AyarBaslik theme={theme} ikon={Palette} not="sûre adı · kaynak · rahle">Süs renkleri</AyarBaslik>
              <SusRenkleri theme={theme} degerler={susRenk}
                onSec={(alan, v) => setSusRenk(o => ({ ...o, [alan]: v }))}
                oneriler={ONERILEN_RENKLER} sonRenkler={sonRenkler} onSonEkle={r => setSonRenkler(sonRenkEkle(r))} />
            </>
          )}

          {/* İŞARET RENGİ — vakıf işaretleri mushaf sayfasındaki gibi boyanabilir */}
          {arapca && (
            <>
              <AyarBaslik theme={theme} ikon={Highlighter} not="vakıf işaretleri">İşaret rengi</AyarBaslik>
              <Secim theme={theme} kucuk deger={isaretRenk} onSec={setIsaretRenk} secenekler={ISARET_RENKLERI} />
              {isaretRenk === "ozel" && (
                <label style={{
                  position: "relative", display: "inline-flex", alignItems: "center", gap: "6px", marginTop: "6px",
                  padding: "6px 11px", borderRadius: "999px", border: `1px solid ${theme.border}`,
                  fontSize: "12px", fontWeight: 600, color: theme.textSecondary, cursor: "pointer", overflow: "hidden",
                }}>
                  <Pipette size={13} /> İşaret rengini seç
                  <span style={{ width: "16px", height: "16px", borderRadius: "50%", background: isaretOzel, border: `1px solid ${theme.border}` }} />
                  <input type="color" value={isaretOzel} onChange={e => setIsaretOzel(e.target.value)}
                    style={{ position: "absolute", inset: 0, opacity: 0, cursor: "pointer", border: "none", padding: 0 }} />
                </label>
              )}
            </>
          )}

          {/* ── VİDEO SEÇENEKLERİ ───────────────────────────── */}
          {mod === "video" && (
            <>
              {/* KAPSAM — birden fazla âyet ya da sûrenin tamamı */}
              {ayet && ayetListesiAl && (
                <>
                  <AyarBaslik theme={theme} ikon={Layers} ust={18}>Kapsam</AyarBaslik>
                  <div style={{ marginBottom: "8px" }}>
                    <Secim theme={theme} kucuk deger={kapsam} onSec={setKapsam}
                      secenekler={[{ id: "tek", ad: "Tek âyet" }, { id: 3, ad: "3 âyet" }, { id: 5, ad: "5 âyet" },
                        { id: 10, ad: "10 âyet" }, { id: "sayfa", ad: "Tek sayfa" },
                        { id: "sure", ad: "Sûrenin tamamı" }, { id: "ozel", ad: "Özel…" }]} />
                  </div>

                  {/* ÖZEL ARALIK — başlangıç / bitiş âyeti (en fazla azamiAyet âyet) */}
                  {kapsam === "ozel" && (() => {
                    const enCok = sureBilgi?.ayetSayisi || 286
                    const kutu = {
                      width: "66px", padding: "7px 8px", borderRadius: "8px", textAlign: "center",
                      border: `1px solid ${theme.border}`, background: theme.background,
                      color: theme.text, fontSize: "13px", outline: "none", fontFamily: "inherit",
                    }
                    // Geçerli (kırpılmış) aralık — önizleme bunu kullanır.
                    const bas = Math.min(Math.max(1, ozelBas || 1), enCok)
                    const son = Math.min(Math.max(bas, ozelSon || bas), Math.min(enCok, bas + azamiAyet - 1))
                    const secili = son - bas + 1
                    // Yazarken KIRPMA YOK: yalnız rakam süzülür, sayı büyükse üst sınıra çekilir.
                    // Asıl sınırlar (bitiş ≥ başlangıç, en fazla azamiAyet) odaktan çıkınca uygulanır.
                    const yazildi = (ham, metinAyarla, sayiAyarla) => {
                      const t = String(ham).replace(/\D/g, "").slice(0, 4)
                      metinAyarla(t)
                      const n = parseInt(t, 10)
                      if (Number.isFinite(n) && n >= 1) sayiAyarla(Math.min(n, enCok))
                    }
                    const basBitti = () => {
                      const n = Math.min(Math.max(1, parseInt(ozelBasMetin, 10) || 1), enCok)
                      ozelBasYaz(n)
                      const ustSinir = Math.min(enCok, n + azamiAyet - 1)
                      if (ozelSon < n) ozelSonYaz(n)
                      else if (ozelSon > ustSinir) ozelSonYaz(ustSinir)
                      else ozelSonYaz(ozelSon)
                    }
                    const sonBitti = () => {
                      const b = Math.min(Math.max(1, ozelBas || 1), enCok)
                      const n = parseInt(ozelSonMetin, 10)
                      const g = Number.isFinite(n) && n >= 1 ? n : b
                      ozelSonYaz(Math.min(Math.max(g, b), Math.min(enCok, b + azamiAyet - 1)))
                    }
                    const kirpildi = (parseInt(ozelSonMetin, 10) || son) !== son || (parseInt(ozelBasMetin, 10) || bas) !== bas
                    return (
                      <div style={{ marginBottom: "10px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
                          <span style={{ fontSize: "12px", color: theme.textSecondary }}>Başlangıç</span>
                          <input
                            type="text" inputMode="numeric" pattern="[0-9]*"
                            value={ozelBasMetin}
                            onChange={e => yazildi(e.target.value, setOzelBasMetin, setOzelBas)}
                            onFocus={e => e.target.select()}
                            onBlur={basBitti}
                            onKeyDown={e => { if (e.key === "Enter") e.currentTarget.blur() }}
                            style={kutu}
                          />
                          <span style={{ fontSize: "12px", color: theme.textSecondary }}>Bitiş</span>
                          <input
                            type="text" inputMode="numeric" pattern="[0-9]*"
                            value={ozelSonMetin}
                            onChange={e => yazildi(e.target.value, setOzelSonMetin, setOzelSon)}
                            onFocus={e => e.target.select()}
                            onBlur={sonBitti}
                            onKeyDown={e => { if (e.key === "Enter") e.currentTarget.blur() }}
                            style={kutu}
                          />
                          <span style={{ fontSize: "11px", color: theme.accent, fontWeight: 600 }}>
                            {secili} âyet
                          </span>
                        </div>
                        <div style={{ fontSize: "10px", color: theme.textSecondary, opacity: 0.75, marginTop: "5px", lineHeight: 1.45 }}>
                          {sureBilgi?.sureAdi ? `${sureBilgi.sureAdi} sûresi 1–${enCok} arası. ` : ""}
                          En fazla {azamiAyet} âyet seçebilirsiniz.
                          {kirpildi ? ` Kullanılan aralık: ${bas}–${son}.` : ""}
                        </div>
                      </div>
                    )
                  })()}
                  <div style={{ fontSize: "10px", color: theme.textSecondary, opacity: 0.75, marginBottom: "12px", lineHeight: 1.45 }}>
                    {videoParcalari.length > 1
                      ? `Ekranda ${videoParcalari.length} bölüm sırayla görünür; her âyetin meali altında eş zamanlı geçer.`
                      : "Tek âyet gösterilir."}
                    {(kapsam === "sure" || kapsam === "sayfa") && ` En fazla ${azamiAyet} âyet alınır.`}
                    {kapsam === "sayfa" && " Sayfa iki sûreye taşıyorsa her âyet kendi sûresinin adıyla gösterilir."}
                    {videoParcalari.some(p => p.tip === "besmele") && " Sûre başından başlandığı için besmele ile açılır."}
                  </div>
                </>
              )}

              <AyarBaslik theme={theme} ikon={Move} ust={ayet && ayetListesiAl ? 4 : 18}>Resim hareketi</AyarBaslik>
              <Secim theme={theme} kucuk deger={hareket} onSec={setHareket} secenekler={HAREKETLER} />
              {SAHNE_HAREKETI.has(hareket) && (
                <>
                  <AyarBaslik theme={theme} ikon={Gauge}>Hız</AyarBaslik>
                  <Secim theme={theme} kucuk deger={hiz} onSec={setHiz} secenekler={HIZLAR} />
                </>
              )}
              {/* VİDEO YERLEŞİMİ — slaytta video varken (izleme moduyla ortak ayar) */}
              {slaytAktif && slaytResimleri.some(id => galeriOgeleri[id]?.video) && (
                <>
                  <AyarBaslik theme={theme} ikon={Frame}>Video yerleşimi</AyarBaslik>
                  <Secim theme={theme} kucuk deger={videoYerlesim} onSec={v => izGuncelle("izleme", { videoYerlesim: v })} secenekler={VIDEO_YERLESIMLERI} />
                </>
              )}
              {/* VİDEO HAREKETİ — slaytta video varken (izleme moduyla ortak ayar) */}
              {hareket !== "yok" && slaytAktif && slaytResimleri.some(id => galeriOgeleri[id]?.video) && (
                <>
                  <AyarBaslik theme={theme} ikon={Move}>Video hareketi</AyarBaslik>
                  <Secim theme={theme} kucuk deger={videoHareket} onSec={v => izGuncelle("izleme", { videoHareket: v })}
                    secenekler={[{ id: "sabit", ad: "Sabit" }, { id: "resim", ad: "Resimle aynı" }]} />
                </>
              )}

              {/* Kâri sesi yalnız âyet bilgisi geldiğinde (KuranOkuma) anlamlı */}
              {ayet && sesUrlAl && (
                <>
                  <AyarBaslik theme={theme} ikon={Volume2}>Ses</AyarBaslik>
                  <Secim theme={theme} kucuk deger={sesAcik ? "kari" : "sessiz"} onSec={v => setSesAcik(v === "kari")}
                    secenekler={[{ id: "kari", ad: "Kâri okusun", Ikon: Volume2 }, { id: "sessiz", ad: "Sessiz", Ikon: VolumeX }]} />
                  {sesAcik && kariler && kariler.length > 0 && (
                    <div style={{ marginTop: "6px" }}>
                      <Secim theme={theme} kucuk deger={kariId} onSec={id => onKari && onKari(id)}
                        secenekler={kariler.map(k => ({ id: k.id, ad: k.label || k.ad || k.id }))} />
                    </div>
                  )}
                  {sesAcik && (
                    <div style={{ fontSize: "10.5px", color: theme.textSecondary, opacity: 0.8, margin: "6px 2px 0" }}>
                      Videonun süresi âyetin okunuş süresi kadar olur.
                      {sesCihazda && sesCihazda.toplam > 0 && (sesCihazda.var === sesCihazda.toplam
                        ? " Bu bölümün sesleri cihazda; internetsiz ve daha hızlı hazırlanır."
                        : " Sesler indirilmiş olursa internetsiz ve daha hızlı hazırlanır.")}
                    </div>
                  )}
                </>
              )}

              <AyarBaslik theme={theme} ikon={Film}>Çözünürlük</AyarBaslik>
              <Secim theme={theme} kucuk deger={videoKalite} onSec={setVideoKalite}
                secenekler={[{ id: 720, ad: "720p", alt: "hızlı" }, { id: 1080, ad: "1080p", alt: "net" }]} />
              <div style={{ fontSize: "10.5px", color: theme.textSecondary, opacity: 0.8, margin: "6px 2px 0", lineHeight: 1.45 }}>
                {hizliKayitOlasi()
                  ? "Bu cihazda video, süresinden çok daha kısa sürede hazırlanır."
                  : "Kayıt gerçek zamanlıdır: video ne kadar sürüyorsa hazırlanması da o kadar sürer. 720p telefonlarda daha akıcı kaydeder."}
              </div>

              {/* Ses yoksa süre seçilir (çoklu âyette süre seslerden gelir) */}
              {(!ayet || !sesUrlAl || !sesAcik) && videoParcalari.length === 1 && (
                <>
                  <AyarBaslik theme={theme} ikon={Timer}>Süre</AyarBaslik>
                  <Secim theme={theme} kucuk deger={videoSure} onSec={setVideoSure} secenekler={SURELER} />
                </>
              )}
            </>
          )}
        </div>

        {/* ALT: indir */}
        <div style={{
          padding: "10px 14px", borderTop: `1px solid ${theme.border}`,
          display: "flex", alignItems: "center", gap: "10px", flexShrink: 0,
        }}>
          <span style={{
            flex: 1, fontSize: "11px", color: theme.textSecondary, minWidth: 0, overflow: "hidden", lineHeight: 1.35,
            // Telefonda uzun durum metni (ör. kalan süre) ikinci satıra iner; en çok 2 satır
            whiteSpace: "pre-line", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical",
          }}>
            {durum || (mod === "video"
              ? (kayitDurum === "kayit"
                  ? `Kaydediliyor… ${kalanSn} sn kaldı`
                  : `${olcu.w}×${olcu.h} · ${mimeTuru && mimeTuru.includes("mp4") ? "MP4" : "WEBM"} · ~${Math.ceil(toplamSureRef.current || videoSure)} sn`)
              : `${olcu.w}×${olcu.h} px · PNG`)}
          </span>

          {mod === "video" && kayitDurum !== "hazir" ? (
            <>
              {/* Kayıt gerçek zamanlıdır: ilerleme çubuğu + durdurma */}
              <span style={{
                flexShrink: 0, width: isMobile ? "70px" : "110px", height: "6px",
                borderRadius: "3px", background: `${theme.accent}22`, overflow: "hidden",
              }}>
                <span style={{
                  display: "block", height: "100%", width: `${Math.round(ilerleme * 100)}%`,
                  background: theme.accent, transition: "width .12s linear",
                }} />
              </span>
              {/* DİNLE — kayıt sürerken sesi hoparlörden duymak isteyen için. Kapalı başlar;
                  kapalı olması kâri sesinin videoya KAYDEDİLMESİNİ engellemez. */}
              {sesAcik && !hizliSurer && (
                <button
                  onClick={() => setDinle(v => !v)}
                  title={dinle ? "Dinlemeyi kapat (kayda etkisi yok)" : "Kayıt sürerken sesi dinle"}
                  style={{
                    display: "flex", alignItems: "center", gap: "5px",
                    padding: isMobile ? "9px 11px" : "10px 13px", borderRadius: "10px",
                    border: `1px solid ${dinle ? theme.accent : theme.border}`,
                    background: dinle ? `${theme.accent}1e` : "transparent",
                    color: dinle ? theme.accent : theme.textSecondary, cursor: "pointer",
                    fontSize: isMobile ? "12px" : "13px", fontWeight: 600, whiteSpace: "nowrap",
                  }}
                >
                  {dinle ? <Volume2 size={14} /> : <VolumeX size={14} />} Dinle
                </button>
              )}
              <button
                onClick={() => {
                  kayitIptalRef.current = true
                  try { iptalRef.current && iptalRef.current.abort() } catch { /* yoksay */ }
                  setDurum("Durduruluyor…")
                }}
                style={{
                  display: "flex", alignItems: "center", gap: "6px",
                  padding: isMobile ? "10px 14px" : "11px 18px", borderRadius: "10px",
                  border: `1px solid ${theme.border}`, background: "transparent",
                  color: theme.textSecondary, cursor: "pointer",
                  fontSize: isMobile ? "13px" : "14px", fontWeight: 600,
                }}
              ><CircleStop size={15} /> Durdur</button>
            </>
          ) : (<>
            {/* HAZIR DOSYA — paylaşım/indirme kendiliğinden çalışmazsa (uzun video kaydından
                sonra tarayıcı "taze kullanıcı hareketi" ister) kullanıcı buradan alır. */}
            {hazirDosya && (
              <a
                href={hazirDosya.url}
                download={hazirDosya.ad}
                onClick={e => { e.preventDefault(); hazirDosyayiAl() }}
                style={{
                  display: "flex", alignItems: "center", gap: "6px", flexShrink: 0,
                  padding: isMobile ? "10px 13px" : "11px 16px", borderRadius: "10px",
                  border: `1px solid ${theme.accent}`, background: `${theme.accent}1e`,
                  color: theme.accent, cursor: "pointer", textDecoration: "none",
                  fontSize: isMobile ? "12px" : "13px", fontWeight: 600, whiteSpace: "nowrap",
                }}
              >
                <Download size={15} /> {hazirDosya.tur.startsWith("video") ? "Videoyu al" : "Görseli al"}
              </a>
            )}
            <button
              onClick={mod === "video" ? videoKaydet : indir}
              disabled={calisiyor}
              style={{
                display: "flex", alignItems: "center", gap: "7px",
                padding: isMobile ? "10px 16px" : "11px 20px", borderRadius: "10px", border: "none",
                background: theme.accent, color: "#fff", cursor: calisiyor ? "wait" : "pointer",
                fontSize: isMobile ? "13px" : "14px", fontWeight: 600,
              }}
            >
              {calisiyor ? <Loader2 size={15} />
                : mod === "video" ? <Film size={15} />
                : (navigator.canShare ? <Share2 size={15} /> : <Download size={15} />)}
              {mod === "video" ? "Videoyu Kaydet" : "Kaydet"}
            </button>
          </>)}
        </div>
      </div>
      <GaleriDuzenleyici acik={galeriDuzenleAcik} kapat={() => setGaleriDuzenleAcik(false)} theme={theme}
        isMobile={isMobile} baglam="gorsel" onEklendi={() => setArkaId("galeri")} />
    </div>
  )
}
