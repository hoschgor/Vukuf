import { useState } from "react"
import { Music2, ChevronDown, Check } from "lucide-react"
import { KARILAR } from "../data/hooks/useAudioPlayer"

export default function KariSecici({ kariId, setKariId, theme, barUiOlcegi = 1, barKonum = "alt" }) {
  const [acik, setAcik] = useState(false)

  const aktifKari = KARILAR.find(k => k.id === kariId) || KARILAR[0]

  function secKari(id) {
    setKariId(id)
    setAcik(false)
  }

  return (
    <div style={{ position: "relative" }}>
      {/* Büyük harf (29 Eylül 2026) — ayarlar panelindeki öbür bölüm
          başlıklarıyla (BAR KONUMU, OTOMATİK GİZLEME…) aynı görünüm */}
      {/* yp-tam-baslik: yatay telefonda Kârî iki sütunu kapladığında başlık
          satırın ortasında, iki yanı çizgili (bkz. yatayDuzen.js) */}
      <div className="yp-tam-baslik" style={{
        fontSize: `${Math.round(11 * barUiOlcegi)}px`,
        color: theme.textSecondary,
        marginBottom: "8px",
        letterSpacing: "1px",
      }}>
        KÂRÎ (OKUYUCU)
      </div>

      {/* Seçili kari butonu */}
      <button
        onClick={() => setAcik(!acik)}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "8px 12px",
          borderRadius: "8px",
          border: `1px solid ${acik ? theme.accent : theme.border}`,
          background: acik ? `${theme.accent}10` : theme.background,
          color: theme.text,
          fontSize: `${Math.round(13 * barUiOlcegi)}px`,
          cursor: "pointer",
          transition: "all 0.15s",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <Music2 size={Math.round(13 * barUiOlcegi)} color={theme.accent} />
          <span>{aktifKari.label}</span>
        </div>
        <ChevronDown
          size={Math.round(13 * barUiOlcegi)}
          color={theme.textSecondary}
          style={{
            transform: acik ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 0.2s",
          }}
        />
      </button>

      {/* Dropdown - yukarı doğru açılır */}
      {acik && (
        <div style={{
          position: "absolute",
          bottom: "calc(100% + 4px)",
          left: 0,
          right: 0,
          background: theme.surface,
          border: `1px solid ${theme.border}`,
          borderRadius: "10px",
          overflow: "hidden",
          zIndex: 10,
          boxShadow: "0 -4px 20px rgba(0,0,0,0.12)",
          maxHeight: "200px",
          display: "flex",
          flexDirection: "column",
        }}>
          {/* Başlık - sabit kalır */}
          <div style={{
            padding: "8px 8px",
            fontSize: `${Math.round(10 * barUiOlcegi)}px`,
            color: theme.textSecondary,
            letterSpacing: "1px",
            borderBottom: `1px solid ${theme.border}`,
            flexShrink: 0,
          }}>
            KÂRÎ (OKUYUCU)
          </div>

          {/* Liste - kaydırılabilir */}
          <div style={{
            overflowY: "auto",
            flex: 1,
          }}>
            {KARILAR.map((kari, i) => {
              const secili = kariId === kari.id
              return (
                <button
                  key={kari.id}
                  onClick={() => secKari(kari.id)}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "10px 12px",
                    border: "none",
                    borderBottom: i < KARILAR.length - 1
                      ? `1px solid ${theme.border}`
                      : "none",
                    background: secili ? `${theme.accent}12` : "transparent",
                    color: secili ? theme.accent : theme.text,
                    fontSize: `${Math.round(13 * barUiOlcegi)}px`,
                    cursor: "pointer",
                    textAlign: "left",
                    transition: "background 0.1s",
                  }}
                  onMouseEnter={e => {
                    if (!secili) e.currentTarget.style.background = `${theme.accent}08`
                  }}
                  onMouseLeave={e => {
                    if (!secili) e.currentTarget.style.background = "transparent"
                  }}
                >
                  <span>{kari.label}</span>
                  {secili && <Check size={Math.round(13 * barUiOlcegi)} color={theme.accent} />}
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
