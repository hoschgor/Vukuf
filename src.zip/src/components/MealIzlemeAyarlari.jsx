/* VUKUF — MEAL & İZLEME AYARLARI PANELİ
   src/components/MealIzlemeAyarlari.jsx

   Tek panel, iki bölüm. PlayerBar'a üçüncü bir düğme eklemek yerine buraya iki
   yerden giriliyor: meal popup'ının kenarındaki dişli ve izleme modundaki dişli.
   Hangi yerden açıldıysa o bölüm seçili açılıyor. Ayarlar `data/izlemeAyar.js`de.

   7 Ekim 2026 (kullanıcı: "butonları daha kullanışlı yapalım, hıfz modundaki gibi"):
   • Yana kayan çip şeritleri yerine hıfz panelindeki BÖLÜNMÜŞ DÜĞMELER (Secim) ve
     AÇ/KAPA SATIRLARI (Anahtar) — ortak `AyarOgeleri.jsx`. Seçenekler satıra
     sarıldığı için telefonda hiçbiri kesik kalmıyor.
   • İzleme bölümü üç sekmeye ayrıldı: Arka plan · Hareket ve efekt · Görünüm.
     Panel kısaldı, aranan ayar bir dokunuşta bulunuyor.
   • Arka planlar küçük resimli kutular: galeri resimleri, hazır resimler, desenler. */

import { useEffect, useMemo, useState } from "react"
import {
  X, Image as ImageIcon, Sparkles, LayoutTemplate, MonitorPlay, Languages,
  Eye, Hand, Type, Move, Wind, Sun, Frame, Layers, Palette, Highlighter, Pipette,
} from "lucide-react"
import { DESENLER, GORSELLER } from "../data/arkaplanlar"
import { useIzlemeAyar, ayarOku } from "../data/izlemeAyar"
import { HAREKETLER, HIZLAR, HAVALAR, ISIKLAR, VIDEO_YERLESIMLERI } from "../data/izlemeSahne"
import { galeriBlobu, eskiGorselVarsaTasi } from "../data/izlemeGaleri"
import { Secim, Anahtar, AyarBaslik, ArkaPlanIzgara, desenOnizleme, useGaleriOgeleri, RenkSecici, SusRenkleri } from "./AyarOgeleri"
import GaleriDuzenleyici, { GaleriKolaj, GaleriOzeti } from "./GaleriDuzenleyici"
import { ONERILEN_RENKLER, sonRenkleriOku, sonRenkEkle, ISARET_RENKLERI } from "./GorselOlustur"

const KONUMLAR   = [{ id: "ust", ad: "Üst" }, { id: "orta", ad: "Orta" }, { id: "alt", ad: "Alt" }]
const GENISLIKLER = [{ id: "dar", ad: "Dar" }, { id: "orta", ad: "Orta" }, { id: "genis", ad: "Geniş" }]
const CERCEVELER = [
  { id: "yok", ad: "Yok" }, { id: "ince", ad: "İnce" }, { id: "cift", ad: "Çift" },
  { id: "kose", ad: "Köşe" }, { id: "kemer", ad: "Kemer" }, { id: "kartus", ad: "Kartuş" },
]
const KARARTMALAR = [
  { id: "yok", ad: "Yok" }, { id: "az", ad: "Az" }, { id: "orta", ad: "Orta" }, { id: "cok", ad: "Çok" },
]
const YAZI_BOYLARI = [12, 13, 14, 15, 16, 18].map(b => ({ id: b, ad: String(b) }))
const SUSLER = [{ id: "dal", ad: "Dallar" }, { id: "tezhip", ad: "Tezhip" }]
const BOLUMLER = [
  { id: "izleme", ad: "İzleme modu", Ikon: MonitorPlay },
  { id: "meal", ad: "Meal penceresi", Ikon: Languages },
]
const SEKMELER = [
  { id: "arka", ad: "Arka plan", Ikon: ImageIcon },
  { id: "efekt", ad: "Hareket", Ikon: Sparkles },
  { id: "gorunum", ad: "Görünüm", Ikon: LayoutTemplate },
]

export default function MealIzlemeAyarlari({ acik, kapat, theme, isMobile, odak = "meal" }) {
  const [ayar, guncelle] = useIzlemeAyar()
  const iz = ayar.izleme
  const [bolum, setBolum] = useState(odak)
  const [sekme, setSekme] = useState("arka")
  useEffect(() => { if (acik) setBolum(odak) }, [acik, odak])

  // Dosyası gerçekten olan hazır fotoğraflar (yoksa listede hiç görünmesin)
  const [gorseller, setGorseller] = useState([])
  useEffect(() => {
    if (!acik) return
    let iptal = false
    Promise.all(GORSELLER.map(g => new Promise(cz => {
      const im = new Image()
      im.onload = () => cz(g); im.onerror = () => cz(null); im.src = g.src
    }))).then(s => { if (!iptal) setGorseller(s.filter(Boolean)) })
    return () => { iptal = true }
  }, [acik])

  // Eski tek resim (dataURL) varsa galeriye taşınsın — panel izleme açılmadan da açılabiliyor
  useEffect(() => { if (acik) eskiGorselVarsaTasi() }, [acik])

  useEffect(() => {
    if (!acik) return
    const tus = (e) => { if (e.key === "Escape") kapat?.() }
    document.addEventListener("keydown", tus)
    return () => document.removeEventListener("keydown", tus)
  }, [acik, kapat])

  const galeri = iz.galeri || []
  // Galeri (resim + video) — ızgarada TEK "Galerim" kutusu; düzenleme ayrı sayfada (13 Ekim 2026)
  const ogeler = useGaleriOgeleri(acik ? galeri : [], galeriBlobu)
  const [duzenleAcik, setDuzenleAcik] = useState(false)
  const [sonRenkler, setSonRenkler] = useState(() => sonRenkleriOku())   // görsel oluşturmayla ortak
  const galeriSecili = (iz.arka === "galeri" || iz.arka === "ozel") && galeri.length > 0

  const arkaOgeleri = useMemo(() => [
    {
      id: "galeri", ad: galeri.length >= 2 ? "Slayt" : "Galerim", secili: galeriSecili,
      icerik: <GaleriKolaj theme={theme} galeri={galeri} ogeler={ogeler} />,
    },
    ...gorseller.map(g => ({ id: g.id, ad: g.ad, resim: g.src, secili: iz.arka === g.id })),
    ...DESENLER.map(d => ({ id: d.id, ad: d.ad, resim: desenOnizleme(d), secili: iz.arka === d.id })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
  ], [galeri.join(","), ogeler, gorseller, iz.arka, galeriSecili, theme])

  if (!acik) return null

  // Galerim boşken kutuya dokunmak düzenleyiciyi açar (ilk eklenen öğeyle seçilir)
  const arkaSec = (id) => {
    if (id === "galeri") {
      if (!galeri.length) { setDuzenleAcik(true); return }
      guncelle("izleme", { arka: "galeri" })
      return
    }
    guncelle("izleme", { arka: id })
  }

  const ipucu = { fontSize: "11px", color: theme.textSecondary, lineHeight: 1.5, margin: "8px 2px 0" }

  /* ── İZLEME: ARKA PLAN ─────────────────────────────────────────────── */
  const arkaSekmesi = (
    <>
      <AyarBaslik theme={theme} ikon={ImageIcon} ust={4}>Arka plan</AyarBaslik>
      <ArkaPlanIzgara theme={theme} ogeler={arkaOgeleri} onSec={arkaSec} />
      {galeriSecili ? (
        <GaleriOzeti theme={theme} galeri={galeri} ogeler={ogeler} iz={iz} onDuzenle={() => setDuzenleAcik(true)} />
      ) : (
        <p style={ipucu}>
          Galerim kutusuyla kendi resim ve videolarınızı ekleyebilirsiniz; birden çok öğe slayt gösterisi olur.
        </p>
      )}
    </>
  )

  /* ── İZLEME: HAREKET VE EFEKT ───────────────────────────────────────── */
  const efektSekmesi = (
    <>
      <AyarBaslik theme={theme} ikon={Move} ust={4}>Resim hareketi</AyarBaslik>
      <Secim theme={theme} kucuk deger={iz.hareket} onSec={v => guncelle("izleme", { hareket: v })} secenekler={HAREKETLER} />
      {iz.hareket !== "sabit" && (
        <>
          <AyarBaslik theme={theme} ikon={Layers}>Hız</AyarBaslik>
          <Secim theme={theme} kucuk deger={iz.hiz} onSec={v => guncelle("izleme", { hiz: v })} secenekler={HIZLAR} />
        </>
      )}
      {/* VİDEO YERLEŞİMİ ve HAREKETİ (13 Ekim 2026) — galeride video varken. Çekim çoğu
          zaman zaten hareketli olduğu için hareket varsayılan sabit. */}
      {galeri.some(id => ogeler[id]?.video) && (
        <>
          <AyarBaslik theme={theme} ikon={Frame}>Video yerleşimi</AyarBaslik>
          <Secim theme={theme} kucuk deger={iz.videoYerlesim || "oto"} onSec={v => guncelle("izleme", { videoYerlesim: v })} secenekler={VIDEO_YERLESIMLERI} />
          {(iz.videoYerlesim || "oto") === "oto" && <p style={ipucu}>Otomatik: ekranla aynı yöndeki video ekranı doldurur; yönü farklı olan (yatay ekranda dikey video gibi) bütünüyle ortada görünür, kenarlar videonun bulanık hâliyle dolar.</p>}
        </>
      )}
      {iz.hareket !== "sabit" && galeri.some(id => ogeler[id]?.video) && (
        <>
          <AyarBaslik theme={theme} ikon={Move}>Video hareketi</AyarBaslik>
          <Secim theme={theme} kucuk deger={iz.videoHareket === "resim" ? "resim" : "sabit"} onSec={v => guncelle("izleme", { videoHareket: v })}
            secenekler={[{ id: "sabit", ad: "Sabit" }, { id: "resim", ad: "Resimle aynı" }]} />
        </>
      )}
      <AyarBaslik theme={theme} ikon={Wind}>Hava</AyarBaslik>
      <Secim theme={theme} kucuk deger={iz.hava} onSec={v => guncelle("izleme", { hava: v })} secenekler={HAVALAR} />
      <AyarBaslik theme={theme} ikon={Sun}>Işık</AyarBaslik>
      <Secim theme={theme} kucuk deger={iz.isik} onSec={v => guncelle("izleme", { isik: v })} secenekler={ISIKLAR} />
    </>
  )

  /* ── İZLEME: GÖRÜNÜM ─────────────────────────────────────────────────── */
  const gorunumSekmesi = (
    <>
      <AyarBaslik theme={theme} ikon={Frame} ust={4}>Çerçeve</AyarBaslik>
      <Secim theme={theme} kucuk deger={iz.cerceve} onSec={v => guncelle("izleme", { cerceve: v })} secenekler={CERCEVELER} sutun={3} />
      <AyarBaslik theme={theme} ikon={Eye} not="yazının okunurluğu">Karartma</AyarBaslik>
      <Secim theme={theme} kucuk deger={iz.karartma} onSec={v => guncelle("izleme", { karartma: v })} secenekler={KARARTMALAR} />
      {/* 8 Ekim 2026: izlemede de yazı rengi + vakıf işaretlerini renklendirme */}
      <AyarBaslik theme={theme} ikon={Palette} not="otomatik: zemine göre">Yazı rengi</AyarBaslik>
      <RenkSecici theme={theme} deger={iz.yaziRengi || null} onSec={v => guncelle("izleme", { yaziRengi: v })}
        oneriler={ONERILEN_RENKLER} sonRenkler={sonRenkler} onSonEkle={r => setSonRenkler(sonRenkEkle(r))} />
      <AyarBaslik theme={theme} ikon={Palette} not="sûre adı · kaynak · rahle">Süs renkleri</AyarBaslik>
      <SusRenkleri theme={theme}
        degerler={{ sureAdi: iz.sureAdiRengi || null, kaynak: iz.kaynakRengi || null, rahle: iz.rahleRengi || null }}
        onSec={(alan, v) => guncelle("izleme", { [`${alan}Rengi`]: v })}
        oneriler={ONERILEN_RENKLER} sonRenkler={sonRenkler} onSonEkle={r => setSonRenkler(sonRenkEkle(r))} />
      <AyarBaslik theme={theme} ikon={Highlighter} not="vakıf işaretleri">İşaret rengi</AyarBaslik>
      <Secim theme={theme} kucuk deger={iz.isaretRenk || "kapali"} onSec={v => guncelle("izleme", { isaretRenk: v })} secenekler={ISARET_RENKLERI} />
      {iz.isaretRenk === "ozel" && (
        <label style={{
          position: "relative", display: "inline-flex", alignItems: "center", gap: "6px", marginTop: "6px",
          padding: "6px 11px", borderRadius: "999px", border: `1px solid ${theme.border}`,
          fontSize: "12px", fontWeight: 600, color: theme.textSecondary, cursor: "pointer", overflow: "hidden",
        }}>
          <Pipette size={13} /> İşaret rengini seç
          <span style={{ width: "16px", height: "16px", borderRadius: "50%", background: iz.isaretOzel || "#e0503c", border: `1px solid ${theme.border}` }} />
          <input type="color" value={iz.isaretOzel || "#e0503c"} onChange={e => guncelle("izleme", { isaretOzel: e.target.value })}
            style={{ position: "absolute", inset: 0, opacity: 0, cursor: "pointer", border: "none", padding: 0 }} />
        </label>
      )}
      <div style={{ height: "12px" }} />
      <Anahtar theme={theme} ikon={Languages} acik={!!iz.meal} onDegis={v => guncelle("izleme", { meal: v })}
        baslik="Meali de göster" aciklama="Arapçanın altında Türkçe meal." />
      <Anahtar theme={theme} ikon={Hand} acik={!!iz.gizliDugme} onDegis={v => guncelle("izleme", { gizliDugme: v })}
        baslik="Gizli butonlar"
        aciklama="Ekranda düğme durmaz. Sola sürükle: önceki · sağa: sonraki · aşağı: çıkış · yukarı: ayarlar · ortaya dokun: duraklat/devam." />
    </>
  )

  /* ── MEAL PENCERESİ ──────────────────────────────────────────────────── */
  const mealBolum = (
    <>
      <AyarBaslik theme={theme} ust={4}
        not={ayar.meal.kaydir !== 0 ? (
          <button onClick={() => guncelle("meal", { kaydir: 0 })} style={{
            border: "none", background: "none", padding: 0, cursor: "pointer", fontFamily: "inherit",
            fontSize: "10.5px", fontWeight: 600, color: theme.accent,
          }}>İnce ayarı sıfırla</button>
        ) : null}>Konum</AyarBaslik>
      <Secim theme={theme} kucuk deger={ayar.meal.konum} onSec={v => guncelle("meal", { konum: v, kaydir: 0 })} secenekler={KONUMLAR} />
      <AyarBaslik theme={theme}>Genişlik</AyarBaslik>
      <Secim theme={theme} kucuk deger={ayar.meal.genislik} onSec={v => guncelle("meal", { genislik: v })} secenekler={GENISLIKLER} />
      <AyarBaslik theme={theme} ikon={Type} not="px">Yazı boyu</AyarBaslik>
      <Secim theme={theme} kucuk deger={ayar.meal.yaziBoyu} onSec={v => guncelle("meal", { yaziBoyu: v })} secenekler={YAZI_BOYLARI} sutun={6} />
      <AyarBaslik theme={theme}>Süs</AyarBaslik>
      <Secim theme={theme} kucuk deger={ayar.meal.sus || "dal"} onSec={v => guncelle("meal", { sus: v })} secenekler={SUSLER} />
      <div style={{ height: "12px" }} />
      <Anahtar theme={theme} acik={!!ayar.meal.hat} onDegis={v => guncelle("meal", { hat: v })}
        baslik="Sûre adı hattı" aciklama="Pencere başlığında sûre adı, sûre başlığındaki hat yazısıyla." />
    </>
  )

  return (
    <>
      <div onClick={kapat} style={{ position: "fixed", inset: 0, zIndex: 620, background: "rgba(0,0,0,0.35)" }} />
      <div style={{
        // z-index HER ŞEYİN ÜSTÜNDE: bu panel hem meal penceresinden (z 92) hem de
        // TAM EKRAN izleme modundan (z 500) açılıyor; 401'de kalırsa izlemede görünmezdi.
        position: "fixed", zIndex: 621,
        left: "50%", transform: "translateX(-50%)",
        bottom: isMobile ? 0 : "6vh",
        width: isMobile ? "100%" : "min(560px, 92vw)",
        maxHeight: "78vh", overflowY: "auto", overscrollBehavior: "contain",
        background: theme.surface,
        border: `1px solid ${theme.border}`,
        borderRadius: isMobile ? "16px 16px 0 0" : "16px",
        boxShadow: "0 -6px 28px rgba(0,0,0,0.28)",
        padding: "12px 14px calc(18px + env(safe-area-inset-bottom))",
        boxSizing: "border-box",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
          <span style={{ fontSize: "14px", fontWeight: 600, color: theme.text }}>Meal ve izleme ayarları</span>
          <button onClick={kapat} aria-label="Kapat" style={{
            display: "flex", padding: "4px", border: "none", background: "none",
            cursor: "pointer", color: theme.textSecondary,
          }}><X size={16} /></button>
        </div>

        <Secim theme={theme} deger={bolum} onSec={setBolum} secenekler={BOLUMLER} />

        {bolum === "izleme" ? (
          <>
            <div style={{ marginTop: "10px" }}>
              <Secim theme={theme} kucuk deger={sekme} onSec={setSekme} secenekler={SEKMELER} />
            </div>
            <div style={{ marginTop: "10px" }}>
              {sekme === "arka" ? arkaSekmesi : sekme === "efekt" ? efektSekmesi : gorunumSekmesi}
            </div>
          </>
        ) : (
          <div style={{ marginTop: "10px" }}>{mealBolum}</div>
        )}
      </div>
      <GaleriDuzenleyici acik={duzenleAcik} kapat={() => setDuzenleAcik(false)} theme={theme} isMobile={isMobile}
        baglam="izleme" onEklendi={() => guncelle("izleme", { arka: "galeri" })} />
    </>
  )
}
