/* ═══════════════════════════════════════════════════════════════════════════
   VUKUF — VERİLER BÖLÜMÜ (Ayarlar panelinin içinde)
   src/components/VeriAyarlari.jsx

   Yedek al · Geri yükle · Sıfırla. Veri işinin tamamı `src/data/vukufVeri.js`
   içinde; burası yalnız arayüz.

   ── TASARIM KARARLARI ──────────────────────────────────────────────────────
   • HER YIKICI İŞLEM ÇİFT ONAYLI. İlk dokunuş düğmeyi "Emin misiniz?" hâline
     getirir, ikinci dokunuş uygular; 4 saniye dokunulmazsa kendiliğinden geri
     döner. Kullanıcının OkumaEkrani'nda kullandığı `OnayliSil` kalıbının aynısı.
   • SİLMEDEN ÖNCE YEDEK. Sıfırlama bölümünün başında yedek alma hatırlatması
     duruyor; "Her şeyi sıfırla" ise yedek alınmadıysa ayrıca uyarıyor.
   • SAYIYLA GÖSTER. Her kategori "kaç kayıt · ne kadar yer" ile listeleniyor.
     Boş kategorinin düğmesi kapalı — "sildim" hissi verip hiçbir şey yapmasın.
   • "DİĞER" KATEGORİSİ GİZLENMİYOR. Sınıflandırılmamış anahtarlar varsa
     kullanıcı bunu görmeli; ileride eklenen bir özelliğin anahtarı sessizce
     yanlış kategoride silinmesin diye.
   • iOS PAYI: ana ekrana eklenmiş uygulamada dosya indirme sessizce
     düşebiliyor. Bu yüzden indirmenin yanında "panoya kopyala", geri
     yüklemede de dosya seçmenin yanında "yapıştır" yolu var.
   • GERİ YÜKLEDİKTEN SONRA SAYFA YENİLENİR. Değerlerin çoğu açılışta bir kez
     state'e okunuyor; yenilemeden arayüz eski değerleri göstermeye devam eder
     ve kullanıcı "geri yükleme çalışmadı" sanır.
   ═══════════════════════════════════════════════════════════════════════════ */

import { useState, useEffect, useRef, useMemo } from "react"
import { Download, Upload, Copy, Check, AlertTriangle, Trash2, FileText, X, HardDrive, Wifi, Loader, CloudOff, BookOpen, Search, Music, RotateCw } from "lucide-react"
import Katlanir from "./Katlanir"
import { destekVar, swSurum, onbellekDokumu, onbellegiTemizle, kabukDurumu, onYukle } from "../data/cevrimdisi"
import { kategoriler } from "../data/kitaplar"
import { normHarf } from "../data/okumaKayit"
import { KARILAR, sesTeshisMetni, sesTeshisTemizle } from "../data/hooks/useAudioPlayer"
// GEÇİCİ — dönme teşhisi (ölçüm bitince bu satır ve aşağıdaki bölüm silinecek)
import { DENEY, deneyAyarla, teshisAcikMi, teshisAyarla, donmeTeshisMetni, donmeTeshisTemizle } from "../data/donmeTeshis"
import {
  mushafYukle, sureListesi, cuzListesi, sesAdresleri,
  boyutOrnekle, tahminiBoyut, sesAnahtarlari, sesOnbellegiSil,
} from "../data/sesIndirme"
import {
  envanter, toplamBoyut, boyutMetni,
  yedekIndir, yedekMetni, yedekDosyaAdi,
  dosyadanOku, yedekCozumle, yedekYaz, sifirla, sonYedekYaz,
} from "../data/vukufVeri"
import { hifzTazele } from "../data/hifz"
import DepolamaGorunumu from "./DepolamaGorunumu"
import { boyutYaz } from "../data/depolamaOlcum"

/* ── ÇEVRİMDIŞI İÇİN İNDİRİLECEK ADRESLER ───────────────────────────────────
   Liste ELLE YAZILMIYOR: katalogdan (kitaplar.js) türetiliyor. Yeni bir kitap
   eklendiğinde burada hiçbir şey değişmiyor — elle liste tutmak, yeni kitabın
   sessizce çevrimdışı kapsamı dışında kalmasına yol açardı.
   İçindekiler dosyasının adı OkumaEkrani'ndeki KURALIN AYNISIYLA türetiliyor
   (`-metin.json` → `-icindekiler.json`); her kitapta olmayabilir, olmayanlar
   indirmede "bulunamadı" sayılır ve sessizce geçilir. */
function kitapListesi() {
  const gorulen = new Set()
  const liste = []
  for (const kisim of kategoriler || []) {
    for (const alim of kisim.alimler || []) {
      const altlar = (alim.altKategoriler && alim.altKategoriler.length)
        ? alim.altKategoriler
        : [{ kitaplar: alim.kitaplar || [] }]
      for (const alt of altlar) {
        for (const b of alt.kitaplar || []) {
          if (!b || !b.dosya || gorulen.has(b.dosya)) continue
          gorulen.add(b.dosya)
          liste.push({
            id: b.id,
            ad: b.baslik || b.id,
            yazar: b.yazar || alim.isim || "",
            // Arama bunlarda da eşleşiyor: "Bediüzzaman" yazınca o âlimin
            // bütün eserleri, kısım adı yazınca o rafın tamamı süzülüyor.
            alim: alim.isim || "",
            kisim: kisim.baslik || "",
            adresler: [
              `/kitap-metin/${b.dosya}`,
              `/bolumler/${b.dosya.replace(/-metin\.json$/, "-icindekiler.json")}`,
            ],
          })
        }
      }
    }
  }
  return liste
}

/* Kur'ân-ı Kerîm katalogda bir "kitap" olarak yer almıyor (kendi ekranı var),
   ama çevrimdışı hazırlıkta en çok istenen şey o. Listeye elle bir girdi olarak
   ekleniyor ki seçilebilsin ve durumu görünsün. */
const KURAN_GIRDISI = {
  id: "__kuran",
  ad: "Kur'ân-ı Kerîm",
  yazar: "",
  alim: "", kisim: "Kur'ân",
  adresler: ["/kuran-mushaf.json", "/kuran.json", "/sayfa-harita.json"],
}

// Mushaf tarafının çekirdek dosyaları (fetch ile alınanlar; import edilenler
// zaten JS paketinin içinde ve kabukla birlikte saklanıyor).
const KURAN_ADRESLERI = ["/kuran-mushaf.json", "/kuran.json", "/sayfa-harita.json"]

/* Yerel font dosyaları. Kullanıldıkça zaten önbelleğe giriyorlar ama okunmamış
   bir kitabın fontu eksik kalabilir — toplu indirmeye dâhil edildiler.
   `encodeURI` ŞART: "KFGQPC Uthmanic.ttf" adında BOŞLUK var, kodlanmadan
   istenirse sunucu 404 döner. */
const FONTLAR = [
  "aria-script.ttf", "Bookerly.ttf", "digital-khatt-indopak.otf",
  "indopak-nastaleeq.ttf", "KFGQPC Uthmanic.ttf", "liva-nur.ttf",
  "Me_Quran.ttf", "PlayfairDisplay-Bold.ttf", "PlayfairDisplay-Regular.ttf",
  "ScheherazadeNew-Bold.ttf", "ScheherazadeNew-Regular.ttf",
  "souvenir-demi.ttf", "Souvenir.ttf", "surah-name-v1.ttf", "surah-name-v2.ttf",
  "Symbols1_Ver02.woff2", "uc_ondokuz.ttf", "uthmanic-bazzi-v20.ttf", "Vukuf.ttf",
  "Vukuf Ince', serif",
  "uthmanic-hafs-v22.ttf",
].map(a => encodeURI(`/fonts/${a}`))

/* Yazı tipleri de listede BİR SATIR. Eskiden sayaca giriyorlar ama listede hiç
   görünmüyorlardı: bir font eksik kaldığında "117/118" yazıyor, liste ise her
   şeyi hazır gösteriyordu — eksik olanı bulmanın yolu yoktu. KURAL: sayaca
   giren her dosya listede bir satıra ait olmalı. */
const FONT_GIRDISI = {
  id: "__fontlar",
  ad: "Yazı tipleri",
  yazar: `${FONTLAR.length} dosya · mushaf ve kitap fontları`,
  alim: "", kisim: "Uygulama",
  ozel: true,
  adresler: FONTLAR,
}

/* ── SUNUCUDA OLMAYAN DOSYALAR ──────────────────────────────────────────────
   İçindekiler dosyası her kitapta yok. Olmayan bir dosya hiçbir zaman
   önbelleğe giremeyeceği için sayaç asla tamamlanmıyordu (117/118 gibi).
   İndirme sırasında servis işçisi 404 alan adresleri bildiriyor; burada
   saklanıp sayaçtan düşülüyor. Her yeni indirmede hedef adresler listeden
   çıkarılıp YENİDEN sınanıyor — sunucuya sonradan eklenen dosya kaçmasın. */
const YOK_ANAHTAR = "vukuf-cevrimdisi-yok"
function yokOku() {
  try { return new Set(JSON.parse(localStorage.getItem(YOK_ANAHTAR) || "[]")) }
  catch { return new Set() }
}
function yokYaz(kume) {
  try { localStorage.setItem(YOK_ANAHTAR, JSON.stringify([...kume])) } catch { /* kota */ }
}

// Eksik dosyayı satırda adıyla göstermek için: "/bolumler/x-icindekiler.json" → "içindekiler"
function dosyaEtiketi(u) {
  const ad = decodeURI(String(u).split("/").pop() || "")
  if (/-icindekiler\.json$/.test(ad)) return "içindekiler"
  if (/-metin\.json$/.test(ad)) return "metin"
  return ad
}

/* GEÇİCİ — ses geçiş teşhisi görüntüleyici. Metin açılışta ve "Yenile"de
   okunuyor; kopyalama iOS'ta pano izni kullanıcı dokunuşuyla verildiği için
   düğmeden yapılıyor, olmazsa metin seçilebilir kutuda duruyor. */
function SesTeshisi({ theme, bilgiVer }) {
  const [metin, setMetin] = useState(() => sesTeshisMetni())
  const kutu = useRef(null)
  const dugme = {
    flex: 1, padding: "8px 10px", borderRadius: "9px", cursor: "pointer",
    border: `1px solid ${theme.border}`, background: "transparent", color: theme.text,
    fontSize: "12px", fontWeight: 600, fontFamily: "inherit",
  }
  async function kopyala() {
    try { await navigator.clipboard.writeText(metin); bilgiVer("iyi", "Teşhis metni kopyalandı.") }
    catch {
      // Yedek yol: metni seçip eski komutla kopyala. (textarea DEĞİL — 16px altı
      // yazı alanına dokunmak iOS'ta sayfayı yakınlaştırıyor.)
      try {
        const aralik = document.createRange(); aralik.selectNodeContents(kutu.current)
        const secim = window.getSelection(); secim.removeAllRanges(); secim.addRange(aralik)
        document.execCommand("copy"); bilgiVer("iyi", "Teşhis metni kopyalandı.")
      } catch { bilgiVer("kotu", "Kopyalanamadı — kutudaki metni elle seçip kopyalayın.") }
    }
  }
  return (
    <div style={{ marginTop: "4px" }}>
      <div style={{ fontSize: "12px", color: theme.textSecondary, lineHeight: 1.6, marginBottom: "8px" }}>
        Kur'ân'da bir sûreyi <b>ekran açıkken</b> 6-8 âyet çalın, sonra buraya
        gelip "Yenile" ve "Kopyala"ya basın. Her satır bir âyet geçişi:
        sessizliğin hangi adımda harcandığını gösterir.
      </div>
      <pre
        ref={kutu}
        style={{
          margin: 0, maxHeight: "min(240px, 34vh)", overflow: "auto", boxSizing: "border-box",
          padding: "8px", borderRadius: "9px", border: `1px solid ${theme.border}`,
          background: theme.background, color: theme.text, whiteSpace: "pre-wrap",
          wordBreak: "break-word", userSelect: "text", WebkitUserSelect: "text",
          fontFamily: "ui-monospace, Menlo, monospace", fontSize: "10.5px", lineHeight: 1.45,
        }}
      >{metin}</pre>
      <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
        <button style={dugme} onClick={() => setMetin(sesTeshisMetni())}>Yenile</button>
        <button style={{ ...dugme, borderColor: theme.accent, color: theme.accent }} onClick={kopyala}>Kopyala</button>
        <button style={dugme} onClick={() => { sesTeshisTemizle(); setMetin(sesTeshisMetni()) }}>Temizle</button>
      </div>
    </div>
  )
}

/* GEÇİCİ — DÖNME TEŞHİSİ. Ölçüm açılır, Kur'ân'da (ses ÇALMADAN) telefon
   birkaç kez çevrilir, burada okunup kopyalanır. Deneyler tek tek açılıp aynı
   ölçüm tekrarlanır → suçlu sayıyla çıkar. Ayarlar Kur'ân'a yeniden girince
   geçerli olur (uygulamayı kapatmak gerekmez). */
function DonmeTeshisi({ theme, bilgiVer }) {
  const [metin, setMetin] = useState(() => donmeTeshisMetni())
  const [acik, setAcik] = useState(() => teshisAcikMi())
  const [deney, setDeney] = useState(() => ({ ...DENEY }))
  const kutu = useRef(null)
  const dugme = {
    flex: 1, padding: "8px 10px", borderRadius: "9px", cursor: "pointer",
    border: `1px solid ${theme.border}`, background: "transparent", color: theme.text,
    fontSize: "12px", fontWeight: 600, fontFamily: "inherit",
  }
  const cip = (secili) => ({
    padding: "6px 10px", borderRadius: "999px", cursor: "pointer", fontFamily: "inherit",
    fontSize: "11.5px", fontWeight: 600,
    border: `1px solid ${secili ? theme.accent : theme.border}`,
    background: secili ? theme.accent : "transparent", color: secili ? "#fff" : theme.textSecondary,
  })
  const DENEYLER = [

  ]
  async function kopyala() {
    try { await navigator.clipboard.writeText(metin); bilgiVer("iyi", "Teşhis metni kopyalandı.") }
    catch {
      try {
        const aralik = document.createRange(); aralik.selectNodeContents(kutu.current)
        const secim = window.getSelection(); secim.removeAllRanges(); secim.addRange(aralik)
        document.execCommand("copy"); bilgiVer("iyi", "Teşhis metni kopyalandı.")
      } catch { bilgiVer("kotu", "Kopyalanamadı — kutudaki metni elle seçip kopyalayın.") }
    }
  }
  return (
    <div style={{ marginTop: "4px" }}>
      <div style={{ fontSize: "12px", color: theme.textSecondary, lineHeight: 1.6, marginBottom: "8px" }}>
        1) Ölçümü açın. 2) Kur'ân'a girin, <b>ses çalmadan</b> telefonu 3 kez
        yatay-dikey çevirin — her dönmeden ~2 sn sonra ekranın üstünde
        "Dönme ölçüldü" yazısı çıkar. 3) Buraya dönüp "Yenile" ve "Kopyala".
        Rapor, dönmede ekranın kaç kez ve ne kadar sürede çizildiğini ve bunu
        hangi durumların tetiklediğini de yazar.
      </div>
      <div style={{ display: "flex", gap: "6px", flexWrap: "wrap", marginBottom: "8px" }}>
        <button style={cip(acik)} onClick={() => { teshisAyarla(!acik); setAcik(!acik); setMetin(donmeTeshisMetni()) }}>
          Ölçüm {acik ? "açık" : "kapalı"}
        </button>
        {DENEYLER.map(([ad, etiket]) => (
          <button key={ad} style={cip(!!deney[ad])} onClick={() => {
            deneyAyarla(ad, !deney[ad]); setDeney({ ...DENEY }); setMetin(donmeTeshisMetni())
          }}>{etiket}</button>
        ))}
      </div>
      <pre
        ref={kutu}
        style={{
          margin: 0, maxHeight: "min(240px, 34vh)", overflow: "auto", boxSizing: "border-box",
          padding: "8px", borderRadius: "9px", border: `1px solid ${theme.border}`,
          background: theme.background, color: theme.text, whiteSpace: "pre-wrap",
          wordBreak: "break-word", userSelect: "text", WebkitUserSelect: "text",
          fontFamily: "ui-monospace, Menlo, monospace", fontSize: "10.5px", lineHeight: 1.45,
        }}
      >{metin}</pre>
      <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
        <button style={dugme} onClick={() => setMetin(donmeTeshisMetni())}>Yenile</button>
        <button style={{ ...dugme, borderColor: theme.accent, color: theme.accent }} onClick={kopyala}>Kopyala</button>
        <button style={dugme} onClick={() => { donmeTeshisTemizle(); setMetin(donmeTeshisMetni()) }}>Temizle</button>
      </div>
    </div>
  )
}

const ONAY_SURESI = 4000   // ms — bu süre dokunulmazsa onay hâli geri döner

/* Çift onaylı düğme. `onayMetni` ikinci dokunuşu bekleyen hâlin yazısı. */
function OnayliDugme({ theme, metin, onayMetni = "Emin misiniz? Tekrar dokunun", ikon: Ikon, kapali, tehlike, onOnay }) {
  const [onayda, setOnayda] = useState(false)
  const zaman = useRef(null)
  useEffect(() => () => { if (zaman.current) clearTimeout(zaman.current) }, [])

  function tikla() {
    if (kapali) return
    if (!onayda) {
      setOnayda(true)
      zaman.current = setTimeout(() => setOnayda(false), ONAY_SURESI)
      return
    }
    if (zaman.current) clearTimeout(zaman.current)
    setOnayda(false)
    onOnay()
  }

  const renk = onayda ? "#c0392b" : (tehlike ? "#c0392b" : theme.accent)
  return (
    <button
      onClick={tikla}
      disabled={kapali}
      style={{
        display: "flex", alignItems: "center", justifyContent: "center", gap: "7px",
        width: "100%", padding: "10px 12px", borderRadius: "10px",
        border: `1px solid ${kapali ? theme.border : renk}`,
        background: onayda ? `${renk}18` : "transparent",
        color: kapali ? theme.textSecondary : renk,
        fontSize: "13px", fontWeight: 600, fontFamily: "inherit",
        cursor: kapali ? "default" : "pointer",
        opacity: kapali ? 0.5 : 1,
        transition: "background 0.15s ease, color 0.15s ease, border-color 0.15s ease",
      }}
    >
      {onayda ? <AlertTriangle size={15} /> : (Ikon ? <Ikon size={15} /> : null)}
      {onayda ? onayMetni : metin}
    </button>
  )
}

function Ayrac({ theme }) {
  return <div style={{ height: "1px", background: theme.border, opacity: 0.6, margin: "12px 0" }} />
}

export default function VeriAyarlari({ theme }) {
  // Envanter her açılışta bir kez okunur; silme/yükleme sonrası `tazele` ile yenilenir.
  // ── AKORDİYON ────────────────────────────────────────────────────────────
  // Aynı anda TEK bölüm açık. Panel kısa kalsın diye; önemli sayılar zaten
  // başlık satırındaki özette görünüyor, bölüm açmaya gerek kalmıyor.
  const [acikBolum, setAcikBolum] = useState(null)
  const kapak = (id) => ({
    acik: acikBolum === id,
    onAc: () => setAcikBolum(x => (x === id ? null : id)),
  })

  const [tazele, setTazele] = useState(0)
  const kutular = useMemo(() => envanter(), [tazele])
  const toplam = useMemo(() => toplamBoyut(), [tazele])

  const [kopyalandi, setKopyalandi] = useState(false)
  const [indirmeHatasi, setIndirmeHatasi] = useState(false)
  const [yapistirAcik, setYapistirAcik] = useState(false)
  const [yapistirMetni, setYapistirMetni] = useState("")
  const [aday, setAday] = useState(null)      // çözümlenmiş yedek, onay bekliyor
  const [mesaj, setMesaj] = useState(null)    // { tip: "iyi"|"kotu", metin }
  const dosyaRef = useRef(null)

  // ── DEPOLAMA ÖLÇÜMÜ ──────────────────────────────────────────────────────
  // `navigator.storage.estimate()` tarayıcının bu kaynağa ayırdığı yeri ve
  // kullanılanı veriyor. Çevrimdışı indirme geldiğinde sürekli lazım olacak.
  const [depolama, setDepolama] = useState(null)
  const [kalici, setKalici] = useState(null)
  useEffect(() => {
    let iptal = false
    ;(async () => {
      // NİÇİN AYRI TEŞHİS: `navigator.storage` yalnız GÜVENLİ BAĞLAMDA (HTTPS ya da
      // localhost) tanımlıdır. Geliştirme sunucusuna telefondan http://192.168.x.x
      // ile bağlanınca API hiç yoktur; eski hâl buna "bu tarayıcı desteklemiyor"
      // diyordu ve yanlış yöne baktırıyordu. Aynı kısıt SERVİS İŞÇİSİ için de
      // geçerli — çevrimdışı özelliği de o adreste hiç çalışmaz.
      try {
        if (!window.isSecureContext) {
          if (!iptal) setDepolama({ hata: "guvensiz" })
        } else if (!navigator.storage || !navigator.storage.estimate) {
          if (!iptal) setDepolama({ hata: "yok" })
        } else {
          const e = await navigator.storage.estimate()
          if (!iptal) setDepolama({ kullanilan: e.usage || 0, kota: e.quota || 0 })
        }
      } catch { if (!iptal) setDepolama({ hata: "yok" }) }
      try {
        const k = await navigator.storage.persisted()
        if (!iptal) setKalici(k)
      } catch { /* destek yok */ }
    })()
    return () => { iptal = true }
  }, [tazele])

  async function kaliciYap() {
    try {
      const oldu = await navigator.storage.persist()
      setKalici(oldu)
      bilgiVer(oldu ? "iyi" : "kotu", oldu
        ? "Depolama kalıcı işaretlendi — tarayıcı yer açmak için silmeyecek."
        : "Tarayıcı kalıcı depolama vermedi. Veriler yine durur ama yer darlığında silinebilir.")
    } catch {
      bilgiVer("kotu", "Bu tarayıcı kalıcı depolamayı desteklemiyor.")
    }
  }

  // ── ÇEVRİMDIŞI DURUMU ────────────────────────────────────────────────────
  const [cevrimdisi, setCevrimdisi] = useState(null)
  useEffect(() => {
    let iptal = false
    ;(async () => {
      if (!destekVar()) { if (!iptal) setCevrimdisi({ destek: false }); return }
      const [surum, dokum, kabuk] = await Promise.all([swSurum(), onbellekDokumu(), kabukDurumu()])
      let kayitli = false
      try {
        const k = await navigator.serviceWorker.getRegistrations()
        kayitli = k.length > 0
      } catch { /* yoksay */ }
      if (!iptal) setCevrimdisi({ destek: true, surum, dokum, kayitli, kabuk })
    })()
    return () => { iptal = true }
  }, [tazele])

  // ── KİTAP İNDİRME ────────────────────────────────────────────────────────
  const kitaplar = useMemo(() => [KURAN_GIRDISI, FONT_GIRDISI, ...kitapListesi()], [])
  const kitapSayisi = kitaplar.filter(k => !k.ozel).length
  // Fontlar ve Kur'ân dosyaları artık kendi satırlarından geliyor; tek kaynak.
  const adresler = useMemo(
    () => [...new Set(kitaplar.flatMap(k => k.adresler))],
    [kitaplar]
  )
  const [yok, setYok] = useState(yokOku)        // sunucuda olmadığı öğrenilen adresler
  // Sayacın paydası: sunucuda olmadığı BİLİNEN dosyalar düşülüyor.
  const sayilan = useMemo(() => adresler.filter(u => !yok.has(u)), [adresler, yok])
  const [durum, setDurum] = useState(null)      // { hazir, bayt, kitapDurum: Map }
  const [indirme, setIndirme] = useState(null)  // { tamam, hata, toplam }
  const [listeAcik, setListeAcik] = useState(false)
  const [arama, setArama] = useState("")

  /* Süzme: kitap adı, yazar, ÂLİM ve KISIM adında birden arıyor. Böylece
     "Bediüzzaman" yazmak o âlimin bütün eserlerini, raf adı yazmak o rafın
     tamamını getiriyor — ayrı bir raf/âlim seçici kutusuna gerek kalmıyor.
     `normHarf` uygulamanın kendi normalizasyonu (İ/ı, şapka) — arama kutusuyla
     aynı davranış olsun diye yeniden yazılmadı. */
  const gorunen = useMemo(() => {
    const q = normHarf(arama.trim())
    const suzulmus = q
      ? kitaplar.filter(k => normHarf(`${k.ad} ${k.yazar} ${k.alim} ${k.kisim}`).includes(q))
      : kitaplar
    /* İNDİRİLMEMİŞLER ÜSTTE: liste 60+ satır ve kullanıcının burada aradığı şey
       "ne eksik" — hazır olanları üstte görmek işe yaramıyor. Sıra: hiç
       inmemiş → kısmen inmiş → hazır. Kendi içlerinde katalog sırası korunuyor
       (sort kararlı). */
    const derece = (k) => {
      const d = durum?.kitapDurum?.get(k.id)
      return !d ? 0 : d.hazir ? 2 : d.kismen ? 1 : 0
    }
    return [...suzulmus].sort((a, b) => derece(a) - derece(b))
  }, [kitaplar, arama, durum])

  /* BOYUT NASIL ÖLÇÜLÜYOR — ve sınırı ne:
     Önbellekteki yanıtların GÖVDESİ okunmuyor (40 MB'ı diskten okumak gerekirdi);
     yalnız `content-length` başlığı toplanıyor. Bu, İNDİRİLEN (aktarım) boyutu
     demek. Sunucu gzip uyguluyorsa diskte kapladığı yer bundan büyük olabilir;
     gerçek disk kullanımı Depolama bölümündeki rakamdır. Bu yüzden "≈" ile
     gösteriliyor. */
  useEffect(() => {
    let iptal = false
    ;(async () => {
      try {
        const k = await caches.open("vukuf-veri")
        const olc = async (u) => {
          const y = await k.match(u, { ignoreVary: true })
          if (!y) return null
          // Veri adresine saklanmış HTML = SPA yönlendirmesinin index.html'i;
          // dosya aslında YOK. Hazır sayılmıyor (işçi indirmede bunu siliyor).
          if ((y.headers.get("content-type") || "").toLowerCase().includes("text/html")) return null
          return Number(y.headers.get("content-length") || 0)
        }
        /* ⚠ ESKİ HATA — SAYAÇ İLE LİSTE FARKLI ŞEYLER SAYIYORDU.
           Sayaç DOSYA sayıyordu (fontlar + Kur'ân'ın üç dosyası + her kitabın
           metni VE içindekileri), liste ise bir kitabı yalnız METNİNE bakarak
           "hazır" diyordu; fontlar listede hiç yoktu. Eksik dosya bir font,
           kuran.json/sayfa-harita.json ya da bir içindekiler olunca sayaç
           117/118'de takılıyor, liste ise her satırı hazır gösteriyordu.
           ŞİMDİ: her dosya bir kez ölçülüyor; sayaç da satırlar da BU TEK
           ölçümden türüyor, yani biri eksik derken öbürü hazır diyemez. */
        const dosya = new Map()                 // adres → bayt | null (yok)
        for (const u of adresler) dosya.set(u, await olc(u))
        let hazir = 0, bayt = 0
        for (const u of sayilan) {
          const b = dosya.get(u)
          if (b !== null && b !== undefined) { hazir++; bayt += b }
        }
        const kitapDurum = new Map()
        for (const kt of kitaplar) {
          let kb = 0
          const eksik = []
          for (const u of kt.adresler) {
            const b = dosya.get(u)
            if (b !== null && b !== undefined) kb += b
            else if (!yok.has(u)) eksik.push(u)   // sunucuda olmayan eksik sayılmaz
          }
          // Asıl dosya (ilk adres: metin / mushaf / ilk font) varsa satır en az
          // "kısmen" hazır; yalnız yan dosyalar eksikse "tamamla" düğmesi çıkıyor.
          const asil = dosya.get(kt.adresler[0])
          kitapDurum.set(kt.id, {
            hazir: eksik.length === 0,
            kismen: eksik.length > 0 && asil !== null && asil !== undefined,
            eksik,
            bayt: kb,
          })
        }
        if (!iptal) setDurum({ hazir, bayt, kitapDurum })
      } catch { if (!iptal) setDurum(null) }
    })()
    return () => { iptal = true }
  }, [kitaplar, adresler, sayilan, yok, tazele, indirme])

  function indirBasla(hedefler, ad) {
    if (!destekVar() || !navigator.serviceWorker.controller) {
      bilgiVer("kotu", "Çevrimdışı etkin değil; indirme yapılamıyor.")
      return
    }
    // Hedefler YENİDEN sınanıyor: daha önce "sunucuda yok" diye işaretlenmiş
    // bir dosya sonradan eklenmişse bu indirmede yakalanır.
    const sinanacak = new Set(yokOku())
    for (const u of hedefler) sinanacak.delete(u)
    yokYaz(sinanacak)
    setYok(new Set(sinanacak))
    setIndirme({ tamam: 0, hata: 0, toplam: hedefler.length, ad })
    // İndirme SERVİS İŞÇİSİNDE yürüyor: panel kapansa bile sürüyor.
    const birak = onYukle(hedefler, (d) => {
      setIndirme({ ...d, ad })
      if (d.tamam + d.hata >= d.toplam) {
        birak()
        // İşçi 404 alan adresleri `yok` dizisinde bildiriyor (eski sürüm
        // işçide alan yoksa boş dizi — davranış eskisi gibi kalır).
        const yeniYok = new Set(sinanacak)
        for (const u of (Array.isArray(d.yok) ? d.yok : [])) yeniYok.add(u)
        yokYaz(yeniYok)
        setYok(yeniYok)
        const yokSayisi = Array.isArray(d.yok) ? d.yok.length : 0
        const baskaHata = d.hata - yokSayisi
        setTimeout(() => { setIndirme(null); setTazele(x => x + 1) }, 1000)
        bilgiVer(baskaHata > 0 ? "kotu" : "iyi",
          `${ad}: ${d.tamam} dosya indirildi` +
          (yokSayisi ? `, ${yokSayisi} dosya sunucuda yok (sayaçtan düşüldü)` : "") +
          (baskaHata > 0 ? `, ${baskaHata} dosya alınamadı — bağlantıyı kontrol edip tekrar deneyin` : "") +
          ".")
      }
    })
  }

  // ── SESLER ───────────────────────────────────────────────────────────────
  const [kari, setKari] = useState(() => {
    try { return localStorage.getItem("vukuf-kari") || KARILAR[0].id } catch { return KARILAR[0].id }
  })
  const [mushaf, setMushaf] = useState(null)
  const [sesSekme, setSesSekme] = useState("cuz")
  const [sesArama, setSesArama] = useState("")
  const [olcum, setOlcum] = useState(null)      // { baytKelime, orneklem, … }
  const [olcuyor, setOlcuyor] = useState(false)
  const [sesVarlar, setSesVarlar] = useState(null)  // önbellekteki adres kümesi

  // Mushaf 5 MB — YALNIZ bölüm açıldığında çekiliyor.
  useEffect(() => {
    if (acikBolum !== "sesler" || mushaf) return
    let iptal = false
    mushafYukle().then(d => { if (!iptal) setMushaf(d) }).catch(() => {})
    return () => { iptal = true }
  }, [acikBolum, mushaf])

  useEffect(() => {
    if (acikBolum !== "sesler") return
    let iptal = false
    sesAnahtarlari().then(x => { if (!iptal) setSesVarlar(x) })
    return () => { iptal = true }
  }, [acikBolum, tazele, indirme])

  const sureler = useMemo(() => (mushaf ? sureListesi(mushaf) : []), [mushaf])
  const cuzler = useMemo(() => (mushaf ? cuzListesi(mushaf) : []), [mushaf])

  // Kâri değişince ölçüm geçersiz: bitrate kâriden kâriye değişiyor.
  useEffect(() => { setOlcum(null) }, [kari])

  async function boyutOlc() {
    if (!mushaf) return
    setOlcuyor(true)
    const o = await boyutOrnekle(kari, mushaf, 20)
    setOlcum(o)
    setOlcuyor(false)
    if (o.hata) bilgiVer("kotu", o.hata)
  }

  const sesSatirlari = useMemo(() => {
    const yap = (ad, alt, ayetler, kelime) => {
      const adresler = sesAdresleri(kari, ayetler)
      const hazir = sesVarlar ? adresler.filter(u => sesVarlar.has(u)).length : 0
      return { ad, alt, adresler, kelime, hazir, toplam: adresler.length }
    }
    if (sesSekme === "cuz") {
      return cuzler.map(c => yap(`${c.no}. Cüz`, c.sureler.slice(0, 3).join(", "), c.ayetler, c.kelime))
    }
    const q = normHarf(sesArama.trim())
    return sureler
      .filter(s => !q || normHarf(`${s.no} ${s.ad}`).includes(q))
      .map(s => yap(`${s.no}. ${s.ad}`, `${s.ayetSayisi} âyet`, s.ayetler, s.kelime))
  }, [sesSekme, sesArama, cuzler, sureler, kari, sesVarlar])

  async function sesleriSil() {
    await sesOnbellegiSil()
    setSesVarlar(new Set())
    setTazele(x => x + 1)
    bilgiVer("iyi", "İndirilen sesler silindi.")
  }

  async function onbellekTemizleTikla() {
    const n = await onbellegiTemizle()
    bilgiVer("iyi", `${n} önbellek silindi, sayfa yenileniyor…`)
    setTimeout(() => window.location.reload(), 600)
  }

  const doluKutular = kutular.filter(k => k.adet > 0)

  function bilgiVer(tip, metin) {
    setMesaj({ tip, metin })
    setTimeout(() => setMesaj(null), 5000)
  }

  function indir() {
    const oldu = yedekIndir()
    setIndirmeHatasi(!oldu)
    if (oldu) bilgiVer("iyi", `${yedekDosyaAdi()} indirildi.`)
  }

  async function panoyaKopyala() {
    try {
      await navigator.clipboard.writeText(yedekMetni())
      sonYedekYaz()            // Hıfz ekranının "yedek alınmadı" hatırlatması için
      setKopyalandi(true)
      setTimeout(() => setKopyalandi(false), 2500)
    } catch {
      bilgiVer("kotu", "Panoya kopyalanamadı. Yedeği dosya olarak indirmeyi deneyin.")
    }
  }

  async function dosyaSecildi(e) {
    const d = e.target.files && e.target.files[0]
    // Aynı dosya art arda seçilebilsin diye input sıfırlanır.
    e.target.value = ""
    if (!d) return
    const c = await dosyadanOku(d)
    if (c.hata) { bilgiVer("kotu", c.hata); return }
    setAday(c)
    setAcikBolum("geri")
  }

  function yapistirilaniAl() {
    const c = yedekCozumle(yapistirMetni)
    if (c.hata) { bilgiVer("kotu", c.hata); return }
    setYapistirAcik(false)
    setYapistirMetni("")
    setAday(c)
    setAcikBolum("geri")
  }

  function geriYukle(kip) {
    const s = yedekYaz(aday, kip)
    if (s.hata) { bilgiVer("kotu", s.hata); return }
    setAday(null)
    // Yenileme şart: değerlerin çoğu açılışta okunuyor.
    setTimeout(() => window.location.reload(), 350)
    bilgiVer("iyi", `${s.yazilan} kayıt geri yüklendi, sayfa yenileniyor…`)
  }

  function kategoriSifirla(id, ad) {
    const silinen = sifirla(id)
    // Hıfz modülü kaydı bellekte de tutuyor; tazelenmezse bir sonraki yazış
    // silinen veriyi geri yazardı (3 Ekim 2026).
    if (id === "hifz") hifzTazele()
    setTazele(x => x + 1)
    bilgiVer("iyi", `${ad}: ${silinen.length} kayıt silindi.`)
    if (id === "hepsi" || id === "tema") setTimeout(() => window.location.reload(), 600)
  }

  const tarihMetni = aday?.tarih
    ? new Date(aday.tarih).toLocaleString("tr-TR", { dateStyle: "medium", timeStyle: "short" })
    : "bilinmiyor"

  return (
    <div>
      <Katlanir
        theme={theme} ikon={HardDrive} baslik="Depolama"
        ozet={depolama && !depolama.hata && depolama.kota > 0 ? `${boyutYaz(depolama.kullanilan)} / ${boyutYaz(depolama.kota)}` : null}
        {...kapak("depolama")}
      >
        {/* 11 Ekim 2026: bölüm bölüm kullanım + toplam/ayrılan/boş (DepolamaGorunumu) */}
        {depolama?.hata === "guvensiz" && (
          <div style={{
            padding: "10px 12px", borderRadius: "10px", marginBottom: "8px",
            border: `1px solid ${theme.border}`, background: theme.background,
            fontSize: "12px", color: theme.textSecondary, lineHeight: 1.6,
          }}>
            <b style={{ color: "#c0392b" }}>Güvenli bağlam değil.</b> Bu sayfa{" "}
            <code style={{ fontSize: "11px" }}>{location.protocol}//{location.host}</code>{" "}
            adresinden açıldı; tarayıcı depolama bilgisini yalnız HTTPS ya da
            localhost üzerinde veriyor. <b>Çevrimdışı özelliği de</b> aynı sebeple
            burada çalışmaz — kurulu uygulama (HTTPS) üzerinden bakın.
          </div>
        )}
        <DepolamaGorunumu theme={theme} tazele={tazele} kalici={kalici} onKaliciYap={kaliciYap} />

      </Katlanir>

      <Katlanir
        theme={theme} ikon={Download} baslik="Yedek al"
        ozet={`${doluKutular.reduce((t, k) => t + k.adet, 0)} kayıt`}
        {...kapak("yedek")}
      >
      <div style={{ display: "flex", gap: "8px" }}>
        <button onClick={indir} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: "7px",
          padding: "11px 12px", borderRadius: "10px",
          background: theme.accent, color: "#fff", border: "none",
          fontSize: "13px", fontWeight: 600, fontFamily: "inherit", cursor: "pointer",
        }}>
          <Download size={15} /> Dosya indir
        </button>
        <button onClick={panoyaKopyala} title="Yedeği panoya kopyala" style={{
          display: "flex", alignItems: "center", justifyContent: "center", gap: "6px",
          padding: "11px 14px", borderRadius: "10px",
          background: "transparent", border: `1px solid ${theme.border}`,
          color: kopyalandi ? theme.accent : theme.textSecondary,
          fontSize: "13px", fontFamily: "inherit", cursor: "pointer",
        }}>
          {kopyalandi ? <Check size={15} /> : <Copy size={15} />}
          {kopyalandi ? "Kopyalandı" : "Kopyala"}
        </button>
      </div>
      {indirmeHatasi && (
        <div style={{ fontSize: "11px", color: theme.textSecondary, marginTop: "6px", lineHeight: 1.5 }}>
          İndirme başlatılamadı — ana ekrana eklenmiş uygulamalarda bu olabiliyor.
          "Kopyala" ile yedeği panoya alıp bir not uygulamasına yapıştırabilirsiniz.
        </div>
      )}

      </Katlanir>

      <Katlanir
        theme={theme} ikon={Upload} baslik="Geri yükle"
        ozet={aday ? `${aday.adet} kayıt okundu` : null}
        {...kapak("geri")}
      >
      {!aday && (
        <>
          <div style={{ display: "flex", gap: "8px" }}>
            <button onClick={() => dosyaRef.current?.click()} style={{
              flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: "7px",
              padding: "11px 12px", borderRadius: "10px",
              background: "transparent", border: `1px solid ${theme.accent}`,
              color: theme.accent, fontSize: "13px", fontWeight: 600,
              fontFamily: "inherit", cursor: "pointer",
            }}>
              <Upload size={15} /> Dosya seç
            </button>
            <button onClick={() => setYapistirAcik(v => !v)} style={{
              display: "flex", alignItems: "center", justifyContent: "center", gap: "6px",
              padding: "11px 14px", borderRadius: "10px",
              background: "transparent", border: `1px solid ${theme.border}`,
              color: theme.textSecondary, fontSize: "13px", fontFamily: "inherit", cursor: "pointer",
            }}>
              <FileText size={15} /> Yapıştır
            </button>
          </div>
          <input ref={dosyaRef} type="file" accept=".json,application/json"
            onChange={dosyaSecildi} style={{ display: "none" }} />
          {yapistirAcik && (
            <div style={{ marginTop: "8px" }}>
              <textarea
                value={yapistirMetni}
                onChange={e => setYapistirMetni(e.target.value)}
                placeholder="Yedek metnini buraya yapıştırın…"
                rows={4}
                style={{
                  width: "100%", boxSizing: "border-box", padding: "10px",
                  borderRadius: "10px", border: `1px solid ${theme.border}`,
                  background: theme.background, color: theme.text,
                  fontSize: "12px", fontFamily: "ui-monospace, monospace", resize: "vertical",
                }}
              />
              <button onClick={yapistirilaniAl} disabled={!yapistirMetni.trim()} style={{
                width: "100%", marginTop: "6px", padding: "9px", borderRadius: "10px",
                background: "transparent", border: `1px solid ${theme.accent}`,
                color: theme.accent, fontSize: "13px", fontWeight: 600,
                fontFamily: "inherit", cursor: yapistirMetni.trim() ? "pointer" : "default",
                opacity: yapistirMetni.trim() ? 1 : 0.5,
              }}>Yedeği oku</button>
            </div>
          )}
        </>
      )}

      {/* Aday yedek — ne olduğu gösterilip iki kipten biri seçiliyor */}
      {aday && (
        <div style={{
          padding: "12px", borderRadius: "10px",
          border: `1px solid ${theme.accent}`, background: `${theme.accent}0d`,
        }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: "8px", marginBottom: "10px" }}>
            <div style={{ flex: 1, fontSize: "12px", color: theme.text, lineHeight: 1.6 }}>
              <b>{aday.adet}</b> kayıt içeren yedek okundu.<br />
              <span style={{ color: theme.textSecondary }}>Tarih: {tarihMetni}</span>
            </div>
            <button onClick={() => setAday(null)} aria-label="Vazgeç"
              style={{ background: "none", border: "none", color: theme.textSecondary, cursor: "pointer", display: "flex", padding: "2px" }}>
              <X size={16} />
            </button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "7px" }}>
            <OnayliDugme theme={theme} metin="Birleştir (yalnız yedektekileri yaz)"
              onayMetni="Birleştirilsin mi? Tekrar dokunun"
              onOnay={() => geriYukle("birlestir")} />
            <OnayliDugme theme={theme} tehlike metin="Tamamen değiştir (öncekileri sil)"
              onayMetni="Mevcut veriler silinecek! Tekrar dokunun"
              onOnay={() => geriYukle("degistir")} />
          </div>
          <div style={{ fontSize: "11px", color: theme.textSecondary, marginTop: "8px", lineHeight: 1.5 }}>
            Geri yüklendikten sonra sayfa kendiliğinden yenilenir.
          </div>
        </div>
      )}

      </Katlanir>

      <Katlanir
        theme={theme} ikon={Trash2} baslik="Sıfırla"
        ozet={`${doluKutular.length} bölüm`}
        {...kapak("sifirla")}
      >
      <div style={{ fontSize: "11px", color: theme.textSecondary, marginBottom: "10px", lineHeight: 1.5 }}>
        Silinen geri getirilemez. Sıfırlamadan önce yukarıdan bir yedek almanız iyi olur.
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
        {kutular.map(k => (
          <div key={k.id} style={{
            padding: "10px 12px", borderRadius: "10px",
            border: `1px solid ${theme.border}`, background: theme.background,
            opacity: k.adet ? 1 : 0.55,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: k.adet ? "8px" : 0 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: "13px", color: theme.text, fontWeight: 600 }}>
                  {k.ad}
                  {k.korumali && k.adet > 0 && (
                    <span style={{ fontSize: "10px", color: "#c0392b", marginLeft: "6px" }}>• kişisel</span>
                  )}
                </div>
                <div style={{ fontSize: "11px", color: theme.textSecondary, marginTop: "2px", lineHeight: 1.4 }}>
                  {k.aciklama}
                </div>
              </div>
              <span style={{
                flexShrink: 0, fontSize: "11px", fontWeight: 600,
                color: k.adet ? theme.accent : theme.textSecondary,
                background: k.adet ? `${theme.accent}18` : "transparent",
                borderRadius: "999px", padding: "3px 9px",
              }}>{k.adet}{k.adet ? ` · ${boyutMetni(k.boyut)}` : ""}</span>
            </div>
            {k.adet > 0 && (
              <OnayliDugme theme={theme} tehlike={k.korumali} ikon={Trash2}
                metin="Sıfırla"
                onayMetni={k.korumali ? `${k.adet} kişisel kayıt silinecek! Tekrar dokunun` : "Emin misiniz? Tekrar dokunun"}
                onOnay={() => kategoriSifirla(k.id, k.ad)} />
            )}
          </div>
        ))}
      </div>

      <Ayrac theme={theme} />
      <OnayliDugme theme={theme} tehlike ikon={Trash2}
        metin="Her şeyi sıfırla"
        onayMetni="TÜM veriler silinecek! Tekrar dokunun"
        kapali={!doluKutular.length}
        onOnay={() => kategoriSifirla("hepsi", "Tümü")} />

      </Katlanir>

      {/* ── ÇEVRİMDIŞI ────────────────────────────────────────────────────
          Servis işçisinin bilinen bedeli BAYAT KOD: yeni sürüm yayınlanır,
          cihaz eskisini çalıştırır, olmayan hata aranır. Bu bölüm o şüpheyi
          tahminle değil BAKARAK çözmek için var — sürüm damgası görünür,
          önbellekte kaç dosya olduğu görünür, ve tek dokunuşla temizlenir. */}
      <Katlanir
        theme={theme} ikon={CloudOff} baslik="Çevrimdışı"
        ozet={cevrimdisi
          ? (cevrimdisi.destek === false ? "kapalı" : cevrimdisi.kayitli ? (cevrimdisi.surum || "etkin") : "kurulmadı")
          : null}
        {...kapak("cevrimdisi")}
      >
        <div style={{
          padding: "10px 12px", borderRadius: "10px",
          border: `1px solid ${theme.border}`, background: theme.background,
          fontSize: "12px", color: theme.textSecondary, lineHeight: 1.6,
        }}>
          {!cevrimdisi && "Bakılıyor…"}
          {cevrimdisi?.destek === false && (
            <>
              <b style={{ color: "#c0392b" }}>Çevrimdışı kapalı.</b> Servis işçisi
              yalnız güvenli bağlamda (HTTPS ya da localhost) çalışır. Geliştirme
              sunucusuna ağ adresiyle bağlanıldığında tarayıcı bu özelliği hiç
              açmaz — kurulu uygulamadan bakın.
            </>
          )}
          {cevrimdisi?.destek && (
            <>
              <div>
                Durum: <b style={{ color: theme.text }}>{cevrimdisi.kayitli ? "etkin" : "henüz kurulmadı"}</b>
                {cevrimdisi.surum && <> · Sürüm: <b style={{ color: theme.text }}>{cevrimdisi.surum}</b></>}
              </div>
              {/* SOĞUK AÇILIŞ TEŞHİSİ: veri önbelleği doluyken bile kabuk boşsa
                  uygulama çevrimdışı AÇILMAZ, ama açıkken her şey çalışır. */}
              <div style={{ marginTop: "4px" }}>
                Uygulama kabuğu:{" "}
                {cevrimdisi.kabuk === null ? <b style={{ color: theme.text }}>bilinmiyor</b>
                  : cevrimdisi.kabuk
                    ? <b style={{ color: theme.accent }}>saklandı</b>
                    : <b style={{ color: "#c0392b" }}>SAKLANMADI — çevrimdışı açılmaz</b>}
              </div>
              {cevrimdisi.dokum?.length > 0 ? (
                <div style={{ marginTop: "6px" }}>
                  {cevrimdisi.dokum.map(d => (
                    <div key={d.ad} style={{ fontFamily: "ui-monospace, monospace", fontSize: "11px" }}>
                      {d.ad}: {d.adet} dosya
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ marginTop: "6px" }}>Önbellekte henüz dosya yok.</div>
              )}
              <div style={{ marginTop: "8px", lineHeight: 1.5 }}>
                Açtığınız sayfalar ve kitaplar kendiliğinden saklanıyor; bir kez
                çevrimiçi açtığınız şey sonra çevrimdışı da açılır.
              </div>
            </>
          )}
        </div>

        {cevrimdisi?.destek && (
          <div style={{ marginTop: "8px" }}>
            <OnayliDugme
              theme={theme} ikon={Trash2}
              metin="Önbelleği temizle ve yenile"
              onayMetni="Önbellek silinecek, sayfa yenilenecek. Tekrar dokunun"
              onOnay={onbellekTemizleTikla}
            />
            <div style={{ fontSize: "11px", color: theme.textSecondary, marginTop: "6px", lineHeight: 1.5 }}>
              Yalnız indirilmiş dosyaları siler — işaretleriniz, notlarınız ve
              ayarlarınız etkilenmez. "Yeni sürümü almıyor" şüphesinde ilk
              başvurulacak yer burası.
            </div>
          </div>
        )}
      </Katlanir>

      {/* ── KİTAPLARI İNDİR ───────────────────────────────────────────────
          "Kullanıldıkça sakla" günlük kullanımda yeterli ama yolculuk/cami gibi
          önceden hazırlık gereken durumlarda yetmiyor.
          Kitap listesi KATALOGDAN (kitaplar.js) türetiliyor — yeni eser
          eklendiğinde burada hiçbir şey değişmiyor. */}
      <Katlanir
        theme={theme} ikon={BookOpen} baslik="Kitapları indir"
        ozet={durum ? `${durum.hazir}/${sayilan.length} · ≈${boyutMetni(durum.bayt)}` : null}
        {...kapak("indir")}
      >
        <div style={{
          padding: "10px 12px", borderRadius: "10px",
          border: `1px solid ${theme.border}`, background: theme.background,
          fontSize: "12px", color: theme.textSecondary, lineHeight: 1.6,
        }}>
          İndirilenler internetsiz açılır. Boyutlar aktarım boyutudur (≈);
          cihazda kapladığı gerçek yer Depolama bölümünde.
          {durum && (
            <div style={{ marginTop: "6px", color: theme.text }}>
              <b>{durum.hazir}</b> / {sayilan.length} dosya hazır ·{" "}
              <b>≈{boyutMetni(durum.bayt)}</b>
            </div>
          )}
        </div>

        {indirme ? (
          <div style={{ marginTop: "10px" }}>
            <div style={{ height: "8px", borderRadius: "4px", overflow: "hidden", background: `${theme.accent}20` }}>
              <div style={{
                height: "100%", background: theme.accent, borderRadius: "4px",
                width: `${Math.round(((indirme.tamam + indirme.hata) / Math.max(1, indirme.toplam)) * 100)}%`,
                transition: "width 0.2s ease",
              }} />
            </div>
            <div style={{ fontSize: "12px", color: theme.textSecondary, marginTop: "6px" }}>
              {indirme.ad} · {indirme.tamam + indirme.hata} / {indirme.toplam}
              {indirme.hata > 0 && ` (${indirme.hata} bulunamadı)`}
            </div>
            <div style={{ fontSize: "11px", color: theme.textSecondary, marginTop: "4px", lineHeight: 1.5 }}>
              İndirme arka planda sürüyor; bu paneli kapatabilirsiniz.
            </div>
          </div>
        ) : (
          <>
            <button
              onClick={() => indirBasla(adresler, "Tümü")}
              disabled={!cevrimdisi?.destek}
              style={{
                width: "100%", marginTop: "10px",
                display: "flex", alignItems: "center", justifyContent: "center", gap: "7px",
                padding: "11px 12px", borderRadius: "10px", border: "none",
                background: cevrimdisi?.destek ? theme.accent : theme.border,
                color: cevrimdisi?.destek ? "#fff" : theme.textSecondary,
                fontSize: "13px", fontWeight: 600, fontFamily: "inherit",
                cursor: cevrimdisi?.destek ? "pointer" : "default",
              }}
            >
              <Download size={15} />
              {durum && durum.hazir >= sayilan.length ? "Yeniden indir" : "Hepsini indir"}
            </button>

            {/* ── KİTAP SEÇ ───────────────────────────────────────────────
                Varsayılan KAPALI: 60'tan fazla satır paneli boğuyordu.
                Ayrı bir "raf/âlim seçici" kutusu YAPILMADI — arama zaten kitap
                adı, yazar, âlim ve kısım adında birden eşleşiyor, yani
                "Bediüzzaman" yazmak o âlimin eserlerini süzüyor. Tek kutu,
                iki işi birden görüyor ve panel sade kalıyor. */}
            <button
              onClick={() => setListeAcik(v => !v)}
              style={{
                width: "100%", marginTop: "8px", padding: "9px 12px",
                display: "flex", alignItems: "center", justifyContent: "center", gap: "6px",
                borderRadius: "10px", background: "transparent",
                border: `1px solid ${theme.border}`, color: theme.textSecondary,
                fontSize: "12px", fontFamily: "inherit", cursor: "pointer",
              }}
            >
              {listeAcik ? "Listeyi kapat" : `Kitap seç (${kitapSayisi})`}
            </button>

            {listeAcik && (
              <>
                <div style={{
                  display: "flex", alignItems: "center", gap: "8px",
                  marginTop: "8px", padding: "8px 11px", borderRadius: "10px",
                  border: `1px solid ${theme.border}`, background: theme.background,
                }}>
                  <Search size={14} color={theme.accent} style={{ flexShrink: 0 }} />
                  <input
                    value={arama}
                    onChange={e => setArama(e.target.value)}
                    placeholder="Kitap, yazar, âlim ya da raf…"
                    style={{
                      flex: 1, minWidth: 0, border: "none", outline: "none",
                      background: "transparent", color: theme.text,
                      fontSize: "13px", fontFamily: "inherit",
                    }}
                  />
                  {arama && (
                    <button onClick={() => setArama("")} aria-label="Temizle"
                      style={{ background: "none", border: "none", color: theme.textSecondary, cursor: "pointer", display: "flex", padding: "2px" }}>
                      <X size={14} />
                    </button>
                  )}
                </div>

                {/* Süzülmüş kümeyi topluca indirme — asıl kolaylık burada:
                    "Bediüzzaman" yaz, tek dokunuşla o külliyatı indir. */}
                {(() => {
                  const eksik = gorunen.filter(k => !(durum?.kitapDurum?.get(k.id)?.hazir))
                  if (!arama.trim() || eksik.length === 0) return null
                  // Yalnız EKSİK dosyalar isteniyor; kısmen inmiş kitabın metni yeniden çekilmesin.
                  const hedef = eksik.flatMap(k => durum?.kitapDurum?.get(k.id)?.eksik || k.adresler)
                  return (
                    <button
                      onClick={() => indirBasla(hedef, `${eksik.length} eser`)}
                      disabled={!cevrimdisi?.destek}
                      style={{
                        width: "100%", marginTop: "8px", padding: "10px 12px",
                        display: "flex", alignItems: "center", justifyContent: "center", gap: "6px",
                        borderRadius: "10px", border: `1px solid ${theme.accent}`,
                        background: `${theme.accent}12`, color: theme.accent,
                        fontSize: "13px", fontWeight: 600, fontFamily: "inherit", cursor: "pointer",
                      }}
                    >
                      <Download size={14} /> Görünen {eksik.length} eseri indir
                    </button>
                  )
                })()}

                {/* İÇ LİSTE — KAYDIRMA ZİNCİRİ AÇIK. Eskiden `overscrollBehavior:
                    "contain"` vardı: parmak listenin üstündeyken liste sonuna
                    gelince kaydırma dış panele GEÇMİYORDU; açık bir bölümde bu
                    liste panelin büyük kısmını kapladığı için panel "kaymıyor"
                    gibi hissettiriyordu (kullanıcı bildirdi). Yükseklik de ekran
                    boyuna bağlandı ki panelde tutulacak boş yer kalsın. */}
                <div style={{
                  marginTop: "8px", maxHeight: "min(300px, 38vh)", overflowY: "auto",
                  border: `1px solid ${theme.border}`, borderRadius: "10px",
                }}>
                  {gorunen.length === 0 && (
                    <div style={{ padding: "14px", fontSize: "12px", color: theme.textSecondary, textAlign: "center" }}>
                      Eşleşme yok.
                    </div>
                  )}
                  {gorunen.map((kt, i) => {
                    const d = durum?.kitapDurum?.get(kt.id)
                    const hazirMi = Boolean(d && d.hazir)
                    const kismen = Boolean(d && d.kismen)
                    // Kısmen inmiş satırda hangi dosyanın eksik olduğu ADIYLA yazılıyor —
                    // "117/118"in hangi satırdan geldiği ilk bakışta görülsün.
                    const eksikYazi = kismen
                      ? (d.eksik.length <= 2
                          ? d.eksik.map(dosyaEtiketi).join(", ")
                          : `${d.eksik.length} dosya`) + " eksik"
                      : ""
                    return (
                      <div key={kt.id} style={{
                        display: "flex", alignItems: "center", gap: "10px",
                        padding: "9px 11px",
                        borderTop: i === 0 ? "none" : `1px solid ${theme.border}`,
                      }}>
                        <span style={{ flex: 1, minWidth: 0 }}>
                          <span style={{
                            display: "block", fontSize: "13px", color: theme.text,
                            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                          }}>{kt.ad}</span>
                          <span style={{
                            display: "block", fontSize: "11px", color: theme.textSecondary,
                            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                          }}>
                            {kismen
                              ? <span style={{ color: "#c0392b" }}>{eksikYazi}</span>
                              : [kt.yazar, hazirMi && d.bayt ? `≈${boyutMetni(d.bayt)}` : ""].filter(Boolean).join(" · ")}
                          </span>
                        </span>
                        {hazirMi ? (
                          <span style={{
                            flexShrink: 0, display: "flex", alignItems: "center", gap: "4px",
                            fontSize: "11px", color: theme.accent,
                          }}><Check size={13} /> hazır</span>
                        ) : kismen ? (
                          <button
                            onClick={() => indirBasla(d.eksik, kt.ad)}
                            disabled={!cevrimdisi?.destek}
                            style={{
                              flexShrink: 0, display: "flex", alignItems: "center", gap: "5px",
                              padding: "6px 10px", borderRadius: "8px",
                              background: `${theme.accent}14`, border: `1px solid ${theme.accent}`,
                              color: theme.accent, fontSize: "11px", fontWeight: 600,
                              fontFamily: "inherit", cursor: "pointer",
                            }}
                          ><Download size={12} /> tamamla</button>
                        ) : (
                          <button
                            onClick={() => indirBasla(kt.adresler, kt.ad)}
                            disabled={!cevrimdisi?.destek}
                            style={{
                              flexShrink: 0, display: "flex", alignItems: "center", gap: "5px",
                              padding: "6px 10px", borderRadius: "8px",
                              background: "transparent", border: `1px solid ${theme.accent}`,
                              color: theme.accent, fontSize: "11px", fontWeight: 600,
                              fontFamily: "inherit", cursor: "pointer",
                            }}
                          ><Download size={12} /> indir</button>
                        )}
                      </div>
                    )
                  })}
                </div>
              </>
            )}
          </>
        )}
      </Katlanir>

      {/* ── SESLER ────────────────────────────────────────────────────────
          Kâri sesleri DIŞ KAYNAKTAN geliyor ve kâriden kâriye bitrate değişiyor
          (her kâride 64 kbps yok). Bu yüzden hiçbir boyut varsayılmıyor:
          seçilen kâriden 20 âyet ÖRNEKLENİP bayt/kelime oranı çıkarılıyor ve
          her cüz/sûre kendi KELİME sayısıyla çarpılıyor. Âyet uzunlukları çok
          değişken olduğu için "âyet başına ortalama" kötü bir ölçü olurdu. */}
      <Katlanir
        theme={theme} ikon={Music} baslik="Sesler"
        ozet={sesVarlar && sesVarlar.size ? `${sesVarlar.size} âyet indirildi` : null}
        {...kapak("sesler")}
      >
        {!mushaf ? (
          <div style={{ fontSize: "12px", color: theme.textSecondary, padding: "6px 2px" }}>
            Mushaf verisi yükleniyor…
          </div>
        ) : (
          <>
            {/* Kâri */}
            <select
              value={kari}
              onChange={e => setKari(e.target.value)}
              style={{
                width: "100%", padding: "10px 11px", borderRadius: "10px",
                border: `1px solid ${theme.border}`, background: theme.background,
                color: theme.text, fontSize: "13px", fontFamily: "inherit",
              }}
            >
              {KARILAR.map(k => <option key={k.id} value={k.id}>{k.label}</option>)}
            </select>

            {/* Ölçüm */}
            {!olcum ? (
              <button
                onClick={boyutOlc} disabled={olcuyor}
                style={{
                  width: "100%", marginTop: "8px", padding: "10px 12px",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: "7px",
                  borderRadius: "10px", border: `1px solid ${theme.accent}`,
                  background: "transparent", color: theme.accent,
                  fontSize: "13px", fontWeight: 600, fontFamily: "inherit",
                  cursor: olcuyor ? "default" : "pointer", opacity: olcuyor ? 0.6 : 1,
                }}
              >
                {olcuyor ? <Loader size={15} className="veri-spin" /> : <Wifi size={15} />}
                {olcuyor ? "Ölçülüyor…" : "Bu kârinin boyutunu ölç"}
              </button>
            ) : olcum.hata ? (
              <div style={{ marginTop: "8px", fontSize: "12px", color: "#c0392b" }}>{olcum.hata}</div>
            ) : (
              <div style={{
                marginTop: "8px", padding: "9px 11px", borderRadius: "10px",
                border: `1px solid ${theme.border}`, background: theme.background,
                fontSize: "12px", color: theme.textSecondary, lineHeight: 1.6,
              }}>
                {olcum.orneklem} âyet örneklendi · tüm Kur'ân{" "}
                <b style={{ color: theme.text }}>
                  ≈{boyutMetni(tahminiBoyut(olcum, sureler.reduce((t, x) => t + x.kelime, 0)))}
                </b>
                <button onClick={boyutOlc}
                  style={{ marginLeft: "8px", background: "none", border: "none", color: theme.accent, fontSize: "11px", fontFamily: "inherit", cursor: "pointer", padding: 0 }}>
                  yeniden ölç
                </button>
              </div>
            )}

            {/* Cüz / Sûre sekmeleri */}
            <div style={{ display: "flex", gap: "6px", marginTop: "10px" }}>
              {[["cuz", `Cüz (${cuzler.length})`], ["sure", `Sûre (${sureler.length})`]].map(([id, et]) => (
                <button key={id} onClick={() => setSesSekme(id)}
                  style={{
                    flex: 1, padding: "8px", borderRadius: "9px", fontSize: "12px",
                    fontWeight: 600, fontFamily: "inherit", cursor: "pointer",
                    border: `1px solid ${sesSekme === id ? theme.accent : theme.border}`,
                    background: sesSekme === id ? `${theme.accent}15` : "transparent",
                    color: sesSekme === id ? theme.accent : theme.textSecondary,
                  }}>{et}</button>
              ))}
            </div>

            {sesSekme === "sure" && (
              <div style={{
                display: "flex", alignItems: "center", gap: "8px", marginTop: "8px",
                padding: "8px 11px", borderRadius: "10px",
                border: `1px solid ${theme.border}`, background: theme.background,
              }}>
                <Search size={14} color={theme.accent} style={{ flexShrink: 0 }} />
                <input value={sesArama} onChange={e => setSesArama(e.target.value)}
                  placeholder="Sûre adı ya da numarası…"
                  style={{ flex: 1, minWidth: 0, border: "none", outline: "none", background: "transparent", color: theme.text, fontSize: "13px", fontFamily: "inherit" }} />
                {sesArama && (
                  <button onClick={() => setSesArama("")} aria-label="Temizle"
                    style={{ background: "none", border: "none", color: theme.textSecondary, cursor: "pointer", display: "flex", padding: "2px" }}>
                    <X size={14} />
                  </button>
                )}
              </div>
            )}

            {/* İç liste — kaydırma zinciri açık (kitap listesindeki notun aynısı). */}
            <div style={{
              marginTop: "8px", maxHeight: "min(320px, 38vh)", overflowY: "auto",
              border: `1px solid ${theme.border}`, borderRadius: "10px",
            }}>
              {sesSatirlari.length === 0 && (
                <div style={{ padding: "14px", fontSize: "12px", color: theme.textSecondary, textAlign: "center" }}>Eşleşme yok.</div>
              )}
              {sesSatirlari.map((r, i) => {
                const tamHazir = r.hazir >= r.toplam
                const kismi = r.hazir > 0 && !tamHazir
                return (
                  <div key={r.ad} style={{
                    display: "flex", alignItems: "center", gap: "10px", padding: "9px 11px",
                    borderTop: i === 0 ? "none" : `1px solid ${theme.border}`,
                  }}>
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ display: "block", fontSize: "13px", color: theme.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.ad}</span>
                      <span style={{ display: "block", fontSize: "11px", color: theme.textSecondary, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {r.alt}
                        {olcum && !olcum.hata ? ` · ≈${boyutMetni(tahminiBoyut(olcum, r.kelime))}` : ""}
                        {kismi ? ` · ${r.hazir}/${r.toplam}` : ""}
                      </span>
                    </span>
                    {tamHazir ? (
                      <span style={{ flexShrink: 0, display: "flex", alignItems: "center", gap: "4px", fontSize: "11px", color: theme.accent }}>
                        <Check size={13} /> hazır
                      </span>
                    ) : (
                      <button onClick={() => indirBasla(r.adresler, r.ad)} disabled={!cevrimdisi?.destek || Boolean(indirme)}
                        style={{
                          flexShrink: 0, display: "flex", alignItems: "center", gap: "5px",
                          padding: "6px 10px", borderRadius: "8px", background: "transparent",
                          border: `1px solid ${theme.accent}`, color: theme.accent,
                          fontSize: "11px", fontWeight: 600, fontFamily: "inherit",
                          cursor: indirme ? "default" : "pointer", opacity: indirme ? 0.5 : 1,
                        }}><Download size={12} /> indir</button>
                    )}
                  </div>
                )
              })}
            </div>

            {sesVarlar && sesVarlar.size > 0 && (
              <div style={{ marginTop: "10px" }}>
                <OnayliDugme theme={theme} tehlike ikon={Trash2}
                  metin={`İndirilen sesleri sil (${sesVarlar.size} dosya)`}
                  onayMetni="Sesler silinecek! Tekrar dokunun"
                  onOnay={sesleriSil} />
                <div style={{ fontSize: "11px", color: theme.textSecondary, marginTop: "6px", lineHeight: 1.5 }}>
                  Sesler ayrı bir önbellekte durur; silmek metinlere dokunmaz.
                </div>
              </div>
            )}
          </>
        )}
      </Katlanir>

      {/* ── SES GEÇİŞ TEŞHİSİ — ⏸ YORUMDA (ileride lazım olabilir) ──────────
          Açmak için: useAudioPlayer.js'te SES_TESHIS = true yapıp aşağıdaki
          bölümün yorumunu kaldır. <SesTeshisi> bileşeni dosyada duruyor.
      <Katlanir
        theme={theme} ikon={Music} baslik="Ses geçiş teşhisi"
        {...kapak("teshis")}
      >
        <SesTeshisi theme={theme} bilgiVer={bilgiVer} />
      </Katlanir>
      */}

      {/* ── DÖNME TEŞHİSİ — ⏸ YORUMDA (ileride lazım olabilir) ──────────────
          Açmak için bu bölümün yorumunu kaldır ve KuranOkuma'daki "dönme
          teşhisi (yorumda)" satırlarını aç. <DonmeTeshisi> dosyada duruyor.
      <Katlanir
        theme={theme} ikon={RotateCw} baslik="Dönme teşhisi (geçici)"
        {...kapak("donme")}
      >
        <DonmeTeshisi theme={theme} bilgiVer={bilgiVer} />
      </Katlanir>
      */}

      {/* Loader'ın dönmesi için — `arama-spin` Arama.jsx'te tanımlı, buraya
          bağımlı olmayalım diye kendi adıyla kopyası. */}
      <style>{`@keyframes veri-spin { to { transform: rotate(360deg) } } .veri-spin { animation: veri-spin 0.9s linear infinite }`}</style>

      {/* ── BİLDİRİM ──────────────────────────────────────────────────────── */}
      {mesaj && (
        <div style={{
          marginTop: "12px", padding: "9px 12px", borderRadius: "10px",
          fontSize: "12px", lineHeight: 1.5,
          color: mesaj.tip === "iyi" ? theme.accent : "#c0392b",
          background: mesaj.tip === "iyi" ? `${theme.accent}12` : "#c0392b12",
          border: `1px solid ${mesaj.tip === "iyi" ? theme.accent : "#c0392b"}40`,
        }}>
          {mesaj.metin}
        </div>
      )}
    </div>
  )
}
