/* VUKUF — HIFZ MODU VERİ KATMANI
   src/data/hifz.js

   Ezber çalışmasının bütün kararları burada; bileşenler yalnız çiziyor.

   ── BİRİM ──────────────────────────────────────────────────────────────────
   Ezberin birimi TEK ÂYET ("2:255"). Sayfa/sûre birim yapılsaydı tekrar
   takvimi kaba kalırdı: bir sayfanın iki âyeti unutulmuşken gerisi sapasağlam
   olabiliyor. Âyet düzeyinde tutup sayfa/cüz özetini hesaplayarak çıkarıyoruz.

   ── KAYIT BİÇİMİ KISA ──────────────────────────────────────────────────────
   6236 âyet olabildiği için alan adları tek harf: d durum, t tekrar sayısı,
   a aralık indeksi, s sonraki tekrar günü, i ipucu sayısı, g son çalışma günü.
   Uzun adlarla aynı veri yaklaşık üç katı yer kaplıyordu.

   ── TEKRAR TAKVİMİ ─────────────────────────────────────────────────────────
   SM-2'nin sadeleştirilmişi: sabit aralık merdiveni + üç cevap.
   "Kolay" bir üst basamağa, "orta" aynı basamakta, "zor" başa döndürür.
   Gün, yerel saate göre gün numarası (gece yarısında döner) — saat tutulsaydı
   "bugünün tekrarı" listesi gün içinde kayardı. */

import { useCallback, useEffect, useState } from "react"

export const ANAHTAR = "vukuf-hifz"
/* /hifz ekranındaki "mushafta aç" hedefi buradan devrediliyor. Yönlendirme
   durumu (router state) sayfa yenilenince kaybolurdu; localStorage PWA'da
   geri dönüldüğünde de duruyor. Okuyan taraf okur okumaz siliyor. */
export const HEDEF_ANAHTAR = "vukuf-hifz-hedef"
/* Ters yön: okuma ekranından hıfz ekranına geçilirken "nereye döneceğiz"
   buraya yazılıyor; /hifz ekranı bunu görürse "Okumaya dön" düğmesini
   gösteriyor. Biçim: {"sure":2,"ayet":255,"kapsam":"sayfa"} */
export const DONUS_ANAHTAR = "vukuf-hifz-donus"

/* GİZLEME BİRİMİ — perdenin neyi sakladığı.
     kelime : âyetin baştan n kelimesi açık, gerisi perdeli (kademe belirler)
     ayet   : âyet ya tümüyle açık ya tümüyle perdeli; kademe devre dışı
   Zincir usulünde ikisi de işe yarıyor: kelime kademesi yeni ezberde,
   âyet birimi pekiştirmede. Bu yüzden ayar kullanıcıya bırakıldı. */
export const BIRIMLER = [
  { id: "kelime", ad: "Kelime" },
  { id: "ayet",   ad: "Âyet" },
]

// Tekrar aralıkları (gün). Son basamağa gelen âyet "oturmuş" sayılır.
export const ARALIKLAR = [1, 3, 7, 14, 30, 60]

export const DURUM = { YENI: 0, CALISILIYOR: 1, EZBERLENDI: 2 }

/* Perde kademeleri: her âyetin BAŞTAN kaç kelimesi açık kalacak.
   Baştan açık bırakmak bilinçli — hâfız âyetin başını hatırlayınca gerisi
   gelir; sondan açmak hatırlamaya yardım etmez, yalnız cevabı gösterir. */
export const KADEMELER = [
  { id: "tam",    ad: "Tam metin",    gorunur: (n) => n },
  { id: "ucte",   ad: "Üçte ikisi",   gorunur: (n) => Math.max(1, Math.ceil(n * 0.66)) },
  { id: "yarim",  ad: "Yarısı",       gorunur: (n) => Math.max(1, Math.ceil(n * 0.4)) },
  { id: "bas",    ad: "İlk kelime",   gorunur: () => 1 },
  { id: "kapali", ad: "Kapalı",       gorunur: () => 0 },
]
export const kademeBul = (id) => KADEMELER.find(k => k.id === id) || KADEMELER[0]
export const sonrakiKademe = (id) => {
  const i = KADEMELER.findIndex(k => k.id === id)
  return KADEMELER[Math.min(KADEMELER.length - 1, (i < 0 ? 0 : i) + 1)].id
}
export const oncekiKademe = (id) => {
  const i = KADEMELER.findIndex(k => k.id === id)
  return KADEMELER[Math.max(0, (i < 0 ? 0 : i) - 1)].id
}

export const birimAnahtar = (sureNo, ayetNo) => `${sureNo}:${ayetNo}`
export const anahtarCoz = (a) => {
  const [s, y] = String(a).split(":")
  return { sureNo: Number(s), ayetNo: Number(y) }
}

/* Yerel gün numarası. Saat/dakika atılıyor: aynı takvim gününde yapılan iki
   çalışma aynı güne düşsün, "yarın" da gerçekten yarın olsun. */
export function bugun() {
  const d = new Date()
  // Yerel saat farkı çıkarılıyor → gün numarası GECE YARISINDA dönüyor.
  // Ham epoch kullanılsaydı UTC'ye göre döner, bizde akşam saatlerinde
  // "yarının tekrarı" bugün görünürdü.
  return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000)
}

const BOS = {
  birimler: {},
  // dokunAc: perdeli yere dokununca orası açılsın mı (eskiden hep açılıyordu → varsayılan açık)
  // dokunSes: dokunulan kelime okunsun mu (29 Eylül 2026, yeni → varsayılan kapalı; kullanıcı seçer)
  ayarlar: {
    kademe: "yarim", tekrarSayisi: 3, zincir: true, birim: "kelime", dokunAc: true, dokunSes: false,
    // EZBER PLANI (30 Eylül 2026) — ayrıntısı aşağıdaki "EZBER PLANI" bölümünde
    ezber: "sayfa",        // "sayfa" | "sure" | "donus"
    sayfaKismi: "tam",     // "tam" | "ust" | "alt"   (sayfa ve dönüşte)
    yon: "yukari",         // "yukari" (yukarıdan aşağı) | "asagi" (aşağıdan yukarı)
    tekrarYontem: "duz",   // "duz" | "baglama"
    bagla: true,           // bağlamada komşu (önceden ezberlenmiş) âyetle başla
    donus: { bas: "son", sira: 0 },   // dönüşün başladığı uç + dizideki yer
    manuel: { sure: 1, bas: 1, son: 7 },   // elle yazılan sûre + âyet aralığı
    sureSira: "orijinal",  // sûre listesi: "orijinal" | "kisa" (kısadan uzuna) | "uzun" (uzundan kısaya)
    // UYARILAR (3 Ekim 2026): kullanıcı "X gün gecikti" gibi uyarıları görmek istemeyebilir.
    bildirimGizle: false,  // gecikme rozetleri, panel rozeti ve yedek hatırlatması gizli
    yedekErtele: 0,        // yedek hatırlatması bu günden (bugun() sayısı) önce gösterilmez
    // ZAMANLAMA (3 Ekim 2026) — ayrıntısı aşağıda "ZAMANLAMA" bölümünde
    tekrarModu: "otomatik", // "otomatik": takvim + listem · "elle": yalnız listem
    eskiTakvim: false,      // "Ezberlediklerimi ekle"de eklenenler takvime de girsin mi
  },
}

let bellek = null
const aboneler = new Set()

export function hifzOku() {
  if (bellek) return bellek
  try {
    const ham = JSON.parse(localStorage.getItem(ANAHTAR) || "{}")
    bellek = {
      birimler: (ham && ham.birimler) || {},
      ayarlar: { ...BOS.ayarlar, ...(ham && ham.ayarlar) },
    }
  } catch { bellek = { birimler: {}, ayarlar: { ...BOS.ayarlar } } }
  return bellek
}

function yaz(yeni) {
  bellek = yeni
  try { localStorage.setItem(ANAHTAR, JSON.stringify(yeni)) } catch { /* kota */ }
  for (const f of aboneler) f(yeni)
  return yeni
}

export function ayarGuncelle(parca) {
  const v = hifzOku()
  return yaz({ ...v, ayarlar: { ...v.ayarlar, ...parca } })
}

const birimAl = (v, a) => v.birimler[a] || { d: DURUM.YENI, t: 0, a: -1, s: 0, i: 0, g: 0 }

/* Çalışıldı işareti — ezberlendi DEĞİL. Yalnız "bugün baktım" bilgisi. */
export function calisildi(anahtarlar) {
  const v = hifzOku()
  const g = bugun()
  const birimler = { ...v.birimler }
  for (const a of anahtarlar) {
    const b = birimAl(v, a)
    birimler[a] = { ...b, g, d: b.d === DURUM.YENI ? DURUM.CALISILIYOR : b.d }
  }
  return yaz({ ...v, birimler })
}

export function ipucuAlindi(anahtar) {
  const v = hifzOku()
  const b = birimAl(v, anahtar)
  return yaz({ ...v, birimler: { ...v.birimler, [anahtar]: { ...b, i: (b.i || 0) + 1 } } })
}

/* ── ZAMANLAMA (3 Ekim 2026) ─────────────────────────────────────────────────
   Kullanıcı: "zaten ezberinde olan kısımlar için tekrar gerekmez, yeni
   ezberlenmişse gerekebilir. Kullanıcı isterse tekrar listesine alabilir;
   isterse otomatik moddan devam eder, bugünün tekrarı otomatik oluşur."
   Her ezberli birimin iki bağımsız bayrağı var:
     p  TAKVİMDE Mİ  — otomatik tekrar planına giriyor mu. Mushafta "Ezberledim"
        ile yeni ezberlenen → takvimde. "Ezberlediklerimi ekle" ile eklenen eski
        ezber → varsayılan takvim DIŞI (istenirse takvime alınır).
        Eski kayıtlarda alan yok → takvimde sayılır (önceki davranış).
     l  TEKRAR LİSTEMDE — kullanıcının elle "Tekrara al" dediği; cevaplanınca
        listeden düşer. Takvimden bağımsız.
   Bugünün tekrarı = (otomatik modda) vadesi gelen takvimdekiler + listem.
   Elle modda yalnız listem. c = son cevap günü (bugün kaç tane bitti). */
export const takvimde = (b) => !!b && b.d === DURUM.EZBERLENDI && b.p !== false

/* Ezberlendi: takvime ilk basamaktan girer (yarın tekrar). */
export function ezberlendi(anahtarlar) {
  const v = hifzOku()
  const g = bugun()
  const birimler = { ...v.birimler }
  for (const a of anahtarlar) {
    const b = birimAl(v, a)
    birimler[a] = { ...b, d: DURUM.EZBERLENDI, g, a: 0, s: g + ARALIKLAR[0], t: (b.t || 0) + 1, p: true }
  }
  return yaz({ ...v, birimler })
}

/* Takvime al / takvimden çıkar (yalnız ezberliler). Takvime ilk kez giren eski
   ezberin ilk tekrarları önümüzdeki 14 güne yayılır (hepsi yarına yığılmasın). */
export function takvimAyarla(anahtarlar, acik) {
  const v = hifzOku()
  const g = bugun()
  const birimler = { ...v.birimler }
  const hedef = anahtarlar.filter(a => (birimler[a] || {}).d === DURUM.EZBERLENDI)
  const yeni = hedef.filter(a => acik && !takvimde(birimler[a]))
  hedef.forEach(a => { if (!acik) birimler[a] = { ...birimler[a], p: false } })
  yeni.forEach((a, i) => {
    const b = birimler[a]
    const gun = 1 + Math.floor((i * 14) / Math.max(1, yeni.length))
    birimler[a] = { ...b, p: true, a: typeof b.a === "number" && b.a >= 0 ? b.a : 2, s: (b.s || 0) > g ? b.s : g + gun }
  })
  return yaz({ ...v, birimler })
}

/* Tekrar listem — ekle/çıkar. Yalnız ezberli âyetler listeye girer. */
export function listeyeEkle(anahtarlar) {
  const v = hifzOku()
  const g = bugun()
  const birimler = { ...v.birimler }
  for (const a of anahtarlar) {
    const b = birimler[a]
    if (b && b.d === DURUM.EZBERLENDI && !b.l) birimler[a] = { ...b, l: g }
  }
  return yaz({ ...v, birimler })
}
export function listedenCikar(anahtarlar) {
  const v = hifzOku()
  const birimler = { ...v.birimler }
  for (const a of anahtarlar) {
    const b = birimler[a]
    if (b && b.l) { const { l: _l, ...kalan } = b; birimler[a] = kalan }
  }
  return yaz({ ...v, birimler })
}

/* Yalnız henüz ezberlenmemiş olanları "ezberlendi" yap — zaten ezberli
   âyetin tekrar takvimi SIFIRLANMASIN (sûreye ✓ atınca yarısı ezberliyse). */
export function ezberleEksikleri(anahtarlar) {
  const v = hifzOku()
  const eksik = anahtarlar.filter(a => (v.birimler[a] || {}).d !== DURUM.EZBERLENDI)
  return eksik.length ? ezberlendi(eksik) : v
}

/* ESKİDEN EZBERLENMİŞ KISIM EKLE (Hıfz ekranı → "Ezberlediklerimi ekle").
   Kullanıcı yıllar önce ezberlediği bir sûreyi/aralığı ekliyor. Normal
   "ezberlendi" gibi hepsini YARINA tekrar koymak, büyük bir ekleme (ör. bir
   cüz) "bugün tekrar" listesini yüzlerce âyetle doldururdu. Bunun yerine:
   takvime 3. basamaktan (7 gün aralık) giriyor ve İLK tekrarları mushaf
   sırasıyla önümüzdeki 14 güne YAYILIYOR. Zaten ezberli âyete dokunulmuyor. */
export function eskiEzberEkle(anahtarlar, { takvim = false } = {}) {
  const v = hifzOku()
  const g = bugun()
  const birimler = { ...v.birimler }
  const eksik = anahtarlar.filter(a => (birimler[a] || {}).d !== DURUM.EZBERLENDI)
  const n = eksik.length
  eksik.forEach((a, i) => {
    const b = birimAl(v, a)
    const gun = 1 + Math.floor((i * 14) / Math.max(1, n))          // 1..14
    // Takvim dışı (3 Ekim 2026 varsayılanı): ezberli sayılır, yüzdeye katılır,
    // ama kendiliğinden tekrara gelmez — istenirse listeye/takvime alınır.
    birimler[a] = takvim
      ? { ...b, d: DURUM.EZBERLENDI, g, a: 2, s: g + gun, t: (b.t || 0) + 1, p: true }
      : { ...b, d: DURUM.EZBERLENDI, g, a: 2, s: 0, t: (b.t || 0) + 1, p: false }
  })
  return yaz({ ...v, birimler })
}

export function geriAl(anahtarlar) {
  const v = hifzOku()
  const birimler = { ...v.birimler }
  for (const a of anahtarlar) delete birimler[a]
  return yaz({ ...v, birimler })
}

/* ── DÜZENLEME GÜVENLİĞİ: SON DEĞİŞİKLİĞİ GERİ AL (2 Ekim 2026) ────────────
   Kullanıcı: "ezberledikleri hatalı eklenirse diye düzenleme ve sıfırlama".
   Hıfz ekranındaki her elle ekleme/çıkarma/sıfırlamadan ÖNCE birimlerin o anki
   hâli tek bir yedek yuvasına yazılıyor; "Geri al" onu geri koyuyor. Yuva
   localStorage'da — sayfadan çıkıp dönünce de geri alınabiliyor. Tek yuva:
   yalnız EN SON değişiklik geri alınır (yeni değişiklik eskisinin yerine geçer). */
export const YEDEK_ANAHTAR = "vukuf-hifz-yedek"

export function yedekAl(aciklama) {
  const v = hifzOku()
  try {
    localStorage.setItem(YEDEK_ANAHTAR, JSON.stringify({ z: Date.now(), aciklama, birimler: v.birimler }))
  } catch { /* kota — yedeksiz devam */ }
}

export function yedekOku() {
  try {
    const y = JSON.parse(localStorage.getItem(YEDEK_ANAHTAR) || "null")
    return y && y.birimler ? y : null
  } catch { return null }
}

export function yedektenDon() {
  const y = yedekOku()
  if (!y) return null
  try { localStorage.removeItem(YEDEK_ANAHTAR) } catch { /* yoksay */ }
  const v = hifzOku()
  yaz({ ...v, birimler: y.birimler })
  return y
}

/* SIFIRLAMA. Ayarlar (perde, ezber tercihi…) hiçbirinde silinmiyor.
     "ezber"  → ezber işaretleri ve tekrar takvimi silinir; ipucu sayaçları
                (zor âyetler) kalır.
     "ipucu"  → yalnız ipucu sayaçları sıfırlanır.
     "hepsi"  → bütün hıfz ilerlemesi (ezber, çalışılan, ipucu). */
export function sifirla(tur) {
  const v = hifzOku()
  if (tur === "hepsi") return yaz({ ...v, birimler: {} })
  const birimler = {}
  for (const [a, b] of Object.entries(v.birimler)) {
    if (tur === "ezber") {
      if (b.d !== DURUM.EZBERLENDI) birimler[a] = b
      else if ((b.i || 0) > 0) birimler[a] = { d: DURUM.YENI, t: 0, a: -1, s: 0, i: b.i, g: b.g || 0 }
    } else if (tur === "ipucu") {
      const yeni = { ...b, i: 0 }
      // Yalnız ipucu için tutulan (hiç çalışılmamış) kayıt artık boş → sil
      if (yeni.d !== DURUM.YENI) birimler[a] = yeni
    } else birimler[a] = b
  }
  return yaz({ ...v, birimler })
}

/* Elle ezberden çıkarma (Hıfz ekranı düzenleme). geriAl'dan farkı: âyetin
   ipucu sayacı (zor âyetler listesi) korunuyor, yalnız ezber + takvim gidiyor. */
export function ezberdenCikar(anahtarlar) {
  const v = hifzOku()
  const birimler = { ...v.birimler }
  for (const a of anahtarlar) {
    const b = birimler[a]
    if (!b || b.d !== DURUM.EZBERLENDI) continue
    if ((b.i || 0) > 0) birimler[a] = { d: DURUM.YENI, t: 0, a: -1, s: 0, i: b.i, g: b.g || 0 }
    else delete birimler[a]
  }
  return yaz({ ...v, birimler })
}

/* Bellekteki kopyayı at ve depodan yeniden oku. Hıfz kaydı bu modülün
   DIŞINDAN değiştiğinde (Ayarlar → Veriler → "Hıfz kaydı"nı sıfırla) çağrılır;
   yoksa bellekteki eski kopya bir sonraki yazışta silinen veriyi geri yazardı. */
export function hifzTazele() {
  bellek = null
  const v = hifzOku()
  for (const f of aboneler) f(v)
  return v
}

/* ── HIFZ YEDEĞİ (3 Ekim 2026) ───────────────────────────────────────────────
   Hıfz kaydı yalnız bu cihazın tarayıcı deposunda duruyor; site verisi
   temizlenir, uygulama silinir ya da telefon değişirse ilerleme gider.
   Biçim GENEL VUKUF YEDEĞİYLE AYNI (uygulama/surum/tarih/veriler) ve içinde
   yalnız "vukuf-hifz" anahtarı var → bu dosya Ayarlar → Veriler → "Geri yükle"
   ile de yüklenebilir; tersine, genel yedek dosyası da burada okunabilir
   (içinden yalnız hıfz kaydı alınır). */
export function hifzYedekNesnesi() {
  const v = hifzOku()
  return {
    uygulama: "vukuf", surum: 1, tur: "hifz",
    tarih: new Date().toISOString(), adet: 1,
    veriler: { [ANAHTAR]: JSON.stringify(v) },
  }
}
export const hifzYedekMetni = () => JSON.stringify(hifzYedekNesnesi(), null, 2)
export function hifzYedekDosyaAdi() {
  const d = new Date()
  const ik = (n) => String(n).padStart(2, "0")
  return `vukuf-hifz-yedek-${d.getFullYear()}-${ik(d.getMonth() + 1)}-${ik(d.getDate())}.json`
}
export function hifzYedekIndir() {
  try {
    const blob = new Blob([hifzYedekMetni()], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = hifzYedekDosyaAdi()
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    setTimeout(() => { try { URL.revokeObjectURL(url) } catch { /* yoksay */ } }, 4000)
    return true
  } catch { return false }
}

/* Yedek metnini çöz. Dönen: { tarih, veri, ezber, kayit } ya da { hata }. */
export function hifzYedekCoz(metin) {
  let d
  try { d = JSON.parse(metin) } catch { return { hata: "Dosya okunamadı — geçerli bir JSON değil." } }
  if (!d || typeof d !== "object" || d.uygulama !== "vukuf") return { hata: "Bu dosya bir Vukuf yedeği değil." }
  const ham = d.veriler && d.veriler[ANAHTAR]
  if (typeof ham !== "string") return { hata: "Bu yedekte hıfz kaydı yok." }
  let veri
  try { veri = JSON.parse(ham) } catch { return { hata: "Yedekteki hıfz kaydı bozuk." } }
  if (!veri || typeof veri.birimler !== "object" || !veri.birimler) return { hata: "Yedekteki hıfz kaydı bozuk." }
  const kayitlar = Object.values(veri.birimler)
  return {
    tarih: d.tarih || null,
    veri,
    ezber: kayitlar.filter(b => b && b.d === DURUM.EZBERLENDI).length,
    kayit: kayitlar.length,
  }
}

/* Yedeği uygula.
     "degistir"  → bu cihazdaki hıfz kaydı (ayarlar dahil) yedektekiyle değişir.
     "birlestir" → iki taraf birleşir: yalnız birinde olan âyet alınır; ikisinde
                   de varsa EZBERLİ olan, ikisi de aynı durumdaysa SON ÇALIŞILAN
                   (g) kazanır; ipucu sayacı büyük olan kalır. Ayarlar değişmez. */
export function hifzYedekUygula(veri, kip = "birlestir") {
  const v = hifzOku()
  if (kip === "degistir") {
    return yaz({ birimler: { ...veri.birimler }, ayarlar: { ...BOS.ayarlar, ...(veri.ayarlar || {}) } })
  }
  const birimler = { ...v.birimler }
  for (const [a, y] of Object.entries(veri.birimler)) {
    if (!y || typeof y !== "object") continue
    const b = birimler[a]
    if (!b) { birimler[a] = y; continue }
    const yEz = y.d === DURUM.EZBERLENDI, bEz = b.d === DURUM.EZBERLENDI
    let kazanan = b
    if (yEz !== bEz) kazanan = yEz ? y : b
    else if ((y.g || 0) > (b.g || 0)) kazanan = y
    birimler[a] = { ...kazanan, i: Math.max(b.i || 0, y.i || 0) }
  }
  return yaz({ ...v, birimler })
}

/* Ezberli âyetleri sûre sûre ARDIŞIK ARALIKLARA topla — düzenleme listesi için.
   `sureler`: [{ id, isim, ayetSayisi }] (mushaf sırası). */
export function ezberAraliklari(veri, sureler) {
  const sonuc = []
  for (const s of sureler) {
    const araliklar = []
    let bas = null, n = 0, takvimli = 0, listede = 0
    for (let a = 1; a <= s.ayetSayisi + 1; a++) {
      const b = a <= s.ayetSayisi ? veri.birimler[`${s.id}:${a}`] : null
      const ezberli = !!b && b.d === DURUM.EZBERLENDI
      if (ezberli) {
        if (bas == null) bas = a
        n++
        if (takvimde(b)) takvimli++
        if (b.l) listede++
      } else if (bas != null) { araliklar.push({ bas, son: a - 1 }); bas = null }
    }
    if (araliklar.length) sonuc.push({ ...s, ezberli: n, takvimli, listede, araliklar })
  }
  return sonuc
}

/* Tekrar cevabı. zorluk: "kolay" | "orta" | "zor" */
export function cevapla(anahtar, zorluk) {
  const v = hifzOku()
  const b = birimAl(v, anahtar)
  const g = bugun()
  let a = typeof b.a === "number" ? b.a : 0
  if (zorluk === "kolay") a = Math.min(ARALIKLAR.length - 1, a + 1)
  else if (zorluk === "zor") a = 0
  // "orta" → basamak aynı kalır
  // "Zor" denen takvim dışı âyet takvime girer: zorlandıysa tekrar gerekiyor.
  const p = zorluk === "zor" ? true : b.p
  const { l: _l, ...kalan } = b                     // cevaplanan listeden düşer
  const yeni = { ...kalan, d: DURUM.EZBERLENDI, a, g, c: g, p, t: (b.t || 0) + 1, s: g + ARALIKLAR[Math.max(0, a)] }
  return yaz({ ...v, birimler: { ...v.birimler, [anahtar]: yeni } })
}

/* Toplu cevap — bir aralığın (grup) bütün âyetleri tek yazışta. */
export function topluCevapla(anahtarlar, zorluk) {
  for (const a of anahtarlar) cevapla(a, zorluk)
  return hifzOku()
}

/* Bugünün tekrarı — en geciken önce. Kaynak: "liste" (elle eklenen) ya da
   "takvim" (otomatik planda vadesi gelen). Elle modda takvim gösterilmez. */
export function bekleyenTekrarlar(veri = hifzOku(), gun = bugun()) {
  const otomatik = (veri.ayarlar && veri.ayarlar.tekrarModu) !== "elle"
  return Object.entries(veri.birimler)
    .filter(([, b]) => b.d === DURUM.EZBERLENDI &&
      (b.l || (otomatik && takvimde(b) && (b.s || 0) <= gun)))
    .map(([a, b]) => ({
      anahtar: a, ...anahtarCoz(a), ...b,
      kaynak: b.l ? "liste" : "takvim",
      gecikme: takvimde(b) && (b.s || 0) <= gun ? gun - (b.s || 0) : 0,
    }))
    .sort((x, y) => y.gecikme - x.gecikme || x.sureNo - y.sureNo || x.ayetNo - y.ayetNo)
}

/* Bugün cevaplanan âyet sayısı — "bugün 4 / 10" ilerlemesi için. */
export function bugunTamamlanan(veri = hifzOku(), gun = bugun()) {
  let n = 0
  for (const b of Object.values(veri.birimler)) if (b.c === gun) n++
  return n
}

/* Bekleyenleri ARALIKLARA topla: aynı sûrede ardışık ve aynı kaynaktan olan
   âyetler tek satır ("Yâsîn 1–12"). 83 âyetlik bir sûre 83 satır olmasın. */
export function tekrarGruplari(liste) {
  const sirali = [...liste].sort((x, y) => x.sureNo - y.sureNo || x.ayetNo - y.ayetNo)
  const gruplar = []
  for (const b of sirali) {
    const o = gruplar[gruplar.length - 1]
    if (o && o.sureNo === b.sureNo && o.son === b.ayetNo - 1 && o.kaynak === b.kaynak) {
      o.son = b.ayetNo; o.anahtarlar.push(b.anahtar); o.gecikme = Math.max(o.gecikme, b.gecikme)
    } else {
      gruplar.push({ sureNo: b.sureNo, bas: b.ayetNo, son: b.ayetNo, kaynak: b.kaynak,
        gecikme: b.gecikme, anahtarlar: [b.anahtar] })
    }
  }
  return gruplar.sort((x, y) => y.gecikme - x.gecikme || x.sureNo - y.sureNo || x.bas - y.bas)
}

/* En çok ipucu alınan âyetler — "zor âyetler" listesi. */
export function zorAyetler(veri = hifzOku(), adet = 20) {
  return Object.entries(veri.birimler)
    .filter(([, b]) => (b.i || 0) > 0)
    .map(([a, b]) => ({ anahtar: a, ...anahtarCoz(a), ipucu: b.i || 0 }))
    .sort((x, y) => y.ipucu - x.ipucu)
    .slice(0, adet)
}

export function ozet(veri = hifzOku()) {
  let ezber = 0, calisilan = 0
  for (const b of Object.values(veri.birimler)) {
    if (b.d === DURUM.EZBERLENDI) ezber++
    else if (b.d === DURUM.CALISILIYOR) calisilan++
  }
  return { ezber, calisilan, bekleyen: bekleyenTekrarlar(veri).length }
}

/* ── PERDE CSS ───────────────────────────────────────────────────────────────
   Gizleme React ile DEĞİL, üretilen bir stil etiketiyle yapılıyor. Sebebi
   önemli: mushaf sayfaları kaydırdıkça monte olup sökülüyor; DOM'a elle sınıf
   yazsaydık, sonradan monte olan kelimeler perdesiz gelirdi. CSS kuralı ise
   yeni gelen düğümlere kendiliğinden uyuyor. Ayrıca yüzlerce kelimeye prop
   geçmediğimiz için sayfa yeniden çizilmiyor.

   ⚠ PERDE ARTIK SOLUKLUK DEĞİL BULANIKLIK. Solukluk (opacity .07) kopya
   çekmeye açıktı: metin duruyor, yalnız soluk; ekranı eğip ya da parlaklığı
   açıp okunabiliyordu. `filter: blur()` glifleri gerçekten dağıtıyor, geri
   getirilebilecek bir kenar bırakmıyor.
   Neden `color: transparent` + `text-shadow` değil: kelimenin Arapça metni
   MushafKelime içinde SATIR İÇİ (inline) `color` ile çiziliyor, stil sayfası
   onu ezemez. `filter` satır içi renkten bağımsız çalışıyor ve mutlak konumlu
   tecvid/vakıf işaretlerini de birlikte bulandırıyor.

   `gizliler`: Map(anahtar → baştan görünür kelime sayısı).
   `disSayfalar`: kapsam DIŞINDA kalan ama ekranın kenarından görünebilen
   sayfalar. Kelime kelime bulandırmak yerine sayfa kabuğuna TEK kural
   veriliyor; yoksa monte 40+ sayfanın ~5000 kelimesi ayrı ayrı katman açardı. */
export const PERDE_SINIF = "vukuf-hifz"
export const ACIK_SINIF = "hifz-gosterildi"

export function perdeCss(gizliler, { disSayfalar = [] } = {}) {
  const bulanik = "var(--hifz-bulanik,6px)"
  const s = [
    `.${PERDE_SINIF} [data-hifz]{transition:filter .2s ease}`,
    // İpucu (kelimeye dokunma) her şeyi ezer.
    `.${PERDE_SINIF} .${ACIK_SINIF}{filter:none !important}`,
  ]
  for (const [anahtar, gorunur] of gizliler) {
    // -1 = âyet tümüyle açık. Hiç kural yazılmıyor: yoksa önce bulanıklık
    // veriliyor, sonra kelime kelime geri alınıyordu — tarayıcıya boşuna yük.
    if (gorunur < 0) continue
    s.push(`.${PERDE_SINIF} [data-hifz="${anahtar}"]{filter:blur(${bulanik})}`)
    if (gorunur > 0) {
      const sec = []
      for (let i = 1; i <= gorunur; i++) {
        sec.push(`.${PERDE_SINIF} [data-hifz="${anahtar}"][data-hs="${i}"]`)
      }
      s.push(`${sec.join(",")}{filter:none}`)
    }
  }
  if (disSayfalar.length) {
    const sec = disSayfalar.map(n => `.${PERDE_SINIF} [data-index="${n}"]`).join(",")
    // Kapsam dışı sayfa: daha kuvvetli bulanıklık + hafif soluklaştırma, ve
    // dokunulamaz (yanlışlıkla oradan ipucu açılmasın).
    s.push(`${sec}{filter:blur(calc(${bulanik} * 1.6));opacity:.45;pointer-events:none}`)
  }
  return s.join("\n")
}

/* Bir âyet aralığı için gizleme haritası.
   kelimeSayisi(anahtar) → o âyetin kelime sayısı (mushaf verisinden).
   zincir=true iken: SIRADAKİ âyet tam açık, ÖNCEKİLER seçili kademede,
   SONRAKİLER tamamen kapalı. Sonrakiler eskiden hiç perdelenmiyordu (haritaya
   bile girmiyorlardı): zincirin bir sonraki âyeti ekranda açıkça duruyordu,
   yani ezber sınavı kendi cevabını gösteriyordu.
   birim="ayet" iken kademe yok sayılıyor: âyet ya tam açık ya tam kapalı. */
export function gizlemeHaritasi({
  anahtarlar, kademe, zincir, aktifAnahtar, kelimeSayisi, birim = "kelime", yon = "yukari",
}) {
  const harita = new Map()
  const k = kademeBul(kademe)
  // AŞAĞIDAN YUKARI ezberde "henüz gelinmemiş" âyetler aktifin ÖNCESİ (üstü),
  // ezberlenmiş olanlar SONRASI (altı) — zincirin yönü ters.
  const ai = zincir ? anahtarlar.indexOf(aktifAnahtar) : -1
  anahtarlar.forEach((a, i) => {
    const n = Math.max(1, kelimeSayisi(a) || 1)
    // -1 → "tümüyle açık"; perdeCss bu âyet için hiç kural üretmiyor.
    if (zincir && i === ai) { harita.set(a, -1); return }
    if (zincir && ai >= 0 && (yon === "asagi" ? i < ai : i > ai)) { harita.set(a, 0); return }   // henüz gelinmedi
    const gorunur = birim === "ayet" ? 0 : k.gorunur(n)
    harita.set(a, gorunur >= n ? -1 : gorunur)
  })
  return harita
}

/* ═══════════════════════════════════════════════════════════════════════════
   EZBER PLANI (30 Eylül 2026) — kullanıcının tarif ettiği usuller

   1) EZBER TERCİHİ — neyin ezberlendiği:
      • Sayfa  : bulunulan sayfa; tamamı ya da ÜST / ALT yarısı.
      • Sûre   : bulunulan sûre (asıl amaç kısa sûreler; panelde kısa sûreler
                 listesi var — "kısa" = en çok 2 sayfaya yayılan, MUSHAF
                 VERİSİNDEN hesaplanıyor, elle yazılmış liste yok).
      • Dönüş  : Türk usulü hafızlık. Her DÖNÜŞ'te 30 cüzün her birinden
                 aynı sıradaki BİR sayfa: 1. dönüş = her cüzün son sayfası
                 (klasik usul, "cüz sonundan") ya da ilk sayfası ("cüz
                 başından"); 2. dönüş = sondan/baştan ikinci sayfa… Cüz
                 sınırları ve sayfa sayıları mushaf verisinden (her âyetin
                 kendi `cuz` ve `sayfa` alanı); 20'den uzun cüzlerde fazla
                 sayfalar son dönüşlere düşüyor, kısa cüz atlanıyor.
   2) SIRA — sayfa/sûre içinde yeni âyetlerin geliş sırası: yukarıdan aşağı
      ya da AŞAĞIDAN YUKARI. Aşağıdan yukarıda YALNIZ YENİ ÂYETİN SIRASI
      tersine döner; birlikte okunan bloklar HER ZAMAN mushaf sırasıyla
      okunur (Kur'ân tersten okunmaz).
   3) TEKRAR YÖNTEMİ:
      • Düz     : seçilen âyetler N kez.
      • Bağlama : yeni âyet N kez → öğrenilenlerin hepsi birlikte bir kez →
                  sonraki yeni âyet N kez → hepsi birlikte… (1; 1-2; 1-2-3…)
                  "Komşuyla bağla" açıksa blok, ÖNCEDEN EZBERLENMİŞ komşu
                  âyetle başlar: sayfada önceki sayfanın son âyeti (alt yarıda
                  üst yarının son âyeti); cüz sonundan dönüşte ise sonraki
                  sayfanın ilk âyeti (çünkü orası bir önceki dönüşte ezberlendi).
   ═══════════════════════════════════════════════════════════════════════════ */
export const EZBER_TERCIHLERI = [
  { id: "sayfa", ad: "Sayfa" },
  { id: "sure",  ad: "Sûre" },
  { id: "donus", ad: "Dönüş" },
  { id: "manuel", ad: "Manuel" },
]
export const SAYFA_KISIMLARI = [
  { id: "tam", ad: "Tamamı" },
  { id: "ust", ad: "Üst yarı" },
  { id: "alt", ad: "Alt yarı" },
]
export const YONLER = [
  { id: "yukari", ad: "Yukarıdan aşağı" },
  { id: "asagi",  ad: "Aşağıdan yukarı" },
]
export const TEKRAR_YONTEMLERI = [
  { id: "duz",     ad: "Düz" },
  { id: "baglama", ad: "Bağlama" },
]
export const SURE_SIRALARI = [
  { id: "orijinal", ad: "Mushaf sırası" },
  { id: "kisa",     ad: "Kısadan uzuna" },
  { id: "uzun",     ad: "Uzundan kısaya" },
]

/* Sûre listesi sıralama: uzunluk ÂYET sayısıyla (eşitse kelime sayısı),
   ezberlenmiş sûreler (✓) her zaman listenin SONUNA iniyor. */
export function sureListesiSirala(liste, sira = "orijinal") {
  const l = [...liste]
  if (sira === "kisa") l.sort((a, b) => (a.ayetSayisi - b.ayetSayisi) || ((a.kelime || 0) - (b.kelime || 0)) || (a.id - b.id))
  else if (sira === "uzun") l.sort((a, b) => (b.ayetSayisi - a.ayetSayisi) || ((b.kelime || 0) - (a.kelime || 0)) || (a.id - b.id))
  else l.sort((a, b) => a.id - b.id)
  return [...l.filter(x => !x.ezber), ...l.filter(x => x.ezber)]
}

/* MANUEL ARAMA — "bakara 5-10", "2:5-10", "yasin", "36 1-12", "fussilet, 44".
   Dönüş: [{ id, isim, ayetSayisi, bas, son }] (en çok `sinir` öneri).
   normla: harf normalleştirici (şapka/aksan/büyük-küçük duyarsız).
   AYRAÇ DUYARSIZ (11 Ekim 2026, sûre menüsüyle aynı): sûre adında kesme, tire,
   nokta ve boşluk yok sayılıyor → "rad" = Ra'd, "aliimran" / "al-i imran" /
   "ali imran 5-10" = Âl-i İmrân, "mumin" = Mü'min (normla ü→u yapıyorsa). */
const AYRAC_SURE = /['`´‘’ʻʼʾʿ‐-―.\s-]/g
export function manuelOneriler(sorgu, sureler, normla = (s) => s.toLowerCase(), sinir = 8) {
  const q = String(sorgu || "").trim()
  if (!q) return []
  const sik = (x) => normla(String(x || "")).replace(AYRAC_SURE, "")
  // Aralık: sondaki "5", "5-10", "5–10", ":5-10", ", 5-10"
  const m = q.match(/^(.*?)[\s,:]*?(\d+)(?:\s*[-–]\s*(\d+))?\s*$/)
  let ad = q, a1 = null, a2 = null
  if (m && m[1].trim()) { ad = m[1].trim(); a1 = parseInt(m[2], 10); a2 = m[3] ? parseInt(m[3], 10) : null }
  else if (m && !m[1].trim() && !m[3]) { ad = m[2]; }          // yalnız sayı → sûre no
  else if (m && !m[1].trim() && m[3]) { ad = m[2]; a1 = parseInt(m[3], 10) }   // "2 5" gibi değil; "2-5" sûre 2 âyet 5
  const nq = sik(ad.replace(/[.:,]+$/, "").trim())
  const sayi = /^\d+$/.test(ad.trim()) ? parseInt(ad, 10) : null
  if (sayi == null && !nq) return []          // yalnız kesme/tire yazıldıysa öneri yok
  const eslesen = sureler.filter(s =>
    sayi != null ? s.id === sayi : (sik(s.isim).startsWith(nq) || sik(s.isim).includes(nq)))
  // Başla eşleşenler önce
  eslesen.sort((x, y) => (sik(y.isim).startsWith(nq) - sik(x.isim).startsWith(nq)) || (x.id - y.id))
  return eslesen.slice(0, sinir).map(s => {
    const n = s.ayetSayisi || 1
    let bas, son
    if (a1 != null) {
      bas = Math.max(1, Math.min(n, a1))
      son = Math.max(bas, Math.min(n, a2 != null ? a2 : a1))
    } else {
      // Aralık yazılmadıysa: kısa sûre tamamı, uzunsa ilk 7 âyet
      bas = 1; son = n <= 20 ? n : 7
    }
    return { ...s, bas, son }
  })
}

export const DONUS_BASLARI = [
  { id: "son", ad: "Cüz sonundan" },
  { id: "bas", ad: "Cüz başından" },
]

const sirala = (a, b) => (a.sureNo - b.sureNo) || (a.ayetNo - b.ayetNo)

/* Sayfanın üst/alt yarısı. Bölme KELİME sayısıyla (satır bilgisi yok): bir
   âyet, kelimelerinin çoğu hangi yarıdaysa oraya düşer. Boş kalırsa tamamı. */
export function sayfaKismiSec(birimler, kisim) {
  if (kisim !== "ust" && kisim !== "alt") return birimler
  const toplam = birimler.reduce((t, b) => t + (b.kelime || 1), 0)
  let birikim = 0
  const ust = [], alt = []
  for (const b of birimler) {
    const orta = birikim + (b.kelime || 1) / 2
    ;(orta <= toplam / 2 ? ust : alt).push(b)
    birikim += b.kelime || 1
  }
  const sec = kisim === "ust" ? ust : alt
  return sec.length ? sec : birimler
}

/* Cüz → { ilk, son } sayfa. Bir sayfanın cüzü, o sayfada BAŞLAYAN ilk âyetin
   cüzü sayılıyor. Kaynak mushaf verisi (sûreler → âyetler: { sayfa, cuz }). */
export function cuzSayfalari(mushafData) {
  const sayfaCuz = new Map()
  for (const sr of mushafData || []) {
    for (const a of sr.ayetler || []) {
      if (a.sayfa && a.cuz && !sayfaCuz.has(a.sayfa)) sayfaCuz.set(a.sayfa, a.cuz)
    }
  }
  const aralik = new Map()
  for (const [s, c] of sayfaCuz) {
    const v = aralik.get(c)
    if (!v) aralik.set(c, { ilk: s, son: s })
    else { if (s < v.ilk) v.ilk = s; if (s > v.son) v.son = s }
  }
  return aralik
}

/* Dönüş dizisi: [{ donus, cuz, sayfa }]. bas="son": her cüzün sondan
   (donus-1). sayfası; bas="bas": baştan (donus-1). sayfası. */
export function donusDizisi(aralik, bas = "son") {
  const cuzler = [...aralik.keys()].sort((x, y) => x - y)
  const enUzun = Math.max(0, ...cuzler.map(c => aralik.get(c).son - aralik.get(c).ilk + 1))
  const dizi = []
  for (let d = 1; d <= enUzun; d++) {
    for (const c of cuzler) {
      const { ilk, son } = aralik.get(c)
      const sayfa = bas === "bas" ? ilk + d - 1 : son - d + 1
      if (sayfa >= ilk && sayfa <= son) dizi.push({ donus: d, cuz: c, sayfa })
    }
  }
  return dizi
}

/* Bağlama adımları. ayetler: mushaf sırasında [{sureNo, ayetNo}].
   bag: önceden ezberlenmiş komşu âyet (ya da null).
   bas: öğrenme sırasında kaçıncı âyetten başlanacağı — öncekiler ÖĞRENİLMİŞ
        sayılır (yeni olarak çalınmaz ama birlikte okunan bloklara girer);
        zincirde kalınan yerden devam etmek için.
   Dönüş: [{ tip: "yeni" | "bagla", ayetler: [...], tekrar }] */
export function baglamaAdimlari({ ayetler, yon = "yukari", tekrar = 3, bag = null, bas = 0 }) {
  const sira = yon === "asagi" ? [...ayetler].reverse() : [...ayetler]
  const b0 = Math.max(0, Math.min(bas || 0, sira.length - 1))
  const bilinen = sira.slice(0, b0)
  const adimlar = []
  for (const x of sira.slice(b0)) {
    adimlar.push({ tip: "yeni", ayetler: [x], tekrar: Math.max(1, tekrar) })
    bilinen.push(x)
    const blok = (bag ? [bag, ...bilinen] : [...bilinen]).sort(sirala)
    if (blok.length > 1) adimlar.push({ tip: "bagla", ayetler: blok, tekrar: 1 })
  }
  return adimlar
}

/* Düz tekrar: âyetler (mushaf sırasıyla) N kez. */
export function duzAdimlar({ ayetler, tekrar = 3 }) {
  return ayetler.length ? [{ tip: "duz", ayetler: [...ayetler].sort(sirala), tekrar: Math.max(1, tekrar) }] : []
}

/* Adımları oynatıcı listesine çevir: [{sureNo, ayetNo}] */
export function adimlariListele(adimlar) {
  const liste = []
  for (const a of adimlar) {
    for (let i = 0; i < a.tekrar; i++) for (const y of a.ayetler) liste.push({ sureNo: y.sureNo, ayetNo: y.ayetNo })
  }
  return liste
}

export function useHifz() {
  const [veri, setVeri] = useState(hifzOku)
  useEffect(() => {
    aboneler.add(setVeri)
    return () => { aboneler.delete(setVeri) }
  }, [])
  const ayarla = useCallback((p) => ayarGuncelle(p), [])
  return [veri, ayarla]
}
